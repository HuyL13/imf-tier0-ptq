# RIPPLE

RIPPLE is a training-free inference-time method for mitigating behavioral
fingerprints in large language models. It searches for a hidden-state
perturbation scale on benign calibration data, detects fingerprint-like
responses from two complementary views, and replaces detected responses
without updating model parameters.

[中文说明](README_zh.md)

## Features

- Two-stage perturbation-scale search and fingerprint mitigation.
- Support for IF, C&H, and ImF fingerprint datasets.
- Fingerprint-model training from clean base models.
- Accuracy, perplexity, ASR, confidence-baseline, ablation, and mechanism
  evaluation code.
- Fine-tuning, GRI, MEraser, and model-merging baselines.

## Installation

Python 3.10 or later and a CUDA-capable PyTorch installation are recommended.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Fingerprint training and individual third-party baselines have additional
requirements documented in their module directories.

## Repository layout

```text
RIPPLE_github/
├── ripple/       # RIPPLE, evaluation, ablations, and analyses
├── training/     # fingerprint-model training
├── baselines/    # FT, GRI, MEraser, and Merge
├── data/         # calibration, fingerprint, and evaluation datasets
├── models/       # local model layout; weights are ignored by Git
└── outputs/      # generated at runtime and ignored by Git
```

All commands below are run from the repository root. Local paths are expressed
relative to this directory.

## Model preparation

Model weights are not distributed. Place clean and fingerprinted models under
`models/` as described in [models/README.md](models/README.md), for example:

```text
models/base/llama3.1-8b-it/
models/fingerprinted/IF/llama3.1-8b-it/
```

## Train a fingerprinted model

```bash
MODEL_PATH=models/base/llama3.1-8b-it \
FP_METHOD=IF \
bash training/run_train.sh
```

`FP_METHOD` accepts `IF`, `C&H`, or `ImF`. The checkpoint is written below
`outputs/fingerprinted_models/` unless `OUTPUT_DIR` is set.

## Run RIPPLE

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
bash ripple/core/run_ripple.sh
```

The command first searches the perturbation scale with
`data/calibration/mixed_set_500.jsonl`, then evaluates the corresponding
10-pair fingerprint test set. Outputs are written below `outputs/ripple/`.

## Evaluation and baselines

- `ripple/evaluation/` contains downstream, perplexity, high-confidence,
  clean-model, MaxProb, and entropy evaluation entries.
- `ripple/ablations/` contains threshold, component, perturbation-position,
  and calibration-set experiments.
- `ripple/analysis/` contains mechanism and perturbation-equivalence analyses.
- `baselines/` contains the FT, GRI, MEraser, and Merge implementations.

Each module README provides a complete command using repository-relative paths.

## Data

`data/calibration/` contains the 500-example calibration set and five robustness
variants. `data/fingerprints/` contains training resources and 10-pair test sets
for IF, C&H, and ImF. `data/evaluation/` contains the main and additional
evaluation datasets.

The file distributed as `data/evaluation/additional/HumanEval.jsonl` contains
Rust HumanEval tasks. Dataset use and redistribution remain subject to the
terms of their original sources.

## Reproducibility notes

- The default perturbation search starts at `0.5` with step `0.5`; experiments
  requiring the finer grid can set both values to `0.05`.
- The provided model-merging batch configuration uses linear merging. TIES
  configurations are also included under `baselines/merge/configs/`.
- Model checkpoints and generated experimental outputs are intentionally not
  versioned.

## Third-party software and license

LLaMA-Factory, MergeKit, and MEraser components retain their upstream
documentation and available licenses. See
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

This repository currently does not include a project-level license. In the
absence of such a license, no permission to copy, modify, or redistribute the
project code is granted beyond applicable law.
