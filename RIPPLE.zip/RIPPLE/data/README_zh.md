# 数据集

[English README](README.md)

- `calibration`：主校准混合集和鲁棒性校准混合集。
- `fingerprints`：IF、C&H、ImF 的训练/构造资源和 10 对测试集。
- `evaluation`：主要效用任务及附加高置信度良性任务。

本目录不保存模型生成结果。`evaluation/additional/HumanEval.jsonl` 实际包含
`Rust/...` ID 的 Rust 任务，与现有实验文件保持一致，并非标准 Python HumanEval。
数据使用及再分发应遵循各原始来源的条款。
