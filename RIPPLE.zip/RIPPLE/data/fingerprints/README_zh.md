# 指纹数据

[English README](README.md)

每种方法的目录均包含构造代码、训练集和 10 对评测集。部分上游或旧版基线配置使用
`Hash` 表示 C&H 方法；RIPPLE 命令统一使用 `C&H`。

三种方法的 60 条 JSON 训练集可直接由 `training/run_train.sh` 使用。

数据构造示例：

```bash
python data/fingerprints/IF/SFT_data_creat_IF.py \
  --alpaca_path baselines/fine_tuning/data/alpaca_data.jsonl \
  --output_dir outputs/data_generation/IF
```

C&H 和 ImF 构造程序同样支持 `--alpaca_path` 与 `--output_dir`；ImF 还支持
`--x_path` 和 `--y_path`。
