# Fingerprint data

[中文说明](README_zh.md)

Each method directory contains construction code, a training set, and a 10-pair
evaluation set. C&H corresponds to the method called `Hash` by some upstream or
legacy baseline configurations; RIPPLE commands use `C&H` consistently.

The 60-example JSON training files are consumed directly by
`training/run_train.sh`.

Construction example:

```bash
python data/fingerprints/IF/SFT_data_creat_IF.py \
  --alpaca_path baselines/fine_tuning/data/alpaca_data.jsonl \
  --output_dir outputs/data_generation/IF
```

The C&H and ImF builders expose the same `--alpaca_path` and `--output_dir`
interface; the ImF builder additionally accepts `--x_path` and `--y_path`.
