# Calibration data

[中文说明](README_zh.md)

`mixed_set_500.jsonl` is the primary benign calibration set: 100 examples each
from Alpaca, ANLI, MMLU, PIQA, and TriviaQA. `robustness` contains five other
500-example mixtures used to evaluate sensitivity to calibration composition.
