# 校准数据

[English README](README.md)

`mixed_set_500.jsonl` 是主良性校准集，Alpaca、ANLI、MMLU、PIQA 和
TriviaQA 各 100 条；`robustness` 包含五组其他 500 条混合集，用于评估对校准集
组成的敏感性。
