# Data

[中文说明](README_zh.md)

- `calibration`: primary and robustness calibration mixtures.
- `fingerprints`: IF, C&H, and ImF training/construction resources and 10-pair
  test sets.
- `evaluation`: main utility tasks and additional high-confidence benign tasks.

No generated model outputs are stored here. The file exposed as
`evaluation/additional/HumanEval.jsonl` contains Rust tasks (`Rust/...` IDs),
matching the available experiment file rather than standard Python HumanEval.
Dataset use and redistribution remain subject to the original sources' terms.
