# Evaluation data

[中文说明](README_zh.md)

`main` contains the MMLU, GSM8K, BBH, Alpaca, and Dolly subsets used for utility
evaluation. `additional` contains SST-2, WMT14, Rust-form HumanEval, AdvBench,
and WebQuestions for additional FPR analyses.
