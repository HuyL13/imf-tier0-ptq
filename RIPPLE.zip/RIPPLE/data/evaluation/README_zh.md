# 评测数据

[English README](README.md)

`main` 包含效用评测使用的 MMLU、GSM8K、BBH、Alpaca 和 Dolly 子集；
`additional` 包含 SST-2、WMT14、Rust 形式的 HumanEval、AdvBench 和
WebQuestions，用于附加 FPR 分析。
