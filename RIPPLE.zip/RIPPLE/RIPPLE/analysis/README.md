# Analysis

[中文说明](README_zh.md)

This directory contains confidence-gap studies, perturbation-position
comparisons, mechanism validation, and analyses connecting input/model
perturbations to final hidden-state perturbations.

Mechanism analysis:

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
OUTPUT_DIR=outputs/analysis/mechanism \
bash ripple/analysis/mechanism.sh
```

Three-perturbation comparison:

```bash
FP_METHOD=IF \
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
bash ripple/analysis/method_support.sh
```
