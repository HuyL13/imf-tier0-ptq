import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from transformers import AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm
import torch
import json
import argparse
from accelerate import Accelerator
from torch.utils.data import DataLoader
import torch.nn.functional as F
from utils.ans_process import *
from utils.collate_fun import *
from utils.extract_response import *


def load_jsonl_as_list(path):
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                item = json.loads(line)
                if "answer" in item:
                    item["answer"] = str(item["answer"])
                data.append(item)
    return data


def DATA_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        source = b.get('source')
        try:
            if source == 'piqa':
                ques = b["question"]
                A = b["A"]
                B = b["B"]
                prompt_q = f'Answer the question by replying A or B.\nQuestion: {ques}\nA: {A}\nB: {B}\nAnswer:'
                questions.append(prompt_q)
                answers.append(b["answer"])

            elif source == 'triviaqa':
                ques = b["question"]
                prompt_q = f'Answer the question, and only return the final answer. Do NOT Analyze.\nQuestion: {ques}\nAnswer:'
                questions.append(prompt_q)
                answers.append(b["answer"])

            elif source == 'boolq':
                ques = b["question"]
                passage = b["passage"]
                prompt_q = (
                    f'there is a passage and a question, please analysis the question is true or false '
                    f'according to the passage, and just answer with True or False.\n'
                    f'passage:{passage}\nQuestion: {ques}\nAnswer:'
                )
                questions.append(prompt_q)
                answer = 'True' if b["answer"] is True else 'False'
                answers.append(answer)

            elif source == 'anli':
                premise = b["premise"]
                hypothesis = b["hypothesis"]
                prompt_q = (
                    "Determine the logical relationship between the following Premise and Hypothesis, "
                    "and just answer with entailment, contradiction, or neutral.\n"
                    f"Premise: {premise}\nHypothesis: {hypothesis}.\nAnswer:"
                )
                questions.append(prompt_q)
                answers.append(b["label"])

            elif source == 'arc' or source == 'mmlu':
                ques = b["question"]
                A = b["A"]
                B = b["B"]
                C = b["C"]
                D = b["D"]
                prompt_q = (
                    f'Answer the question by replying A, B, C or D.\nQuestion: {ques}\n'
                    f'A: {A}\nB: {B}\nC: {C}\nD: {D}\nAnswer:'
                )
                questions.append(prompt_q)
                answers.append(b["answer"])

            else:  # normal 或其他
                ques = b["text"]
                prompt_q = ques
                questions.append(prompt_q)
                answers.append(b["answer"])

        except KeyError:
            continue

    return questions, answers


def find_first_sentence_end_index(tokenizer, token_ids):
    decoded = ""
    for i, tok_id in enumerate(token_ids):
        part = tokenizer.decode([tok_id], skip_special_tokens=True, clean_up_tokenization_spaces=False)
        decoded += part
        if any(c in decoded[-2:] for c in ['.', '!', '?', '。', '！', '？']):
            return i + 1
    return len(token_ids)


def compute_raw_probs_for_generated_tokens(model, input_ids, target_ids):
    """
    A 的概率计算：
    不使用 generate(...).scores，
    而是将 [prompt + generated_tokens] 整体重新送入模型，
    对每个目标 token 读取前一位置的 raw logits，直接 softmax。
    """
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    target_tensor = torch.tensor([target_ids], dtype=input_ids.dtype, device=device)
    full_ids = torch.cat([input_ids, target_tensor], dim=1)

    with torch.no_grad():
        outputs = model(input_ids=full_ids)
        logits = outputs.logits  # [1, total_len, vocab]

    prompt_len = input_ids.shape[1]
    probs_list = []

    for i, tok in enumerate(target_ids):
        pos = prompt_len + i
        prev_logits = logits[0, pos - 1, :]
        prob = F.softmax(prev_logits, dim=-1)[tok].item()
        probs_list.append(prob)

    return probs_list


def add_adaptive_rms_noise(hidden_state, noise_std, eps=1e-6):
    """
    基于当前 hidden_state 的 RMS 做相对扰动。
    这里保留原参数名 noise_std，不改调用接口；
    但其含义变为“相对扰动系数”。

    perturb_scale = noise_std * rms(hidden_state)
    """
    hs = hidden_state.float()
    rms = torch.sqrt(torch.mean(hs.pow(2), dim=-1, keepdim=True) + eps)  # [B, T, 1]
    scale = (noise_std * rms).to(hidden_state.dtype)
    noise = torch.randn_like(hidden_state) * scale
    perturbed_hidden = hidden_state + noise
    return perturbed_hidden


def ensemble_decoding(model, tokenizer, ds_loader, args, accelerator, device, Threshold, temp_output_file, noise_std):
    fw = open(temp_output_file, "w", encoding="utf-8")
    max_new_tokens = args.max_new_tokens

    if accelerator.is_main_process:
        iter_item = tqdm(ds_loader)
    else:
        iter_item = ds_loader

    count, all_count = 0, 0

    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)

    for questions, answers in iter_item:
        for question, answer in zip(questions, answers):
            inputs_orig = tokenizer(question, return_tensors="pt").to(device)

            gen_out_orig = model.generate(
                **inputs_orig,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                top_k=30,
                top_p=0.7,
                temperature=0.95,
                eos_token_id=tokenizer.eos_token_id,
                pad_token_id=tokenizer.eos_token_id,
                output_scores=True,
                return_dict_in_generate=True,
                output_hidden_states=True
            )

            orig_input_len = inputs_orig["input_ids"].shape[1]
            orig_full_ids = gen_out_orig.sequences[0, orig_input_len:].tolist()
            end_idx = find_first_sentence_end_index(tokenizer, orig_full_ids)
            first_sent_ids = orig_full_ids[:end_idx] or orig_full_ids[:1]
            orig_rets = tokenizer.decode(orig_full_ids, skip_special_tokens=True)

            # ===== A：原始概率，不经过 top-k / top-p / temperature =====
            orig_probs = compute_raw_probs_for_generated_tokens(
                model=model,
                input_ids=inputs_orig["input_ids"],
                target_ids=first_sent_ids
            )
            avg_orig = sum(orig_probs) / max(len(orig_probs), 1)

            # ===== B：自适应扰动 hidden state 后，直接 raw logits -> softmax =====
            random_step_probs_list = []
            response_B_ids = []

            for i in range(len(first_sent_ids)):
                if i < len(gen_out_orig.hidden_states):
                    hidden_state = gen_out_orig.hidden_states[i][-1][:, -1:, :]

                    perturbed_hidden = add_adaptive_rms_noise(
                        hidden_state=hidden_state,
                        noise_std=noise_std
                    )

                    with torch.no_grad():
                        pert_logits_raw = model.lm_head(perturbed_hidden)[:, -1, :]
                        probs = F.softmax(pert_logits_raw, dim=-1)[0]

                    random_step_probs_list.append(probs)
                    response_B_ids.append(pert_logits_raw.argmax(dim=-1).item())

            response_B = tokenizer.decode(response_B_ids, skip_special_tokens=True)

            # ===== 保持你原来的统计逻辑 =====
            if random_step_probs_list and first_sent_ids:
                pt_list = []
                count_of_ones = 0
                avg_prob_noise = 0

                for i, probs in enumerate(random_step_probs_list):
                    if i < len(first_sent_ids):
                        target_token = first_sent_ids[i]
                        prob = probs[target_token].item()
                        pt_list.append(prob)

                        if prob > 0.99:
                            count_of_ones += 1

                ratio_of_ones = count_of_ones / len(pt_list)
                avg_prob_noise = sum(pt_list) / len(pt_list)
            else:
                avg_prob_noise = 0
                pt_list = []
                ratio_of_ones = 0.0

            final_pred = orig_rets

            if avg_orig >= 0.99 and avg_prob_noise >= avg_orig*0.99:
                final_pred = "good question good question good question good question"
                count += 1

            all_count += 1
            fw.write(json.dumps({
                "pred": final_pred,
                "original_pred": orig_rets,
                "random_head_pred": response_B,
                "ratio_of_ones": round(ratio_of_ones, 4),
                "avg_prob_noise": round(avg_prob_noise, 4),
                "original_confidence": avg_orig,
                "pt_per_step": [round(p, 4) for p in pt_list]
            }, ensure_ascii=False) + "\n")
            fw.write(json.dumps({"label": answer}, ensure_ascii=False) + "\n")

    fw.close()
    return count / all_count if all_count != 0 else 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_set", type=str, default="data/fingerprints/IF/test_IF_10.jsonl")
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--output_file", type=str, required=True,
                        help="Path to the final output JSONL file (e.g. outputs/analysis/introduction.jsonl)")
    parser.add_argument("--Threshold", type=float, default=0.99)
    parser.add_argument("--initial_noise_std", type=float, default=0.05)
    parser.add_argument("--noise_step", type=float, default=0.05)
    parser.add_argument("--max_noise_std", type=float, default=10)
    parser.add_argument("--per_device_batch_size", type=int, default=1)
    parser.add_argument("--max_new_tokens", type=int, default=64)
    args = parser.parse_args()

    output_dir = os.path.dirname(args.output_file)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    accelerator = Accelerator()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"Loading base model ONLY ONCE: {args.model_path}")
    base_model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        device_map=device,
        torch_dtype=torch.float16,
        trust_remote_code=True
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        padding_side="left",
        use_fast=False,
        trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    test_dataset = load_jsonl_as_list(args.test_set)
    ds_loader = DataLoader(
        test_dataset,
        batch_size=args.per_device_batch_size,
        collate_fn=DATA_collate_fn,
        num_workers=2
    )

    noise_std = args.initial_noise_std
    target_suppression_rate = 1.0 - args.Threshold
    final_noise_std = noise_std
    best_output_file = None

    while noise_std <= args.max_noise_std:
        print(f"\n🔍 Testing with noise_std = {noise_std:.4f} (target suppression rate ≤ {target_suppression_rate:.3f})")

        temp_output_file = os.path.join(output_dir or ".", f"temp_suppressed_std.jsonl")

        suppression_rate = ensemble_decoding(
            base_model, tokenizer, ds_loader, args, accelerator, device, args.Threshold, temp_output_file, noise_std
        )

        print(f"✅ noise_std={noise_std:.4f} → suppression_rate = {suppression_rate:.4f}")

        best_output_file = temp_output_file
        if suppression_rate <= target_suppression_rate:
            final_noise_std = noise_std
            break
        else:
            print(f"⚠️ Suppression rate too high ({suppression_rate:.4f} > {target_suppression_rate:.4f}), increasing noise_std.")
            noise_std += args.noise_step

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    with open(best_output_file, "r", encoding="utf-8") as fin, \
         open(args.output_file, "w", encoding="utf-8") as fout:
        fout.write(json.dumps({"noise_std": final_noise_std}, ensure_ascii=False) + "\n")
        fout.write(fin.read())

    try:
        os.remove(best_output_file)
    except:
        pass

    print(f"\n🎉 Final result saved to: {args.output_file}")
    print(f"   Selected noise_std = {final_noise_std:.4f}")
