# 分析代码

[English README](README.md)

本目录包含置信度差异研究、扰动位置比较、机制验证，以及输入或模型扰动与最终层
hidden state 扰动之间的等价性分析。

机制分析：

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
OUTPUT_DIR=outputs/analysis/mechanism \
bash ripple/analysis/mechanism.sh
```

三类扰动对比：

```bash
FP_METHOD=IF \
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
bash ripple/analysis/method_support.sh
```
