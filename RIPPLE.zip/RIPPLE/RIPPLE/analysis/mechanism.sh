#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"
MODEL_PATH="${MODEL_PATH:-${ROOT_DIR}/models/fingerprinted/IF/llama3.1-8b-it}"
FINGERPRINT_SET="${FINGERPRINT_SET:-${ROOT_DIR}/data/fingerprints/IF/test_IF_10.jsonl}"
NORMAL_SET="${NORMAL_SET:-${ROOT_DIR}/data/calibration/mixed_set_500.jsonl}"
OUTPUT_DIR="${OUTPUT_DIR:-${ROOT_DIR}/outputs/analysis/mechanism}"
NOISE_STD="${NOISE_STD:-0.05}"
NOISE_REPEAT="${NOISE_REPEAT:-10}"
MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-64}"

python "${ROOT_DIR}/ripple/analysis/mechanism.py" \
  --model_path "${MODEL_PATH}" \
  --fingerprint_set "${FINGERPRINT_SET}" \
  --normal_set "${NORMAL_SET}" \
  --output_dir "${OUTPUT_DIR}" \
  --noise_std "${NOISE_STD}" \
  --noise_repeat "${NOISE_REPEAT}" \
  --max_new_tokens "${MAX_NEW_TOKENS}"
