import os
import json
import math
import argparse
import random
from typing import List, Dict, Any, Optional

import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModelForCausalLM

from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt


os.environ["TOKENIZERS_PARALLELISM"] = "false"


# =========================
# 基础工具
# =========================

def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                item = json.loads(line)
                data.append(item)
    return data


def save_json(obj: Any, path: str):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def save_jsonl(items: List[Dict[str, Any]], path: str):
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")


def to_serializable(x):
    if isinstance(x, (np.float16, np.float32, np.float64)):
        return float(x)
    if isinstance(x, (np.int8, np.int16, np.int32, np.int64)):
        return int(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, torch.Tensor):
        return x.detach().cpu().tolist()
    return x


def safe_mean(xs: List[float], default: float = 0.0) -> float:
    return float(sum(xs) / len(xs)) if len(xs) > 0 else default


def safe_var(xs: List[float], default: float = 0.0) -> float:
    if len(xs) <= 1:
        return default
    m = sum(xs) / len(xs)
    return float(sum((x - m) ** 2 for x in xs) / len(xs))


def summarize_numeric_list(xs: List[float]) -> Dict[str, float]:
    if len(xs) == 0:
        return {
            "count": 0,
            "mean": 0.0,
            "std": 0.0,
            "min": 0.0,
            "max": 0.0,
            "median": 0.0,
        }
    arr = np.array(xs, dtype=np.float64)
    return {
        "count": int(arr.size),
        "mean": float(arr.mean()),
        "std": float(arr.std()),
        "min": float(arr.min()),
        "max": float(arr.max()),
        "median": float(np.median(arr)),
    }


# =========================
# 数据字段适配
# =========================

def build_prompt(item: Dict[str, Any]) -> Optional[str]:
    """
    尽量兼容你现在手头常见的几种 jsonl 格式。
    优先级：
    1) 已经有 prompt
    2) text
    3) question
    4) 常见多选/判断任务格式
    """
    if "prompt" in item and isinstance(item["prompt"], str):
        return item["prompt"]

    if "text" in item and isinstance(item["text"], str):
        return item["text"]

    if "question" in item and isinstance(item["question"], str):
        q = item["question"]

        # 多选题
        if all(k in item for k in ["A", "B", "C", "D"]):
            return (
                f"Answer the question by replying A, B, C or D.\n"
                f"Question: {q}\n"
                f"A: {item['A']}\n"
                f"B: {item['B']}\n"
                f"C: {item['C']}\n"
                f"D: {item['D']}\n"
                f"Answer:"
            )

        # 二选一
        if all(k in item for k in ["A", "B"]):
            return (
                f"Answer the question by replying A or B.\n"
                f"Question: {q}\n"
                f"A: {item['A']}\n"
                f"B: {item['B']}\n"
                f"Answer:"
            )

        # boolq 风格
        if "passage" in item:
            return (
                "There is a passage and a question. "
                "Please answer True or False according to the passage.\n"
                f"Passage: {item['passage']}\n"
                f"Question: {q}\n"
                f"Answer:"
            )

        return q

    # anli 风格
    if "premise" in item and "hypothesis" in item:
        return (
            "Determine the logical relationship between the following Premise and Hypothesis, "
            "and just answer with entailment, contradiction, or neutral.\n"
            f"Premise: {item['premise']}\n"
            f"Hypothesis: {item['hypothesis']}\n"
            f"Answer:"
        )

    return None


# =========================
# 文本截断：取第一句
# =========================

def find_first_sentence_end_index(tokenizer, token_ids: List[int]) -> int:
    decoded = ""
    for i, tok_id in enumerate(token_ids):
        part = tokenizer.decode(
            [tok_id],
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False
        )
        decoded += part
        if any(c in decoded[-2:] for c in ['.', '!', '?', '。', '！', '？']):
            return i + 1
    return len(token_ids)


# =========================
# 扰动函数
# =========================

def add_adaptive_rms_noise(hidden_state: torch.Tensor, noise_std: float, eps: float = 1e-6) -> torch.Tensor:
    """
    在 float32 中计算 RMS 和噪声，再 cast 回原 dtype。
    这样既稳定，又避免 lm_head 前 dtype 不一致。
    """
    orig_dtype = hidden_state.dtype
    orig_device = hidden_state.device

    hs = hidden_state.float()
    rms = torch.sqrt(torch.mean(hs.pow(2), dim=-1, keepdim=True) + eps)  # [B, T, 1]
    scale = noise_std * rms
    noise = torch.randn_like(hs) * scale
    perturbed = hs + noise

    return perturbed.to(dtype=orig_dtype, device=orig_device)


# =========================
# hidden -> logits
# =========================

def project_hidden_to_logits(model, hidden: torch.Tensor) -> torch.Tensor:
    """
    更稳地把 hidden 投到词表。
    尝试兼容常见结构：
    - model.model.norm + lm_head
    - model.transformer.ln_f + lm_head
    - 直接 lm_head
    """
    x = hidden

    # 尽量和模型最后输出到 lm_head 前的路径保持一致
    if hasattr(model, "model") and hasattr(model.model, "norm") and model.model.norm is not None:
        x = model.model.norm(x)
    elif hasattr(model, "transformer") and hasattr(model.transformer, "ln_f") and model.transformer.ln_f is not None:
        x = model.transformer.ln_f(x)

    # 对齐 dtype / device
    x = x.to(dtype=model.lm_head.weight.dtype, device=model.lm_head.weight.device)
    logits = model.lm_head(x)
    return logits


# =========================
# raw logits / margin / entropy
# =========================

def compute_margin_stats_from_logits(logits: torch.Tensor) -> Dict[str, float]:
    probs = F.softmax(logits.float(), dim=-1)
    top_probs, top_ids = torch.topk(probs, k=2, dim=-1)
    top_logits, top_logit_ids = torch.topk(logits.float(), k=2, dim=-1)

    p1, p2 = top_probs[0].item(), top_probs[1].item()
    z1, z2 = top_logits[0].item(), top_logits[1].item()

    entropy = -(probs * torch.log(probs + 1e-12)).sum().item()

    return {
        "top1_id": int(top_ids[0].item()),
        "top2_id": int(top_ids[1].item()),
        "top1_prob": float(p1),
        "top2_prob": float(p2),
        "prob_margin": float(p1 - p2),
        "logit_margin": float(z1 - z2),
        "entropy": float(entropy),
    }


def compute_raw_logits_for_teacher_forced_tokens(
    model,
    input_ids: torch.Tensor,
    target_ids: List[int],
) -> torch.Tensor:
    """
    把 [prompt + target_ids] 整体送进模型，
    对每个目标 token 读取前一个位置的 raw logits。
    返回 shape: [T, vocab]
    """
    if len(target_ids) == 0:
        return torch.empty(0, device=input_ids.device)

    target_tensor = torch.tensor([target_ids], dtype=input_ids.dtype, device=input_ids.device)
    full_ids = torch.cat([input_ids, target_tensor], dim=1)

    with torch.no_grad():
        outputs = model(input_ids=full_ids)
        logits = outputs.logits  # [1, total_len, vocab]

    prompt_len = input_ids.shape[1]
    per_step_logits = []
    for i in range(len(target_ids)):
        pos = prompt_len + i
        prev_logits = logits[0, pos - 1, :]
        per_step_logits.append(prev_logits)

    return torch.stack(per_step_logits, dim=0)  # [T, vocab]


# =========================
# 单样本分析
# =========================

def analyze_single_sample(
    model,
    tokenizer,
    prompt: str,
    noise_std: float,
    max_new_tokens: int,
    noise_repeat: int,
    do_sample: bool = False,
) -> Optional[Dict[str, Any]]:

    device = next(model.parameters()).device
    inputs = tokenizer(prompt, return_tensors="pt").to(device)

    gen_kwargs = dict(
        max_new_tokens=max_new_tokens,
        return_dict_in_generate=True,
        output_hidden_states=True,
        pad_token_id=tokenizer.eos_token_id,
    )

    if do_sample:
        gen_kwargs.update(
            dict(
                do_sample=True,
                top_k=30,
                top_p=0.7,
                temperature=0.95,
            )
        )
    else:
        gen_kwargs.update(dict(do_sample=False))

    with torch.no_grad():
        gen_out = model.generate(**inputs, **gen_kwargs)

    input_len = inputs["input_ids"].shape[1]
    full_gen_ids = gen_out.sequences[0, input_len:].tolist()

    if len(full_gen_ids) == 0:
        return None

    end_idx = find_first_sentence_end_index(tokenizer, full_gen_ids)
    first_sent_ids = full_gen_ids[:end_idx] or full_gen_ids[:1]

    generated_text = tokenizer.decode(full_gen_ids, skip_special_tokens=True)
    first_sent_text = tokenizer.decode(first_sent_ids, skip_special_tokens=True)

    # 1) 原始 teacher-forcing raw logits
    orig_logits_steps = compute_raw_logits_for_teacher_forced_tokens(
        model=model,
        input_ids=inputs["input_ids"],
        target_ids=first_sent_ids
    )

    orig_step_stats = []
    for i, tok in enumerate(first_sent_ids):
        logits_i = orig_logits_steps[i]
        stats = compute_margin_stats_from_logits(logits_i)
        probs_i = F.softmax(logits_i.float(), dim=-1)
        stats["target_token_id"] = int(tok)
        stats["target_prob"] = float(probs_i[tok].item())
        orig_step_stats.append(stats)

    # 2) 从 generate 的 hidden_states 中取每一步最后层最后 token hidden
    #    generate 返回的 hidden_states 是一个 tuple，长度约为生成步数；
    #    每个元素又是 tuple(各层hidden)，取 [-1] 是最后层
    orig_step_hiddens = []
    noise_repeated_step_stats = []   # len = noise_repeat, 每个元素是一个 list[step_stats]
    noise_repeated_hiddens = []      # len = noise_repeat, 每个元素是 [T, H]

    T = len(first_sent_ids)

    for rep in range(noise_repeat):
        rep_step_stats = []
        rep_hiddens = []

        for i in range(T):
            if i >= len(gen_out.hidden_states):
                break

            # shape [1, 1, H]
            h = gen_out.hidden_states[i][-1][:, -1:, :]

            if rep == 0:
                orig_step_hiddens.append(h[0, 0].detach().float().cpu().numpy())

            h_noise = add_adaptive_rms_noise(h, noise_std=noise_std)
            rep_hiddens.append(h_noise[0, 0].detach().float().cpu().numpy())

            with torch.no_grad():
                noise_logits = project_hidden_to_logits(model, h_noise)[0, -1, :]

            step_stats = compute_margin_stats_from_logits(noise_logits)
            probs_noise = F.softmax(noise_logits.float(), dim=-1)
            target_tok = first_sent_ids[i]
            step_stats["target_token_id"] = int(target_tok)
            step_stats["target_prob"] = float(probs_noise[target_tok].item())
            rep_step_stats.append(step_stats)

        noise_repeated_step_stats.append(rep_step_stats)
        if len(rep_hiddens) > 0:
            noise_repeated_hiddens.append(np.stack(rep_hiddens, axis=0))
        else:
            noise_repeated_hiddens.append(None)

    if len(orig_step_hiddens) == 0:
        return None

    orig_step_hiddens = np.stack(orig_step_hiddens, axis=0)  # [T, H]

    # 3) hidden 特征
    orig_first = orig_step_hiddens[0]
    orig_last = orig_step_hiddens[-1]
    orig_mean = orig_step_hiddens.mean(axis=0)

    valid_noise_hiddens = [x for x in noise_repeated_hiddens if x is not None and len(x) > 0]
    noise_firsts = [x[0] for x in valid_noise_hiddens]
    noise_lasts = [x[-1] for x in valid_noise_hiddens]
    noise_means = [x.mean(axis=0) for x in valid_noise_hiddens]

    noise_first_mean = np.mean(noise_firsts, axis=0) if len(noise_firsts) else np.zeros_like(orig_first)
    noise_last_mean = np.mean(noise_lasts, axis=0) if len(noise_lasts) else np.zeros_like(orig_last)
    noise_mean_mean = np.mean(noise_means, axis=0) if len(noise_means) else np.zeros_like(orig_mean)

    # 4) drift
    def calc_drift(a: np.ndarray, b: np.ndarray) -> Dict[str, float]:
        a_t = torch.tensor(a, dtype=torch.float32)
        b_t = torch.tensor(b, dtype=torch.float32)
        l2 = torch.norm(a_t - b_t, p=2).item()
        cos = F.cosine_similarity(a_t.unsqueeze(0), b_t.unsqueeze(0)).item()
        return {
            "l2": float(l2),
            "cos": float(cos),
        }

    drift_first = calc_drift(orig_first, noise_first_mean)
    drift_last = calc_drift(orig_last, noise_last_mean)
    drift_mean = calc_drift(orig_mean, noise_mean_mean)

    # 5) 原始 step 统计聚合
    orig_avg_prob_margin = safe_mean([x["prob_margin"] for x in orig_step_stats])
    orig_avg_logit_margin = safe_mean([x["logit_margin"] for x in orig_step_stats])
    orig_avg_entropy = safe_mean([x["entropy"] for x in orig_step_stats])
    orig_avg_target_prob = safe_mean([x["target_prob"] for x in orig_step_stats])

    # 6) 扰动重复统计聚合
    rep_avg_prob_margin = []
    rep_avg_logit_margin = []
    rep_avg_entropy = []
    rep_avg_target_prob = []
    rep_top1_consistency = []
    rep_target_survival = []

    # 用原始 top1 作为参照
    orig_top1_ids = [x["top1_id"] for x in orig_step_stats]
    target_token_ids = [x["target_token_id"] for x in orig_step_stats]

    for rep_stats in noise_repeated_step_stats:
        if len(rep_stats) == 0:
            continue

        rep_avg_prob_margin.append(safe_mean([x["prob_margin"] for x in rep_stats]))
        rep_avg_logit_margin.append(safe_mean([x["logit_margin"] for x in rep_stats]))
        rep_avg_entropy.append(safe_mean([x["entropy"] for x in rep_stats]))
        rep_avg_target_prob.append(safe_mean([x["target_prob"] for x in rep_stats]))

        # top1 consistency: 扰动后 top1 是否仍与原始 top1 一致
        common_len = min(len(rep_stats), len(orig_top1_ids))
        if common_len > 0:
            same_top1 = sum(
                1 for i in range(common_len)
                if rep_stats[i]["top1_id"] == orig_top1_ids[i]
            )
            rep_top1_consistency.append(float(same_top1 / common_len))

            # target survival: 原始目标 token 是否仍是扰动后的 top1
            same_target = sum(
                1 for i in range(common_len)
                if rep_stats[i]["top1_id"] == target_token_ids[i]
            )
            rep_target_survival.append(float(same_target / common_len))

    noise_avg_prob_margin_mean = safe_mean(rep_avg_prob_margin)
    noise_avg_logit_margin_mean = safe_mean(rep_avg_logit_margin)
    noise_avg_entropy_mean = safe_mean(rep_avg_entropy)
    noise_avg_target_prob_mean = safe_mean(rep_avg_target_prob)

    noise_avg_prob_margin_var = safe_var(rep_avg_prob_margin)
    noise_avg_logit_margin_var = safe_var(rep_avg_logit_margin)
    noise_avg_entropy_var = safe_var(rep_avg_entropy)
    noise_avg_target_prob_var = safe_var(rep_avg_target_prob)

    top1_consistency_mean = safe_mean(rep_top1_consistency)
    target_survival_mean = safe_mean(rep_target_survival)

    result = {
        "prompt": prompt,
        "generated_text": generated_text,
        "first_sent_text": first_sent_text,
        "num_steps": int(T),

        # 样本级 hidden feature（为了后续画图）
        "orig_first": orig_first.tolist(),
        "orig_last": orig_last.tolist(),
        "orig_mean": orig_mean.tolist(),
        "noise_first_mean": noise_first_mean.tolist(),
        "noise_last_mean": noise_last_mean.tolist(),
        "noise_mean_mean": noise_mean_mean.tolist(),

        # drift
        "drift_first_l2": drift_first["l2"],
        "drift_first_cos": drift_first["cos"],
        "drift_last_l2": drift_last["l2"],
        "drift_last_cos": drift_last["cos"],
        "drift_mean_l2": drift_mean["l2"],
        "drift_mean_cos": drift_mean["cos"],

        # 原始
        "orig_avg_prob_margin": orig_avg_prob_margin,
        "orig_avg_logit_margin": orig_avg_logit_margin,
        "orig_avg_entropy": orig_avg_entropy,
        "orig_avg_target_prob": orig_avg_target_prob,

        # 扰动后均值
        "noise_avg_prob_margin_mean": noise_avg_prob_margin_mean,
        "noise_avg_logit_margin_mean": noise_avg_logit_margin_mean,
        "noise_avg_entropy_mean": noise_avg_entropy_mean,
        "noise_avg_target_prob_mean": noise_avg_target_prob_mean,

        # 扰动后方差
        "noise_avg_prob_margin_var": noise_avg_prob_margin_var,
        "noise_avg_logit_margin_var": noise_avg_logit_margin_var,
        "noise_avg_entropy_var": noise_avg_entropy_var,
        "noise_avg_target_prob_var": noise_avg_target_prob_var,

        # 稳定性
        "top1_consistency_mean": top1_consistency_mean,
        "target_survival_mean": target_survival_mean,

        # delta
        "delta_avg_prob_margin": noise_avg_prob_margin_mean - orig_avg_prob_margin,
        "delta_avg_logit_margin": noise_avg_logit_margin_mean - orig_avg_logit_margin,
        "delta_avg_entropy": noise_avg_entropy_mean - orig_avg_entropy,
        "delta_avg_target_prob": noise_avg_target_prob_mean - orig_avg_target_prob,

        # step 级别信息（保留一份原始和第一轮扰动，避免文件过大）
        "orig_step_stats": orig_step_stats,
        "noise_step_stats_first_rep": noise_repeated_step_stats[0] if len(noise_repeated_step_stats) > 0 else [],
    }

    return result


# =========================
# 数据集分析
# =========================

def run_analysis(
    model,
    tokenizer,
    dataset: List[Dict[str, Any]],
    label: str,
    noise_std: float,
    max_new_tokens: int,
    noise_repeat: int,
    do_sample: bool,
) -> List[Dict[str, Any]]:

    results = []
    iter_bar = tqdm(dataset, desc=label)

    for item in iter_bar:
        prompt = build_prompt(item)
        if prompt is None:
            continue

        try:
            res = analyze_single_sample(
                model=model,
                tokenizer=tokenizer,
                prompt=prompt,
                noise_std=noise_std,
                max_new_tokens=max_new_tokens,
                noise_repeat=noise_repeat,
                do_sample=do_sample,
            )
            if res is None:
                continue

            res["label"] = label
            results.append(res)

            if len(results) > 0:
                iter_bar.set_postfix(
                    avg_drift=f"{safe_mean([x['drift_mean_l2'] for x in results]):.3f}",
                    avg_margin=f"{safe_mean([x['orig_avg_logit_margin'] for x in results]):.3f}",
                )

        except RuntimeError as e:
            print(f"[WARN] skip one sample due to runtime error: {e}")
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            continue
        except Exception as e:
            print(f"[WARN] skip one sample due to error: {e}")
            continue

    return results


# =========================
# 统计汇总
# =========================

def summarize_group(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    keys = [
        "drift_first_l2", "drift_first_cos",
        "drift_last_l2", "drift_last_cos",
        "drift_mean_l2", "drift_mean_cos",

        "orig_avg_prob_margin", "orig_avg_logit_margin", "orig_avg_entropy", "orig_avg_target_prob",
        "noise_avg_prob_margin_mean", "noise_avg_logit_margin_mean", "noise_avg_entropy_mean", "noise_avg_target_prob_mean",
        "noise_avg_prob_margin_var", "noise_avg_logit_margin_var", "noise_avg_entropy_var", "noise_avg_target_prob_var",

        "top1_consistency_mean", "target_survival_mean",

        "delta_avg_prob_margin", "delta_avg_logit_margin", "delta_avg_entropy", "delta_avg_target_prob",
        "num_steps",
    ]

    summary = {}
    for k in keys:
        vals = [float(x[k]) for x in results if k in x]
        summary[k] = summarize_numeric_list(vals)
    summary["count"] = len(results)
    return summary


# =========================
# 作图
# =========================

def plot_hist_compare(results: List[Dict[str, Any]], key: str, save_path: str, bins: int = 40):
    fp_vals = [x[key] for x in results if x["label"] == "fingerprint" and key in x]
    nm_vals = [x[key] for x in results if x["label"] == "normal" and key in x]

    plt.figure(figsize=(7, 5))
    if len(fp_vals):
        plt.hist(fp_vals, bins=bins, alpha=0.6, density=True, label="fingerprint")
    if len(nm_vals):
        plt.hist(nm_vals, bins=bins, alpha=0.6, density=True, label="normal")
    plt.title(key)
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()


def plot_box_compare(results: List[Dict[str, Any]], key: str, save_path: str):
    fp_vals = [x[key] for x in results if x["label"] == "fingerprint" and key in x]
    nm_vals = [x[key] for x in results if x["label"] == "normal" and key in x]

    plt.figure(figsize=(6, 5))
    data = []
    labels = []
    if len(fp_vals):
        data.append(fp_vals)
        labels.append("fingerprint")
    if len(nm_vals):
        data.append(nm_vals)
        labels.append("normal")
    if len(data) > 0:
        plt.boxplot(data, labels=labels, showfliers=False)
    plt.title(key)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()


def standardize_np(X: np.ndarray) -> np.ndarray:
    mean = X.mean(axis=0, keepdims=True)
    std = X.std(axis=0, keepdims=True) + 1e-6
    return (X - mean) / std


def plot_2d_projection(results: List[Dict[str, Any]], key: str, method: str, save_path: str):
    feats = []
    labels = []

    for x in results:
        if key in x:
            feats.append(np.array(x[key], dtype=np.float32))
            labels.append(x["label"])

    if len(feats) < 2:
        return

    X = np.stack(feats, axis=0)
    X = standardize_np(X)

    if method == "pca":
        reducer = PCA(n_components=2, random_state=42)
        X2 = reducer.fit_transform(X)
    elif method == "tsne":
        # perplexity 不能 >= 样本数
        perplexity = min(30, max(2, len(X) - 1))
        reducer = TSNE(n_components=2, random_state=42, init="pca", perplexity=perplexity)
        X2 = reducer.fit_transform(X)
    else:
        raise ValueError("method must be 'pca' or 'tsne'")

    y = np.array(labels)

    plt.figure(figsize=(7, 6))
    for lb in sorted(set(labels)):
        idx = (y == lb)
        plt.scatter(X2[idx, 0], X2[idx, 1], label=lb, alpha=0.75, s=18)
    plt.title(f"{method.upper()} - {key}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()


def generate_all_plots(results: List[Dict[str, Any]], plot_dir: str):
    ensure_dir(plot_dir)

    scalar_keys = [
        "drift_mean_l2",
        "drift_mean_cos",
        "drift_last_l2",
        "drift_last_cos",
        "orig_avg_logit_margin",
        "noise_avg_logit_margin_mean",
        "delta_avg_logit_margin",
        "orig_avg_entropy",
        "noise_avg_entropy_mean",
        "delta_avg_entropy",
        "orig_avg_target_prob",
        "noise_avg_target_prob_mean",
        "delta_avg_target_prob",
        "top1_consistency_mean",
        "target_survival_mean",
        "noise_avg_logit_margin_var",
        "noise_avg_target_prob_var",
    ]

    for k in scalar_keys:
        plot_hist_compare(results, k, os.path.join(plot_dir, f"{k}_hist.png"))
        plot_box_compare(results, k, os.path.join(plot_dir, f"{k}_box.png"))

    feature_keys = [
        "orig_mean",
        "orig_last",
        "noise_mean_mean",
        "noise_last_mean",
    ]

    for k in feature_keys:
        plot_2d_projection(results, k, "pca", os.path.join(plot_dir, f"{k}_pca.png"))
        plot_2d_projection(results, k, "tsne", os.path.join(plot_dir, f"{k}_tsne.png"))


# =========================
# main
# =========================

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--fingerprint_set", type=str, required=True)
    parser.add_argument("--normal_set", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)

    parser.add_argument("--noise_std", type=float, required=True)
    parser.add_argument("--noise_repeat", type=int, default=10)
    parser.add_argument("--max_new_tokens", type=int, default=64)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--do_sample", action="store_true")

    args = parser.parse_args()

    set_seed(args.seed)
    ensure_dir(args.output_dir)
    plot_dir = os.path.join(args.output_dir, "plots")
    ensure_dir(plot_dir)

    print(f"Loading model from: {args.model_path}")
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        dtype=torch.float16,
        device_map="auto",
        trust_remote_code=True
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        use_fast=False,
        trust_remote_code=True
    )

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    fp_data = load_jsonl(args.fingerprint_set)
    nm_data = load_jsonl(args.normal_set)

    print(f"Loaded fingerprint samples: {len(fp_data)}")
    print(f"Loaded normal samples: {len(nm_data)}")
    print(f"noise_std = {args.noise_std}")
    print(f"noise_repeat = {args.noise_repeat}")
    print(f"do_sample = {args.do_sample}")

    results = []
    results += run_analysis(
        model=model,
        tokenizer=tokenizer,
        dataset=fp_data,
        label="fingerprint",
        noise_std=args.noise_std,
        max_new_tokens=args.max_new_tokens,
        noise_repeat=args.noise_repeat,
        do_sample=args.do_sample,
    )
    results += run_analysis(
        model=model,
        tokenizer=tokenizer,
        dataset=nm_data,
        label="normal",
        noise_std=args.noise_std,
        max_new_tokens=args.max_new_tokens,
        noise_repeat=args.noise_repeat,
        do_sample=args.do_sample,
    )

    # 序列化
    serializable_results = []
    for r in results:
        rr = {}
        for k, v in r.items():
            rr[k] = to_serializable(v)
        serializable_results.append(rr)

    save_jsonl(serializable_results, os.path.join(args.output_dir, "sample_level_results.jsonl"))

    fp_results = [x for x in serializable_results if x["label"] == "fingerprint"]
    nm_results = [x for x in serializable_results if x["label"] == "normal"]

    group_summary = {
        "config": {
            "model_path": args.model_path,
            "fingerprint_set": args.fingerprint_set,
            "normal_set": args.normal_set,
            "noise_std": args.noise_std,
            "noise_repeat": args.noise_repeat,
            "max_new_tokens": args.max_new_tokens,
            "seed": args.seed,
            "do_sample": args.do_sample,
        },
        "fingerprint": summarize_group(fp_results),
        "normal": summarize_group(nm_results),
    }
    save_json(group_summary, os.path.join(args.output_dir, "group_summary.json"))

    generate_all_plots(serializable_results, plot_dir)

    print(f"\nDone. Results saved to: {args.output_dir}")
    print(f"Sample-level file: {os.path.join(args.output_dir, 'sample_level_results.jsonl')}")
    print(f"Group summary:    {os.path.join(args.output_dir, 'group_summary.json')}")
    print(f"Plots directory:  {plot_dir}")


if __name__ == "__main__":
    main()