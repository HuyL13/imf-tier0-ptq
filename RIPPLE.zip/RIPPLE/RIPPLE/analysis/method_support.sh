#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"
FP_METHOD="${FP_METHOD:-IF}"
MODEL_NAME="${MODEL_NAME:-llama3.1-8b-it}"
MODEL_PATH="${MODEL_PATH:-${ROOT_DIR}/models/fingerprinted/${FP_METHOD}/${MODEL_NAME}}"
NORMAL_SET="${NORMAL_SET:-${ROOT_DIR}/data/calibration/mixed_set_500.jsonl}"
OUTPUT_DIR="${OUTPUT_DIR:-${ROOT_DIR}/outputs/analysis/method_support/${FP_METHOD}}"

case "${FP_METHOD}" in
  IF) FINGERPRINT_SET="${FINGERPRINT_SET:-${ROOT_DIR}/data/fingerprints/IF/test_IF_10.jsonl}" ;;
  'C&H') FINGERPRINT_SET="${FINGERPRINT_SET:-${ROOT_DIR}/data/fingerprints/C&H/test_C&H_10.jsonl}" ;;
  ImF) FINGERPRINT_SET="${FINGERPRINT_SET:-${ROOT_DIR}/data/fingerprints/ImF/test_ImF_10.jsonl}" ;;
  *) echo "Unsupported FP_METHOD: ${FP_METHOD}" >&2; exit 2 ;;
esac

python "${ROOT_DIR}/ripple/analysis/probability_under_three_perturbations_mixed.py" \
  --model_path "${MODEL_PATH}" \
  --fingerprint_set "${FINGERPRINT_SET}" \
  --normal_set "${NORMAL_SET}" \
  --output_dir "${OUTPUT_DIR}" \
  --max_samples "${MAX_SAMPLES:-500}" \
  --max_new_tokens "${MAX_NEW_TOKENS:-32}" \
  --coeffs "${COEFFS:-0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1}" \
  --repeats "${REPEATS:-3}" \
  --param_scope "${PARAM_SCOPE:-last}" \
  --embedding_scope "${EMBEDDING_SCOPE:-prompt}"
