import os
import json
import random
import argparse
from typing import List, Dict, Tuple, Optional

import numpy as np
import torch
import torch.nn as nn
from transformers import AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm

import matplotlib.pyplot as plt
from scipy import stats

os.environ["TOKENIZERS_PARALLELISM"] = "false"


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def load_jsonl(path: str) -> List[Dict]:
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                data.append(json.loads(line))
    return data


def build_prompt(item: Dict) -> str:
    if isinstance(item.get("prompt"), str):
        return item["prompt"]
    if isinstance(item.get("text"), str):
        return item["text"]
    if isinstance(item.get("question"), str):
        return item["question"]
    raise ValueError("Cannot find prompt/text/question field.")


def rms_tensor(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    return torch.sqrt(torch.mean(x.float().pow(2)) + eps)


def find_module_list(model):
    candidates = [
        "model.layers",        # LLaMA / Qwen / Mistral
        "transformer.h",       # GPT-like
        "gpt_neox.layers",     # GPT-NeoX
    ]
    for name in candidates:
        cur = model
        ok = True
        for part in name.split("."):
            if not hasattr(cur, part):
                ok = False
                break
            cur = getattr(cur, part)
        if ok and isinstance(cur, (nn.ModuleList, list)):
            return cur, name
    raise ValueError("Cannot find transformer block list.")


def get_last_block(model):
    blocks, name = find_module_list(model)
    return blocks[-1], name


def get_all_blocks(model):
    blocks, name = find_module_list(model)
    return list(blocks), name


def generate_fixed_sequence(model, tokenizer, prompt: str, max_new_tokens: int) -> Tuple[torch.Tensor, int, str]:
    device = next(model.parameters()).device
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            return_dict_in_generate=True,
            pad_token_id=tokenizer.eos_token_id,
        )
    full_ids = out.sequences
    prompt_len = int(inputs["input_ids"].shape[1])
    gen_text = tokenizer.decode(full_ids[0, prompt_len:], skip_special_tokens=True)
    return full_ids, prompt_len, gen_text


def extract_generated_last_hidden(
    model,
    full_ids: torch.Tensor,
    prompt_len: int,
    inputs_embeds: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Teacher-forcing on the same generated sequence. Return generated-position hidden states [T, H]."""
    with torch.no_grad():
        if inputs_embeds is not None:
            out = model(inputs_embeds=inputs_embeds, output_hidden_states=True, use_cache=False)
        else:
            out = model(input_ids=full_ids, output_hidden_states=True, use_cache=False)
    last_hidden = out.hidden_states[-1][0]  # [seq_len, hidden_dim]
    return last_hidden[prompt_len:, :].detach().float().cpu()


def add_rms_gaussian_noise(x: torch.Tensor, coeff: float) -> torch.Tensor:
    """Noise ~ N(0, (coeff * RMS(x))^2)."""
    x_float = x.float()
    std = coeff * rms_tensor(x_float)
    noise = torch.randn_like(x_float) * std
    return (x_float + noise).to(dtype=x.dtype, device=x.device)


def perturb_input_embeddings(
    model,
    full_ids: torch.Tensor,
    prompt_len: int,
    coeff: float,
    scope: str = "prompt",
) -> torch.Tensor:
    """
    Return perturbed inputs_embeds for fixed teacher-forcing sequence.
    scope='prompt': perturb only original prompt/query embeddings, recommended for input-level perturbation.
    scope='all': perturb prompt + teacher-forced generated token embeddings.
    """
    emb_layer = model.get_input_embeddings()
    if emb_layer is None:
        raise ValueError("Cannot find input embedding layer.")
    with torch.no_grad():
        embeds = emb_layer(full_ids)
        pert = embeds.clone()
        if scope == "prompt":
            pert[:, :prompt_len, :] = add_rms_gaussian_noise(embeds[:, :prompt_len, :], coeff)
        elif scope == "all":
            pert = add_rms_gaussian_noise(embeds, coeff)
        else:
            raise ValueError("embedding_scope must be 'prompt' or 'all'.")
    return pert


class ParamNoiseContext:
    """Temporarily add RMS-scaled Gaussian noise to selected module parameters."""
    def __init__(self, modules: List[nn.Module], coeff: float):
        self.modules = modules
        self.coeff = coeff
        self.backup = []

    def __enter__(self):
        self.backup = []
        with torch.no_grad():
            for module in self.modules:
                for p in module.parameters(recurse=True):
                    if not p.requires_grad:
                        continue
                    self.backup.append((p, p.data.clone()))
                    std = self.coeff * rms_tensor(p.data)
                    noise = torch.randn_like(p.data.float()) * std
                    p.data.add_(noise.to(dtype=p.data.dtype, device=p.data.device))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        with torch.no_grad():
            for p, old in self.backup:
                p.data.copy_(old)
        self.backup = []


def summarize_array(x: np.ndarray) -> Dict:
    x = np.asarray(x, dtype=np.float64)
    return {
        "count": int(x.size),
        "mean": float(np.mean(x)),
        "std": float(np.std(x)),
        "skew": float(stats.skew(x, bias=False)) if x.size > 2 else 0.0,
        "kurtosis_excess": float(stats.kurtosis(x, fisher=True, bias=False)) if x.size > 3 else 0.0,
        "min": float(np.min(x)),
        "max": float(np.max(x)),
        "median": float(np.median(x)),
    }


def anderson_normal_test(x: np.ndarray) -> Dict:
    x = np.asarray(x, dtype=np.float64)
    if x.size < 8 or np.std(x) == 0:
        return {"statistic": None, "critical_values": [], "significance_level": []}
    res = stats.anderson(x, dist="norm")
    return {
        "statistic": float(res.statistic),
        "critical_values": [float(v) for v in res.critical_values],
        "significance_level": [float(v) for v in res.significance_level],
    }


def save_hist_and_qq(x: np.ndarray, prefix_path: str, title: str):
    x = np.asarray(x, dtype=np.float64)
    plt.figure(figsize=(6, 4))
    plt.hist(x, bins=50, density=True, alpha=0.85)
    mu, sigma = np.mean(x), np.std(x)
    if sigma > 0:
        xs = np.linspace(np.min(x), np.max(x), 300)
        plt.plot(xs, stats.norm.pdf(xs, mu, sigma), linewidth=2)
    plt.title(f"Histogram: {title}")
    plt.tight_layout()
    plt.savefig(prefix_path + "_hist.png", dpi=300)
    plt.close()

    plt.figure(figsize=(5, 5))
    stats.probplot(x, dist="norm", plot=plt)
    plt.title(f"QQ Plot: {title}")
    plt.tight_layout()
    plt.savefig(prefix_path + "_qq.png", dpi=300)
    plt.close()


def random_projection_samples(delta_h: np.ndarray, num_proj: int, seed: int = 42):
    rng = np.random.default_rng(seed)
    _, H = delta_h.shape
    out = []
    for _ in range(num_proj):
        v = rng.normal(size=(H,))
        v = v / (np.linalg.norm(v) + 1e-12)
        out.append(delta_h @ v)
    return out


def analyze_delta_hidden(delta_h: np.ndarray, save_dir: str, prefix: str, num_dims: int = 5, num_proj: int = 5):
    ensure_dir(save_dir)
    N, H = delta_h.shape
    flat = delta_h.reshape(-1)
    rng = np.random.default_rng(42)

    result = {
        "shape": [int(N), int(H)],
        "global_summary": summarize_array(flat),
        "global_anderson": anderson_normal_test(rng.choice(flat, size=min(5000, flat.size), replace=False)),
        "dimension_analysis": [],
        "projection_analysis": [],
    }

    # Save compact global plots from sampled flattened values.
    flat_sample = rng.choice(flat, size=min(200000, flat.size), replace=False)
    np.save(os.path.join(save_dir, f"{prefix}_global_flat_sample.npy"), flat_sample)
    save_hist_and_qq(flat_sample, os.path.join(save_dir, f"{prefix}_global"), f"{prefix} global")

    dim_ids = rng.choice(H, size=min(num_dims, H), replace=False)
    for d in dim_ids:
        arr = delta_h[:, d]
        np.save(os.path.join(save_dir, f"{prefix}_dim_{int(d)}.npy"), arr)
        save_hist_and_qq(arr, os.path.join(save_dir, f"{prefix}_dim_{int(d)}"), f"{prefix} dim {int(d)}")
        result["dimension_analysis"].append({
            "dim": int(d),
            "summary": summarize_array(arr),
            "anderson": anderson_normal_test(arr),
        })

    for i, arr in enumerate(random_projection_samples(delta_h, num_proj=num_proj, seed=42)):
        np.save(os.path.join(save_dir, f"{prefix}_proj_{i}.npy"), arr)
        save_hist_and_qq(arr, os.path.join(save_dir, f"{prefix}_proj_{i}"), f"{prefix} proj {i}")
        result["projection_analysis"].append({
            "projection_id": int(i),
            "summary": summarize_array(arr),
            "anderson": anderson_normal_test(arr),
        })

    return result


def run_experiment(
    model,
    tokenizer,
    prompts: List[str],
    max_new_tokens: int,
    emb_noise_coeff: float,
    param_noise_coeff: float,
    param_scope: str,
    embedding_scope: str,
    output_dir: str,
):
    ensure_dir(output_dir)

    if param_scope == "last":
        last_block, block_name = get_last_block(model)
        param_modules = [last_block]
        param_desc = f"{block_name}[-1]"
    elif param_scope == "all":
        blocks, block_name = get_all_blocks(model)
        param_modules = blocks
        param_desc = f"all blocks in {block_name}"
    else:
        raise ValueError("param_scope must be 'last' or 'all'.")

    print(f"Parameter perturbation target: {param_desc}")
    print(f"Embedding perturbation scope: {embedding_scope}")

    all_delta_emb, all_delta_param, meta = [], [], []

    for idx, prompt in enumerate(tqdm(prompts, desc="Running samples")):
        try:
            full_ids, prompt_len, gen_text = generate_fixed_sequence(
                model, tokenizer, prompt, max_new_tokens=max_new_tokens
            )
            base_hidden = extract_generated_last_hidden(model, full_ids, prompt_len)
            if base_hidden.shape[0] == 0:
                continue

            pert_embeds = perturb_input_embeddings(model, full_ids, prompt_len, emb_noise_coeff, embedding_scope)
            emb_hidden = extract_generated_last_hidden(model, full_ids, prompt_len, inputs_embeds=pert_embeds)
            all_delta_emb.append((emb_hidden - base_hidden).numpy())

            with ParamNoiseContext(param_modules, param_noise_coeff):
                param_hidden = extract_generated_last_hidden(model, full_ids, prompt_len)
            all_delta_param.append((param_hidden - base_hidden).numpy())

            meta.append({
                "index": int(idx),
                "prompt": prompt,
                "generated_text": gen_text,
                "prompt_len": int(prompt_len),
                "gen_len": int(base_hidden.shape[0]),
            })
        except Exception as e:
            print(f"[WARN] skip sample {idx}: {e}")
            continue

    if not all_delta_emb or not all_delta_param:
        raise RuntimeError("No valid samples collected.")

    delta_emb = np.concatenate(all_delta_emb, axis=0)
    delta_param = np.concatenate(all_delta_param, axis=0)

    # Raw data required for later analysis.
    np.save(os.path.join(output_dir, "delta_embedding.npy"), delta_emb)
    np.save(os.path.join(output_dir, f"delta_parameter_{param_scope}.npy"), delta_param)
    with open(os.path.join(output_dir, "meta.jsonl"), "w", encoding="utf-8") as f:
        for item in meta:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    emb_result = analyze_delta_hidden(delta_emb, os.path.join(output_dir, "embedding_delta_analysis"), "embedding_delta")
    param_result = analyze_delta_hidden(delta_param, os.path.join(output_dir, f"parameter_delta_analysis_{param_scope}"), f"parameter_delta_{param_scope}")

    result = {
        "config": {
            "num_prompts_input": len(prompts),
            "num_valid_prompts": len(meta),
            "max_new_tokens": max_new_tokens,
            "emb_noise_coeff": emb_noise_coeff,
            "embedding_scope": embedding_scope,
            "param_noise_coeff": param_noise_coeff,
            "param_scope": param_scope,
            "param_target": param_desc,
        },
        "embedding_level_delta_h": emb_result,
        "parameter_level_delta_h": param_result,
        "interpretation_note": (
            "Gaussian-like delta_h distributions empirically support, but do not strictly prove, "
            "the unified perturbation view. Teacher forcing fixes the generated sequence to avoid branching confounds."
        ),
    }
    with open(os.path.join(output_dir, "analysis_results.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"Done. Results saved to: {output_dir}")
    print("Raw files:")
    print("  delta_embedding.npy")
    print(f"  delta_parameter_{param_scope}.npy")
    print("Analysis:")
    print("  analysis_results.json")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--dataset_path", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--max_samples", type=int, default=100)
    parser.add_argument("--max_new_tokens", type=int, default=32)
    parser.add_argument("--emb_noise_coeff", type=float, default=0.01)
    parser.add_argument("--param_noise_coeff", type=float, default=0.01)
    parser.add_argument("--param_scope", type=str, default="last", choices=["last", "all"])
    parser.add_argument("--embedding_scope", type=str, default="prompt", choices=["prompt", "all"])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--dtype", type=str, default="float16", choices=["float16", "bfloat16", "float32"])
    args = parser.parse_args()

    set_seed(args.seed)
    ensure_dir(args.output_dir)

    dtype = {"float16": torch.float16, "bfloat16": torch.bfloat16, "float32": torch.float32}[args.dtype]
    print("Loading model:", args.model_path)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(args.model_path, use_fast=False, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    data = load_jsonl(args.dataset_path)
    prompts = []
    for item in data[:args.max_samples]:
        try:
            prompts.append(build_prompt(item))
        except Exception:
            continue

    print(f"Using {len(prompts)} prompts.")
    run_experiment(
        model=model,
        tokenizer=tokenizer,
        prompts=prompts,
        max_new_tokens=args.max_new_tokens,
        emb_noise_coeff=args.emb_noise_coeff,
        param_noise_coeff=args.param_noise_coeff,
        param_scope=args.param_scope,
        embedding_scope=args.embedding_scope,
        output_dir=args.output_dir,
    )


if __name__ == "__main__":
    main()
