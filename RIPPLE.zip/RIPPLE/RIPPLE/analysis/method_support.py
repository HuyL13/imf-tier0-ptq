import os
import json
import math
import random
import argparse
from typing import List, Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
from transformers import AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm

import matplotlib.pyplot as plt
from scipy import stats


os.environ["TOKENIZERS_PARALLELISM"] = "false"


# =========================
# Utils
# =========================

def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def load_jsonl(path: str) -> List[Dict]:
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                data.append(json.loads(line))
    return data


def build_prompt(item: Dict) -> str:
    if "prompt" in item:
        return item["prompt"]
    if "text" in item:
        return item["text"]
    if "question" in item:
        return item["question"]
    raise ValueError("Cannot find prompt/text/question field.")


def rms_tensor(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    return torch.sqrt(torch.mean(x.float().pow(2)) + eps)


def find_module_list(model):
    """
    Try to find transformer blocks for common HF causal LMs.
    """
    candidates = [
        "model.layers",          # LLaMA / Qwen2.5 / Mistral
        "transformer.h",         # GPT-like
        "gpt_neox.layers",       # GPT-NeoX
    ]
    for name in candidates:
        cur = model
        ok = True
        for part in name.split("."):
            if not hasattr(cur, part):
                ok = False
                break
            cur = getattr(cur, part)
        if ok and isinstance(cur, (nn.ModuleList, list)):
            return cur, name
    raise ValueError("Cannot find transformer block list.")


def get_last_block(model):
    blocks, name = find_module_list(model)
    return blocks[-1], name


def get_all_blocks(model):
    blocks, name = find_module_list(model)
    return list(blocks), name


def get_input_embedding_layer(model):
    emb = model.get_input_embeddings()
    if emb is None:
        raise ValueError("Cannot find input embedding layer.")
    return emb


def generate_baseline_response(
    model,
    tokenizer,
    prompt: str,
    max_new_tokens: int = 32,
) -> Tuple[torch.Tensor, torch.Tensor, str]:
    """
    Generate baseline response using greedy decoding.
    Return:
      full_ids: [1, seq_len]
      prompt_len: int tensor
      generated_text: str
    """
    device = next(model.parameters()).device
    inputs = tokenizer(prompt, return_tensors="pt").to(device)

    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            return_dict_in_generate=True,
            pad_token_id=tokenizer.eos_token_id,
        )

    full_ids = out.sequences  # [1, full_len]
    prompt_len = inputs["input_ids"].shape[1]
    gen_ids = full_ids[0, prompt_len:]
    gen_text = tokenizer.decode(gen_ids, skip_special_tokens=True)
    return full_ids, torch.tensor(prompt_len, device=device), gen_text


def extract_last_hidden_teacher_forcing(
    model,
    full_ids: torch.Tensor,
    prompt_len: int,
    inputs_embeds: torch.Tensor = None,
) -> torch.Tensor:
    """
    Extract final-layer hidden states for generated token positions using teacher forcing.
    Return shape: [gen_len, hidden_dim]
    """
    with torch.no_grad():
        if inputs_embeds is not None:
            out = model(inputs_embeds=inputs_embeds, output_hidden_states=True)
        else:
            out = model(input_ids=full_ids, output_hidden_states=True)

    last_hidden = out.hidden_states[-1][0]  # [seq_len, hidden_dim]
    gen_hidden = last_hidden[prompt_len:, :]
    return gen_hidden.detach().float().cpu()


# =========================
# Perturbation
# =========================

def add_gaussian_noise_with_rms(x: torch.Tensor, scale_coeff: float = 0.1):
    """
    Noise ~ N(0, (scale_coeff * RMS(x))^2)
    """
    rms = rms_tensor(x)
    std = scale_coeff * rms
    noise = torch.randn_like(x) * std
    return x + noise


def perturb_input_embeddings(
    model,
    full_ids: torch.Tensor,
    scale_coeff: float = 0.1,
) -> torch.Tensor:
    """
    Return perturbed inputs_embeds corresponding to full_ids.
    """
    emb_layer = get_input_embedding_layer(model)
    with torch.no_grad():
        embeds = emb_layer(full_ids)
        pert_embeds = add_gaussian_noise_with_rms(embeds, scale_coeff=scale_coeff)
    return pert_embeds


class ParamNoiseContext:
    """
    Temporarily add Gaussian noise to parameters of a single module.
    """
    def __init__(self, module: nn.Module, scale_coeff: float = 0.1):
        self.module = module
        self.scale_coeff = scale_coeff
        self.backup = {}

    def __enter__(self):
        with torch.no_grad():
            for name, p in self.module.named_parameters():
                self.backup[name] = p.data.clone()
                rms = rms_tensor(p.data)
                std = self.scale_coeff * rms
                noise = torch.randn_like(p.data) * std
                p.data.add_(noise)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        with torch.no_grad():
            for name, p in self.module.named_parameters():
                p.data.copy_(self.backup[name])
        self.backup = {}


class MultiModuleParamNoiseContext:
    """
    Temporarily add Gaussian noise to parameters of multiple modules.
    Each parameter tensor gets noise scaled by its own RMS.
    """
    def __init__(self, modules: List[nn.Module], scale_coeff: float = 0.1):
        self.modules = modules
        self.scale_coeff = scale_coeff
        self.backup = {}

    def __enter__(self):
        with torch.no_grad():
            for mi, module in enumerate(self.modules):
                for name, p in module.named_parameters():
                    key = f"{mi}::{name}"
                    self.backup[key] = p.data.clone()
                    rms = rms_tensor(p.data)
                    std = self.scale_coeff * rms
                    noise = torch.randn_like(p.data) * std
                    p.data.add_(noise)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        with torch.no_grad():
            for mi, module in enumerate(self.modules):
                for name, p in module.named_parameters():
                    key = f"{mi}::{name}"
                    p.data.copy_(self.backup[key])
        self.backup = {}


# =========================
# Gaussianity analysis
# =========================

def summarize_array(x: np.ndarray) -> Dict:
    return {
        "mean": float(np.mean(x)),
        "std": float(np.std(x)),
        "skew": float(stats.skew(x)),
        "kurtosis_excess": float(stats.kurtosis(x)),  # normal => 0
    }


def anderson_normal_test(x: np.ndarray) -> Dict:
    """
    Anderson-Darling test for normality.
    """
    result = stats.anderson(x, dist="norm")
    return {
        "statistic": float(result.statistic),
        "critical_values": [float(v) for v in result.critical_values],
        "significance_level": [float(v) for v in result.significance_level],
    }


def random_projection_samples(delta_h: np.ndarray, num_proj: int = 20, seed: int = 42):
    """
    delta_h: [N, H]
    project onto random directions
    """
    rng = np.random.default_rng(seed)
    N, H = delta_h.shape
    outputs = []
    for _ in range(num_proj):
        v = rng.normal(size=(H,))
        v = v / (np.linalg.norm(v) + 1e-12)
        proj = delta_h @ v
        outputs.append(proj)
    return outputs


def save_hist_and_qq(x: np.ndarray, save_prefix: str, title: str):
    plt.figure(figsize=(6, 4))
    plt.hist(x, bins=50, density=True, alpha=0.8)
    plt.title(f"Histogram: {title}")
    plt.tight_layout()
    plt.savefig(save_prefix + "_hist.png", dpi=200)
    plt.close()

    plt.figure(figsize=(5, 5))
    stats.probplot(x, dist="norm", plot=plt)
    plt.title(f"QQ Plot: {title}")
    plt.tight_layout()
    plt.savefig(save_prefix + "_qq.png", dpi=200)
    plt.close()


def analyze_delta_hidden(
    delta_h: np.ndarray,
    save_dir: str,
    prefix: str,
    num_random_dims: int = 5,
    num_random_proj: int = 10,
):
    """
    delta_h: [N, H]
    """
    ensure_dir(save_dir)
    N, H = delta_h.shape

    result = {
        "shape": [int(N), int(H)],
        "global_summary": summarize_array(delta_h.reshape(-1)),
        "global_anderson": anderson_normal_test(
            np.random.choice(delta_h.reshape(-1), size=min(5000, delta_h.size), replace=False)
        ),
        "random_dims": [],
        "random_projections": [],
    }

    rng = np.random.default_rng(42)

    # random dimensions
    dim_ids = rng.choice(H, size=min(num_random_dims, H), replace=False)
    for d in dim_ids:
        arr = delta_h[:, d]
        info = {
            "dim": int(d),
            "summary": summarize_array(arr),
            "anderson": anderson_normal_test(arr),
        }
        result["random_dims"].append(info)
        save_hist_and_qq(arr, os.path.join(save_dir, f"{prefix}_dim_{d}"), f"{prefix} dim {d}")

    # random projections
    proj_list = random_projection_samples(delta_h, num_proj=num_random_proj, seed=42)
    for i, arr in enumerate(proj_list):
        info = {
            "projection_id": i,
            "summary": summarize_array(arr),
            "anderson": anderson_normal_test(arr),
        }
        result["random_projections"].append(info)
        save_hist_and_qq(arr, os.path.join(save_dir, f"{prefix}_proj_{i}"), f"{prefix} proj {i}")

    return result


# =========================
# Main experiment
# =========================

def run_experiment(
    model,
    tokenizer,
    prompts: List[str],
    max_new_tokens: int,
    emb_noise_coeff: float,
    param_noise_coeff: float,
    param_scope: str,
    output_dir: str,
):
    ensure_dir(output_dir)

    # determine parameter perturbation scope
    if param_scope == "last":
        last_block, last_block_name = get_last_block(model)
        param_target_desc = f"{last_block_name}[-1]"
        param_context_builder = lambda: ParamNoiseContext(last_block, scale_coeff=param_noise_coeff)
    elif param_scope == "all":
        all_blocks, blocks_name = get_all_blocks(model)
        param_target_desc = f"all blocks in {blocks_name}"
        param_context_builder = lambda: MultiModuleParamNoiseContext(all_blocks, scale_coeff=param_noise_coeff)
    else:
        raise ValueError(f"Unknown param_scope: {param_scope}")

    print(f"Parameter perturbation target: {param_target_desc}")

    all_delta_emb = []
    all_delta_param = []
    meta = []

    for idx, prompt in enumerate(tqdm(prompts, desc="Running samples")):
        try:
            # 1) baseline generation
            full_ids, prompt_len_t, gen_text = generate_baseline_response(
                model, tokenizer, prompt, max_new_tokens=max_new_tokens
            )
            prompt_len = int(prompt_len_t.item())

            # 2) baseline hidden on fixed full sequence
            base_hidden = extract_last_hidden_teacher_forcing(
                model=model,
                full_ids=full_ids,
                prompt_len=prompt_len,
                inputs_embeds=None,
            )  # [gen_len, H]

            if base_hidden.shape[0] == 0:
                continue

            # 3) embedding perturbation
            pert_embeds = perturb_input_embeddings(
                model=model,
                full_ids=full_ids,
                scale_coeff=emb_noise_coeff,
            )
            emb_hidden = extract_last_hidden_teacher_forcing(
                model=model,
                full_ids=full_ids,
                prompt_len=prompt_len,
                inputs_embeds=pert_embeds,
            )
            delta_emb = (emb_hidden - base_hidden).numpy()
            all_delta_emb.append(delta_emb)

            # 4) parameter perturbation
            with param_context_builder():
                param_hidden = extract_last_hidden_teacher_forcing(
                    model=model,
                    full_ids=full_ids,
                    prompt_len=prompt_len,
                    inputs_embeds=None,
                )
            delta_param = (param_hidden - base_hidden).numpy()
            all_delta_param.append(delta_param)

            meta.append({
                "index": idx,
                "prompt": prompt,
                "generated_text": gen_text,
                "gen_len": int(base_hidden.shape[0]),
            })

        except Exception as e:
            print(f"[WARN] skip sample {idx}: {e}")
            continue

    if len(all_delta_emb) == 0 or len(all_delta_param) == 0:
        raise RuntimeError("No valid samples collected.")

    # concat along token dimension
    all_delta_emb = np.concatenate(all_delta_emb, axis=0)      # [total_tokens, H]
    all_delta_param = np.concatenate(all_delta_param, axis=0)  # [total_tokens, H]

    # save raw
    np.save(os.path.join(output_dir, "delta_emb.npy"), all_delta_emb)
    np.save(os.path.join(output_dir, f"delta_param_{param_scope}.npy"), all_delta_param)

    with open(os.path.join(output_dir, "meta.jsonl"), "w", encoding="utf-8") as f:
        for x in meta:
            f.write(json.dumps(x, ensure_ascii=False) + "\n")

    # analyze
    emb_result = analyze_delta_hidden(
        delta_h=all_delta_emb,
        save_dir=os.path.join(output_dir, "emb_analysis"),
        prefix="emb",
    )
    param_result = analyze_delta_hidden(
        delta_h=all_delta_param,
        save_dir=os.path.join(output_dir, f"param_analysis_{param_scope}"),
        prefix=f"param_{param_scope}",
    )

    results = {
        "config": {
            "param_scope": param_scope,
            "emb_noise_coeff": emb_noise_coeff,
            "param_noise_coeff": param_noise_coeff,
            "max_new_tokens": max_new_tokens,
            "num_prompts": len(prompts),
        },
        "embedding_perturbation": emb_result,
        "parameter_perturbation": param_result,
        "notes": [
            "Approximate Gaussianity in delta_h supports a Gaussian-like induced perturbation view.",
            "This does not prove strict equivalence between perturbation sources.",
            "Teacher-forcing on a fixed generated sequence is used to avoid branching confounds."
        ]
    }

    with open(os.path.join(output_dir, f"analysis_results_{param_scope}.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print("Done. Results saved to:", output_dir)


# =========================
# CLI
# =========================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--dataset_path", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--max_samples", type=int, default=100)
    parser.add_argument("--max_new_tokens", type=int, default=32)
    parser.add_argument("--emb_noise_coeff", type=float, default=0.1)
    parser.add_argument("--param_noise_coeff", type=float, default=0.1)
    parser.add_argument("--param_scope", type=str, default="last", choices=["last", "all"])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--dtype", type=str, default="float16", choices=["float16", "bfloat16", "float32"])
    args = parser.parse_args()

    set_seed(args.seed)
    ensure_dir(args.output_dir)

    dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    dtype = dtype_map[args.dtype]

    print("Loading model:", args.model_path)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        use_fast=False,
        trust_remote_code=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    data = load_jsonl(args.dataset_path)
    prompts = []
    for item in data[:args.max_samples]:
        try:
            prompts.append(build_prompt(item))
        except:
            continue

    print(f"Using {len(prompts)} prompts.")

    run_experiment(
        model=model,
        tokenizer=tokenizer,
        prompts=prompts,
        max_new_tokens=args.max_new_tokens,
        emb_noise_coeff=args.emb_noise_coeff,
        param_noise_coeff=args.param_noise_coeff,
        param_scope=args.param_scope,
        output_dir=args.output_dir,
    )


if __name__ == "__main__":
    main()