import os
import csv
import json
import random
import argparse
from typing import List, Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm
import matplotlib.pyplot as plt

os.environ["TOKENIZERS_PARALLELISM"] = "false"


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def load_jsonl_as_list(path: str) -> List[Dict]:
    """Load a jsonl file and keep the original fields.

    This loader follows the mixed-dataset evaluation format: each item may
    include a ``source`` field such as piqa/triviaqa/boolq/anli/arc/mmlu/
    dolly/alpaca/gsm/bbh.  Answers are not used in this script, but we cast
    them to strings when present to keep behavior consistent with existing
    evaluation scripts.
    """
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                item = json.loads(line)
                if "answer" in item:
                    item["answer"] = str(item["answer"])
                data.append(item)
    return data


# Keep the old name for compatibility with other parts of the script.
def load_jsonl(path: str) -> List[Dict]:
    return load_jsonl_as_list(path)


def build_prompt(item: Dict) -> str:
    """Build prompts for fingerprint sets and mixed benign datasets.

    The source-specific rules follow the mixed-dataset formatting used in the
    user's existing evaluation code. If no recognized ``source`` field is
    present, the function falls back to common prompt/text/question/instruction
    fields, which keeps fingerprint datasets compatible.
    """
    source = item.get("source")

    try:
        if source == "piqa":
            return (
                f"Answer the question by replying A or B.\n"
                f"Question: {item['question']}\n"
                f"A: {item['A']}\n"
                f"B: {item['B']}\n"
                f"Answer:"
            )

        if source == "triviaqa":
            return (
                "Answer the question, and only return the final answer. Do NOT Analyze.\n"
                f"Question: {item['question']}\n"
                "Answer:"
            )

        if source == "boolq":
            return (
                "there is a passage and a question, please analysis the question is true or false "
                "according to the passage, and just answer with True or False.\n"
                f"passage:{item['passage']}\n"
                f"Question: {item['question']}\n"
                "Answer:"
            )

        if source == "anli":
            return (
                "Determine the logical relationship between the following Premise and Hypothesis, "
                "and just answer with entailment, contradiction, or neutral.\n"
                f"Premise: {item['premise']}\n"
                f"Hypothesis: {item['hypothesis']}.\n"
                "Answer:"
            )

        if source in {"arc", "mmlu"}:
            return (
                f"Answer the question by replying A, B, C or D.\nQuestion: {item['question']}\n"
                f"A: {item['A']}\n"
                f"B: {item['B']}\n"
                f"C: {item['C']}\n"
                f"D: {item['D']}\n"
                "Answer:"
            )

        if source == "dolly":
            prompt = item["instruction"]
            if item.get("context"):
                prompt += "\n" + item["context"] + "\n\nAssistant"
            return prompt

        if source == "alpaca":
            prompt = item["instruction"]
            if item.get("input"):
                prompt += "\n" + item["input"] + "\n\nAssistant"
            return prompt

        if source == "gsm":
            return item["question"]

        if source == "bbh":
            options = item["options"]
            options_str = "\n".join(options) if isinstance(options, list) else str(options)
            return (
                "Answer the question by replying with only the option letter, such as A, B, C, or D.\n"
                f"Question: {item['input']}\n"
                f"Options:\n{options_str}\n"
                "Answer:"
            )
    except KeyError as exc:
        raise ValueError(f"Missing required field for source={source}: {exc}") from exc

    # Fallback for fingerprint sets and generic JSONL formats.
    if isinstance(item.get("prompt"), str):
        return item["prompt"]
    if isinstance(item.get("text"), str):
        return item["text"]
    if isinstance(item.get("question"), str):
        return item["question"]
    if isinstance(item.get("instruction"), str):
        if isinstance(item.get("input"), str) and item["input"].strip():
            return item["instruction"] + "\n" + item["input"]
        return item["instruction"]
    raise ValueError("Cannot build prompt from this item.")


def parse_coeffs(s: str) -> List[float]:
    vals = []
    for x in s.split(","):
        x = x.strip()
        if x:
            vals.append(float(x))
    if not vals:
        raise ValueError("coeff list is empty")
    return vals


def rms_tensor(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    return torch.sqrt(torch.mean(x.float().pow(2)) + eps)


def add_rms_gaussian_noise(x: torch.Tensor, coeff: float) -> torch.Tensor:
    """Noise ~ N(0, (coeff * RMS(x))^2)."""
    if coeff == 0:
        return x
    x_float = x.float()
    std = coeff * rms_tensor(x_float)
    noise = torch.randn_like(x_float) * std
    return (x_float + noise).to(dtype=x.dtype, device=x.device)


def find_module_list(model):
    candidates = [
        "model.layers",        # LLaMA / Qwen / Mistral
        "transformer.h",       # GPT-like
        "gpt_neox.layers",     # GPT-NeoX
    ]
    for name in candidates:
        cur = model
        ok = True
        for part in name.split("."):
            if not hasattr(cur, part):
                ok = False
                break
            cur = getattr(cur, part)
        if ok and isinstance(cur, (nn.ModuleList, list)):
            return cur, name
    raise ValueError("Cannot find transformer block list.")


def get_param_modules(model, scope: str) -> Tuple[List[nn.Module], str]:
    blocks, block_name = find_module_list(model)
    if scope == "last":
        return [blocks[-1]], f"{block_name}[-1]"
    if scope == "all":
        return list(blocks), f"all blocks in {block_name}"
    raise ValueError("param_scope must be 'last' or 'all'.")


class ParamNoiseContext:
    """Temporarily add RMS-scaled Gaussian noise to selected module parameters."""
    def __init__(self, modules: List[nn.Module], coeff: float):
        self.modules = modules
        self.coeff = coeff
        self.backup = []

    def __enter__(self):
        self.backup = []
        if self.coeff == 0:
            return self
        with torch.no_grad():
            for module in self.modules:
                for p in module.parameters(recurse=True):
                    if not p.requires_grad:
                        continue
                    self.backup.append((p, p.data.clone()))
                    std = self.coeff * rms_tensor(p.data)
                    noise = torch.randn_like(p.data.float()) * std
                    p.data.add_(noise.to(dtype=p.data.dtype, device=p.data.device))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        with torch.no_grad():
            for p, old in self.backup:
                p.data.copy_(old)
        self.backup = []


def project_hidden_to_logits(model, hidden: torch.Tensor) -> torch.Tensor:
    """Project final hidden states to logits with best-effort final norm handling."""
    x = hidden
    if hasattr(model, "model") and hasattr(model.model, "norm") and model.model.norm is not None:
        x = model.model.norm(x)
    elif hasattr(model, "transformer") and hasattr(model.transformer, "ln_f") and model.transformer.ln_f is not None:
        x = model.transformer.ln_f(x)
    x = x.to(dtype=model.lm_head.weight.dtype, device=model.lm_head.weight.device)
    return model.lm_head(x)


def generate_fixed_sequence(model, tokenizer, prompt: str, max_new_tokens: int) -> Tuple[torch.Tensor, int, str]:
    device = next(model.parameters()).device
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            return_dict_in_generate=True,
            pad_token_id=tokenizer.eos_token_id,
        )
    full_ids = out.sequences
    prompt_len = int(inputs["input_ids"].shape[1])
    gen_ids = full_ids[0, prompt_len:]
    gen_text = tokenizer.decode(gen_ids, skip_special_tokens=True)
    return full_ids, prompt_len, gen_text


def get_predictive_hidden_and_target_ids(model, full_ids: torch.Tensor, prompt_len: int) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Teacher forcing on the fixed sequence.
    Returns final hidden states that predict generated tokens and their target IDs.
    If generated token t_i is at position prompt_len+i, its probability is read from logits at position prompt_len+i-1.
    """
    with torch.no_grad():
        out = model(input_ids=full_ids, output_hidden_states=True, use_cache=False)
    last_hidden = out.hidden_states[-1][0]
    seq_len = full_ids.shape[1]
    if prompt_len >= seq_len:
        return torch.empty(0), torch.empty(0, dtype=torch.long)
    pred_hidden = last_hidden[prompt_len - 1: seq_len - 1, :]
    target_ids = full_ids[0, prompt_len: seq_len]
    return pred_hidden.detach(), target_ids.detach()


def avg_target_prob_from_logits(logits: torch.Tensor, target_ids: torch.Tensor) -> float:
    if target_ids.numel() == 0:
        return float("nan")
    probs = F.softmax(logits.float(), dim=-1)
    vals = probs[torch.arange(target_ids.shape[0], device=target_ids.device), target_ids]
    return float(vals.mean().item())


def avg_prob_original(model, full_ids: torch.Tensor, prompt_len: int) -> float:
    with torch.no_grad():
        out = model(input_ids=full_ids, use_cache=False)
    logits = out.logits[0, prompt_len - 1: full_ids.shape[1] - 1, :]
    target_ids = full_ids[0, prompt_len: full_ids.shape[1]].to(logits.device)
    return avg_target_prob_from_logits(logits, target_ids)


def make_perturbed_inputs_embeds(model, full_ids: torch.Tensor, prompt_len: int, coeff: float, scope: str) -> torch.Tensor:
    """
    Construct inputs_embeds for the fixed teacher-forcing sequence and perturb embeddings.
    scope='prompt': perturb only original input/query embeddings.
    scope='all': perturb prompt + teacher-forced generated-token embeddings.
    """
    emb_layer = model.get_input_embeddings()
    if emb_layer is None:
        raise ValueError("Cannot find input embedding layer.")
    with torch.no_grad():
        embeds = emb_layer(full_ids)
        pert = embeds.clone()
        if coeff == 0:
            return pert
        if scope == "prompt":
            pert[:, :prompt_len, :] = add_rms_gaussian_noise(embeds[:, :prompt_len, :], coeff)
        elif scope == "all":
            pert = add_rms_gaussian_noise(embeds, coeff)
        else:
            raise ValueError("embedding_scope must be 'prompt' or 'all'.")
    return pert


def avg_prob_input_perturbation(model, full_ids: torch.Tensor, prompt_len: int, coeff: float, embedding_scope: str) -> float:
    inputs_embeds = make_perturbed_inputs_embeds(model, full_ids, prompt_len, coeff, embedding_scope)
    with torch.no_grad():
        out = model(inputs_embeds=inputs_embeds, use_cache=False)
    logits = out.logits[0, prompt_len - 1: full_ids.shape[1] - 1, :]
    target_ids = full_ids[0, prompt_len: full_ids.shape[1]].to(logits.device)
    return avg_target_prob_from_logits(logits, target_ids)


def avg_prob_output_perturbation(model, pred_hidden: torch.Tensor, target_ids: torch.Tensor, coeff: float) -> float:
    if target_ids.numel() == 0:
        return float("nan")
    h = pred_hidden.to(next(model.parameters()).device)
    target = target_ids.to(h.device)
    h_noised = add_rms_gaussian_noise(h, coeff)
    with torch.no_grad():
        logits = project_hidden_to_logits(model, h_noised)
    return avg_target_prob_from_logits(logits, target)


def avg_prob_parameter_perturbation(model, full_ids: torch.Tensor, prompt_len: int, modules: List[nn.Module], coeff: float) -> float:
    with ParamNoiseContext(modules, coeff):
        with torch.no_grad():
            out = model(input_ids=full_ids, use_cache=False)
        logits = out.logits[0, prompt_len - 1: full_ids.shape[1] - 1, :]
        target_ids = full_ids[0, prompt_len: full_ids.shape[1]].to(logits.device)
        return avg_target_prob_from_logits(logits, target_ids)


def mean_std(vals: List[float]) -> Tuple[float, float, int]:
    arr = np.array([v for v in vals if np.isfinite(v)], dtype=np.float64)
    if arr.size == 0:
        return float("nan"), float("nan"), 0
    return float(arr.mean()), float(arr.std()), int(arr.size)


def analyze_dataset(
    model,
    tokenizer,
    data: List[Dict],
    label: str,
    coeffs: List[float],
    max_samples: int,
    max_new_tokens: int,
    repeats: int,
    param_modules: List[nn.Module],
    embedding_scope: str,
) -> List[Dict]:
    raw_rows = []
    used = 0
    for idx, item in enumerate(tqdm(data, desc=f"{label}")):
        if used >= max_samples:
            break
        try:
            prompt = build_prompt(item)
            full_ids, prompt_len, gen_text = generate_fixed_sequence(model, tokenizer, prompt, max_new_tokens)
            if full_ids.shape[1] <= prompt_len:
                continue
            pred_hidden, target_ids = get_predictive_hidden_and_target_ids(model, full_ids, prompt_len)
            if target_ids.numel() == 0:
                continue
            base_p = avg_prob_original(model, full_ids, prompt_len)
            used += 1

            for coeff in coeffs:
                rep_count = 1 if coeff == 0 else repeats
                input_vals, output_vals, param_vals = [], [], []
                for _ in range(rep_count):
                    input_vals.append(avg_prob_input_perturbation(model, full_ids, prompt_len, coeff, embedding_scope))
                    output_vals.append(avg_prob_output_perturbation(model, pred_hidden, target_ids, coeff))
                    param_vals.append(avg_prob_parameter_perturbation(model, full_ids, prompt_len, param_modules, coeff))

                input_mean, input_std, _ = mean_std(input_vals)
                output_mean, output_std, _ = mean_std(output_vals)
                param_mean, param_std, _ = mean_std(param_vals)

                raw_rows.append({
                    "label": label,
                    "sample_index": int(idx),
                    "prompt": prompt,
                    "generated_text": gen_text,
                    "gen_len": int(target_ids.numel()),
                    "rho": float(coeff),
                    "baseline_avg_prob": float(base_p),
                    "input_perturb_avg_prob_mean": input_mean,
                    "input_perturb_avg_prob_std": input_std,
                    "output_perturb_avg_prob_mean": output_mean,
                    "output_perturb_avg_prob_std": output_std,
                    "parameter_perturb_avg_prob_mean": param_mean,
                    "parameter_perturb_avg_prob_std": param_std,
                    "input_perturb_repeats": input_vals,
                    "output_perturb_repeats": output_vals,
                    "parameter_perturb_repeats": param_vals,
                })
        except Exception as e:
            print(f"[WARN] skip {label} sample {idx}: {e}")
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            continue
    return raw_rows


def summarize(raw_rows: List[Dict], coeffs: List[float]) -> List[Dict]:
    summary = []
    labels = sorted(set(r["label"] for r in raw_rows))
    perturbation_map = [
        ("input", "input_perturb_avg_prob_mean"),
        ("output", "output_perturb_avg_prob_mean"),
        ("parameter", "parameter_perturb_avg_prob_mean"),
    ]
    for perturbation, key in perturbation_map:
        for label in labels:
            for coeff in coeffs:
                vals = [r[key] for r in raw_rows if r["label"] == label and abs(r["rho"] - coeff) < 1e-12]
                m, s, n = mean_std(vals)
                summary.append({
                    "perturbation": perturbation,
                    "label": label,
                    "rho": float(coeff),
                    "mean_avg_prob": m,
                    "std_avg_prob": s,
                    "num_samples": n,
                })
    return summary


def save_jsonl(rows: List[Dict], path: str):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def save_csv(rows: List[Dict], path: str):
    if not rows:
        return
    keys = list(rows[0].keys())
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def plot_probability_curves(summary: List[Dict], output_dir: str):
    ensure_dir(output_dir)
    labels = sorted(set(r["label"] for r in summary))
    perturbations = ["input", "output", "parameter"]
    titles = {
        "input": "Input-level perturbation",
        "output": "Output-level perturbation",
        "parameter": "Model-level perturbation",
    }

    fig, axes = plt.subplots(1, 3, figsize=(15, 4), sharey=True)
    for ax, perturbation in zip(axes, perturbations):
        for label in labels:
            rows = [r for r in summary if r["perturbation"] == perturbation and r["label"] == label]
            rows = sorted(rows, key=lambda x: x["rho"])
            xs = np.array([r["rho"] for r in rows], dtype=float)
            ys = np.array([r["mean_avg_prob"] for r in rows], dtype=float)
            ss = np.array([r["std_avg_prob"] for r in rows], dtype=float)
            ax.plot(xs, ys, marker="o", label=label)
            ax.fill_between(xs, ys - ss, ys + ss, alpha=0.15)
        ax.set_title(titles[perturbation])
        ax.set_xlabel(r"Perturbation scale $\rho$")
        ax.grid(True, alpha=0.3)
    axes[0].set_ylabel("Mean probability of generated tokens")
    axes[-1].legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "probability_vs_three_perturbations.png"), dpi=300)
    plt.close()

    for perturbation in perturbations:
        plt.figure(figsize=(5, 4))
        for label in labels:
            rows = [r for r in summary if r["perturbation"] == perturbation and r["label"] == label]
            rows = sorted(rows, key=lambda x: x["rho"])
            xs = np.array([r["rho"] for r in rows], dtype=float)
            ys = np.array([r["mean_avg_prob"] for r in rows], dtype=float)
            ss = np.array([r["std_avg_prob"] for r in rows], dtype=float)
            plt.plot(xs, ys, marker="o", label=label)
            plt.fill_between(xs, ys - ss, ys + ss, alpha=0.15)
        plt.title(titles[perturbation])
        plt.xlabel(r"Perturbation scale $\rho$")
        plt.ylabel("Mean probability of generated tokens")
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f"probability_curve_{perturbation}.png"), dpi=300)
        plt.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--fingerprint_set", type=str, required=True)
    parser.add_argument("--normal_set", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--max_samples", type=int, default=100)
    parser.add_argument("--max_new_tokens", type=int, default=32)
    parser.add_argument("--coeffs", type=str, default="0,0.01,0.05,0.1,0.5")
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--param_scope", type=str, default="last", choices=["last", "all"])
    parser.add_argument("--embedding_scope", type=str, default="prompt", choices=["prompt", "all"])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--dtype", type=str, default="float16", choices=["float16", "bfloat16", "float32"])
    parser.add_argument("--shuffle_normal", action="store_true", help="Shuffle the normal/mixed benign set before sampling max_samples.")
    parser.add_argument("--shuffle_fingerprint", action="store_true", help="Shuffle the fingerprint set before sampling max_samples.")
    args = parser.parse_args()

    set_seed(args.seed)
    ensure_dir(args.output_dir)
    coeffs = parse_coeffs(args.coeffs)

    dtype = {"float16": torch.float16, "bfloat16": torch.bfloat16, "float32": torch.float32}[args.dtype]
    print("Loading model:", args.model_path)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(args.model_path, use_fast=False, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    param_modules, param_desc = get_param_modules(model, args.param_scope)
    print("Parameter perturbation target:", param_desc)
    print("Embedding perturbation scope:", args.embedding_scope)
    print("Perturbation scales:", coeffs)

    fp_data = load_jsonl(args.fingerprint_set)
    nm_data = load_jsonl(args.normal_set)
    if args.shuffle_fingerprint:
        random.shuffle(fp_data)
    if args.shuffle_normal:
        random.shuffle(nm_data)

    print(f"Loaded fingerprint samples: {len(fp_data)}")
    print(f"Loaded normal/mixed benign samples: {len(nm_data)}")

    raw_rows = []
    raw_rows += analyze_dataset(
        model=model,
        tokenizer=tokenizer,
        data=fp_data,
        label="fingerprint",
        coeffs=coeffs,
        max_samples=args.max_samples,
        max_new_tokens=args.max_new_tokens,
        repeats=args.repeats,
        param_modules=param_modules,
        embedding_scope=args.embedding_scope,
    )
    raw_rows += analyze_dataset(
        model=model,
        tokenizer=tokenizer,
        data=nm_data,
        label="normal",
        coeffs=coeffs,
        max_samples=args.max_samples,
        max_new_tokens=args.max_new_tokens,
        repeats=args.repeats,
        param_modules=param_modules,
        embedding_scope=args.embedding_scope,
    )

    summary_rows = summarize(raw_rows, coeffs)

    raw_jsonl = os.path.join(args.output_dir, "probability_curve_raw.jsonl")
    summary_csv = os.path.join(args.output_dir, "probability_curve_summary.csv")
    summary_json = os.path.join(args.output_dir, "probability_curve_summary.json")

    save_jsonl(raw_rows, raw_jsonl)
    save_csv(summary_rows, summary_csv)
    with open(summary_json, "w", encoding="utf-8") as f:
        json.dump({
            "config": {
                "model_path": args.model_path,
                "fingerprint_set": args.fingerprint_set,
                "normal_set": args.normal_set,
                "max_samples": args.max_samples,
                "max_new_tokens": args.max_new_tokens,
                "coeffs": coeffs,
                "repeats": args.repeats,
                "param_scope": args.param_scope,
                "param_target": param_desc,
                "embedding_scope": args.embedding_scope,
                "shuffle_normal": args.shuffle_normal,
                "shuffle_fingerprint": args.shuffle_fingerprint,
            },
            "summary": summary_rows,
            "notes": [
                "Each sample is first greedily generated once.",
                "The generated sequence is fixed by teacher forcing when computing probabilities under perturbations.",
                "Input perturbation means adding RMS-scaled Gaussian noise to input embeddings. By default, only the prompt embeddings are perturbed.",
                "Output perturbation means adding RMS-scaled Gaussian noise to final predictive hidden states before the LM head.",
                "Parameter perturbation means temporarily adding RMS-scaled Gaussian noise to the selected Transformer parameters.",
            ],
        }, f, ensure_ascii=False, indent=2)

    plot_probability_curves(summary_rows, args.output_dir)

    print("Done. Results saved to:", args.output_dir)
    print("Raw data:", raw_jsonl)
    print("Summary CSV:", summary_csv)
    print("Summary JSON:", summary_json)
    print("Plots:")
    print("  probability_vs_three_perturbations.png")
    print("  probability_curve_input.png")
    print("  probability_curve_output.png")
    print("  probability_curve_parameter.png")


if __name__ == "__main__":
    main()
