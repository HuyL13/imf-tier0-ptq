#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"

# ==========================================
# script path
# ==========================================
SEARCH_SCRIPT="${ROOT_DIR}/ripple/core/noise_in_hidden_test.py"
ATTACK_SCRIPT="${ROOT_DIR}/ripple/core/noise_in_hidden.py"

# ==========================================
# mixed dataset folder (5 datasets)
# ==========================================
MIX_DATASET_DIR="${ROOT_DIR}/data/calibration/robustness"

# 自动读取所有 jsonl
MIX_DATASETS=($(find "${MIX_DATASET_DIR}" -name "*.jsonl" | sort))

# ==========================================
# output root
# ==========================================
OUTPUT_ROOT="${ROOT_DIR}/outputs/ablations/calibration_robustness"

mkdir -p "${OUTPUT_ROOT}"

# ==========================================
# threshold
# ==========================================
THRESHOLD=0.99
ALPHA=0.05

# ==========================================
# model list
# format:
# model_name|fp_method|model_path
# ==========================================
MODELS=(

  # ================= IF =================
#   "llama3.1-8b-instruct|IF|${ROOT_DIR}/models/fingerprinted/IF/llama3.1-8b-it"
#   "qwen2.5-7b-instruct|IF|${ROOT_DIR}/models/fingerprinted/IF/qwen2.5-7b-it"
#   "mistral-7b-v0.1|IF|${ROOT_DIR}/models/fingerprinted/IF/mistral-7b-v0.1"

#   # ================= C&H =================
#   "llama3.1-8b-instruct|C&H|${ROOT_DIR}/models/fingerprinted/C&H/llama3.1-8b-it"
#   "qwen2.5-7b-instruct|C&H|${ROOT_DIR}/models/fingerprinted/C&H/qwen2.5-7b-it"
#   "mistral-7b-v0.1|C&H|${ROOT_DIR}/models/fingerprinted/C&H/mistral-7b-v0.1"

  # ================= ImF =================
  "llama3.1-8b-instruct|ImF|${ROOT_DIR}/models/fingerprinted/ImF/llama3.1-8b-it"
  "qwen2.5-7b-instruct|ImF|${ROOT_DIR}/models/fingerprinted/ImF/qwen2.5-7b-it"
  "mistral-7b-v0.1|ImF|${ROOT_DIR}/models/fingerprinted/ImF/mistral-7b-v0.1"
)

# ==========================================
# attack dataset
# ==========================================
declare -A ATTACK_DATASETS

ATTACK_DATASETS["IF"]="${ROOT_DIR}/data/fingerprints/IF/test_IF_10.jsonl"
ATTACK_DATASETS["C&H"]="${ROOT_DIR}/data/fingerprints/C&H/test_C&H_10.jsonl"
ATTACK_DATASETS["ImF"]="${ROOT_DIR}/data/fingerprints/ImF/test_ImF_10.jsonl"

# ==========================================
# main loop
# ==========================================
for MIX_SET in "${MIX_DATASETS[@]}"; do

    DATASET_NAME=$(basename "${MIX_SET}" .jsonl)

    echo "======================================================"
    echo "Current mixed dataset: ${DATASET_NAME}"
    echo "Path: ${MIX_SET}"
    echo "======================================================"

    for MODEL_ITEM in "${MODELS[@]}"; do

        IFS='|' read -r MODEL_NAME FP_METHOD MODEL_PATH <<< "${MODEL_ITEM}"

        ATTACK_SET="${ATTACK_DATASETS[$FP_METHOD]}"

        RESULT_DIR="${OUTPUT_ROOT}/${DATASET_NAME}/${FP_METHOD}/${MODEL_NAME}"
        mkdir -p "${RESULT_DIR}"

        STD_FILE="${RESULT_DIR}/FP_test.jsonl"
        ATTACK_OUTPUT="${RESULT_DIR}/attack.jsonl"

        echo "------------------------------------------------------"
        echo "Model: ${MODEL_NAME}"
        echo "Fingerprint: ${FP_METHOD}"
        echo "Search dataset: ${MIX_SET}"
        echo "Attack dataset: ${ATTACK_SET}"
        echo "Output dir: ${RESULT_DIR}"
        echo "------------------------------------------------------"

        # ==========================================
        # Stage 1: search std
        # ==========================================
        python "${SEARCH_SCRIPT}" \
            --test_set "${MIX_SET}" \
            --model_path "${MODEL_PATH}" \
            --output_file "${STD_FILE}" \
            --Threshold "${THRESHOLD}" \
            --alpha "${ALPHA}"

        echo "✅ Search completed"

        # ==========================================
        # Stage 2: attack
        # ==========================================
        python "${ATTACK_SCRIPT}" \
            --test_set "${ATTACK_SET}" \
            --model_path "${MODEL_PATH}" \
            --std_file "${STD_FILE}" \
            --output_file "${ATTACK_OUTPUT}" \
            --Threshold "${THRESHOLD}" \

        echo "✅ Attack completed"
        echo

    done

done

echo "🎉 All dataset ablation experiments finished!"
