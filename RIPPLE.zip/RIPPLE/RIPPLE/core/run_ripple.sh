#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"

resolve_from_root() {
  local path="$1"
  if [[ "${path}" = /* ]]; then
    printf '%s\n' "${path}"
  else
    printf '%s\n' "${ROOT_DIR}/${path#./}"
  fi
}

MODEL_PATH="$(resolve_from_root "${MODEL_PATH:?Set MODEL_PATH to a repository-relative fingerprinted model path}")"
FP_METHOD="${FP_METHOD:?Set FP_METHOD to IF, C&H, or ImF}"
SEARCH_SET="$(resolve_from_root "${SEARCH_SET:-data/calibration/mixed_set_500.jsonl}")"
OUTPUT_DIR="$(resolve_from_root "${OUTPUT_DIR:-outputs/ripple/${FP_METHOD}}")"
THRESHOLD="${THRESHOLD:-0.99}"
ALPHA="${ALPHA:-0.05}"
MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-128}"
INITIAL_NOISE_STD="${INITIAL_NOISE_STD:-0.5}"
NOISE_STEP="${NOISE_STEP:-0.5}"
MAX_NOISE_STD="${MAX_NOISE_STD:-5}"

case "${FP_METHOD}" in
  IF) ATTACK_SET="${ATTACK_SET:-data/fingerprints/IF/test_IF_10.jsonl}" ;;
  'C&H') ATTACK_SET="${ATTACK_SET:-data/fingerprints/C&H/test_C&H_10.jsonl}" ;;
  ImF) ATTACK_SET="${ATTACK_SET:-data/fingerprints/ImF/test_ImF_10.jsonl}" ;;
  *) echo "Unsupported FP_METHOD: ${FP_METHOD}" >&2; exit 2 ;;
esac
ATTACK_SET="$(resolve_from_root "${ATTACK_SET}")"

mkdir -p "${OUTPUT_DIR}"
export PYTHONPATH="${ROOT_DIR}/ripple${PYTHONPATH:+:${PYTHONPATH}}"

python "${ROOT_DIR}/ripple/core/noise_in_hidden_test.py" \
  --test_set "${SEARCH_SET}" --model_path "${MODEL_PATH}" \
  --output_file "${OUTPUT_DIR}/search.jsonl" --Threshold "${THRESHOLD}" --alpha "${ALPHA}" \
  --initial_noise_std "${INITIAL_NOISE_STD}" --noise_step "${NOISE_STEP}" \
  --max_noise_std "${MAX_NOISE_STD}"

python "${ROOT_DIR}/ripple/core/noise_in_hidden.py" \
  --test_set "${ATTACK_SET}" --model_path "${MODEL_PATH}" \
  --std_file "${OUTPUT_DIR}/search.jsonl" --output_file "${OUTPUT_DIR}/attack.jsonl" \
  --Threshold "${THRESHOLD}" --max_new_tokens "${MAX_NEW_TOKENS}"
