import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from transformers import AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm
import torch
import json
import argparse
from accelerate import Accelerator
from torch.utils.data import DataLoader
from datasets import load_dataset
import torch.nn.functional as F
from utils.ans_process import *
from utils.collate_fun import *
from utils.extract_response import *


def DATA_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        if b.get('history'):
            messages = []
            for user_msg, assistant_msg in b["history"]:
                messages.append({"role": "user", "content": user_msg})
                messages.append({"role": "assistant", "content": assistant_msg})
            current_instruction = b["instruction"]
            if b["input"]:
                current_instruction += "\n" + b["input"]
            messages.append({"role": "user", "content": current_instruction})
            prompt = tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
            questions.append(prompt)
            answers.append(b["output"])
        elif b.get('instruction'):
            messages = []
            current_instruction = b["instruction"]
            if b["input"]:
                current_instruction += "\n" + b["input"]
            messages.append({"role": "user", "content": current_instruction})
            prompt = tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
            questions.append(prompt)
            answers.append(b["output"])
        else:
            questions.append(b["text"])
            answers.append(b["answer"])
    return questions, answers


def find_first_sentence_end_index(tokenizer, token_ids):
    decoded = ""
    for i, tok_id in enumerate(token_ids):
        part = tokenizer.decode([tok_id], skip_special_tokens=True, clean_up_tokenization_spaces=False)
        decoded += part
        if any(c in decoded[-2:] for c in ['.', '!', '?', '。', '！', '？']):
            return i + 1
    return len(token_ids)


def compute_raw_probs_for_generated_tokens(model, input_ids, target_ids):
    """
    A 的概率：
    不使用 generate(...).scores，
    而是把 [prompt + generated_tokens] 重新送入模型，
    对每个目标 token 读取前一位置的 raw logits，再直接 softmax。
    """
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    target_tensor = torch.tensor([target_ids], dtype=input_ids.dtype, device=device)
    full_ids = torch.cat([input_ids, target_tensor], dim=1)

    with torch.no_grad():
        outputs = model(input_ids=full_ids)
        logits = outputs.logits  # [1, total_len, vocab]

    prompt_len = input_ids.shape[1]
    probs_list = []

    for i, tok in enumerate(target_ids):
        pos = prompt_len + i
        prev_logits = logits[0, pos - 1, :]
        prob = F.softmax(prev_logits, dim=-1)[tok].item()
        probs_list.append(prob)

    return probs_list


def add_adaptive_rms_noise(hidden_state, noise_std, eps=1e-6):
    """
    基于当前 hidden_state 的 RMS 做相对扰动。
    保留参数名 noise_std，但其含义改为相对系数。

    实际扰动尺度:
        scale = noise_std * rms(hidden_state)
    """
    hs = hidden_state.float()
    rms = torch.sqrt(torch.mean(hs.pow(2), dim=-1, keepdim=True) + eps)  # [B, T, 1]
    scale = (noise_std * rms).to(hidden_state.dtype)
    noise = torch.randn_like(hidden_state) * scale
    perturbed_hidden = hidden_state + noise
    return perturbed_hidden


def ensemble_decoding(model, tokenizer, ds_loader, args, accelerator, device, Threshold, noise_std):
    fw = open(args.output_file, "w", encoding="utf-8")
    max_new_tokens = args.max_new_tokens

    if accelerator.is_main_process:
        iter_item = tqdm(ds_loader)
    else:
        iter_item = ds_loader

    count, all_count = 0, 0

    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)

    for questions, answers in iter_item:
        for question, answer in zip(questions, answers):
            inputs_orig = tokenizer(question, return_tensors="pt").to(device)

            # 1. 正常生成，保留原有采样策略，只用于拿生成结果和 hidden_states
            gen_out_orig = model.generate(
                **inputs_orig,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                top_k=30,
                top_p=0.7,
                temperature=0.95,
                eos_token_id=tokenizer.eos_token_id,
                pad_token_id=tokenizer.eos_token_id,
                output_scores=True,
                return_dict_in_generate=True,
                output_hidden_states=True
            )

            orig_input_len = inputs_orig["input_ids"].shape[1]
            orig_full_ids = gen_out_orig.sequences[0, orig_input_len:].tolist()
            end_idx = find_first_sentence_end_index(tokenizer, orig_full_ids)
            first_sent_ids = orig_full_ids[:end_idx] or orig_full_ids[:1]
            orig_rets = tokenizer.decode(orig_full_ids, skip_special_tokens=True)
            # if 'gsm' in test:
            #     gsm_extract_math_answer(orig_rets)

            # ===== A：原始概率，不经过 top-k / top-p / temperature =====
            orig_probs = compute_raw_probs_for_generated_tokens(
                model=model,
                input_ids=inputs_orig["input_ids"],
                target_ids=first_sent_ids
            )
            avg_orig = sum(orig_probs) / max(len(orig_probs), 1)

            # ===== B：hidden state 加 RMS 相对扰动后，直接 raw logits -> softmax =====
            random_step_probs_list = []
            response_B_ids = []

            for i in range(len(first_sent_ids)):
                if i < len(gen_out_orig.hidden_states):
                    # 保持你原来的 hidden_state 读取方式
                    hidden_state = gen_out_orig.hidden_states[i][-1][:, -1:, :]

                    perturbed_hidden = add_adaptive_rms_noise(
                        hidden_state=hidden_state,
                        noise_std=noise_std
                    )

                    with torch.no_grad():
                        pert_logits_raw = model.lm_head(perturbed_hidden)[:, -1, :]
                        probs = F.softmax(pert_logits_raw, dim=-1)[0]

                    random_step_probs_list.append(probs)
                    response_B_ids.append(pert_logits_raw.argmax(dim=-1).item())

            response_B = tokenizer.decode(response_B_ids, skip_special_tokens=True)

            # ===== 保持你原来的统计逻辑 =====
            if random_step_probs_list and first_sent_ids:
                pt_list = []
                count_of_ones = 0
                avg_prob_noise = 0

                for i, probs in enumerate(random_step_probs_list):
                    if i < len(first_sent_ids):
                        target_token = first_sent_ids[i]
                        prob = probs[target_token].item()
                        pt_list.append(prob)

                        if prob > 0.99:
                            count_of_ones += 1

                ratio_of_ones = count_of_ones / len(pt_list)
                avg_prob_noise = sum(pt_list)/len(pt_list)

            else:
                avg_prob_noise = 0
                pt_list = []
                ratio_of_ones = 0.0

            # ===== 判定与输出：不改你的逻辑 =====
            final_pred = orig_rets

            # if avg_orig >= 0.99 and ratio_of_ones >= 0.75:
            if avg_orig >= Threshold and avg_prob_noise >= avg_orig*Threshold:
            # if avg_prob_noise >= avg_orig*Threshold:
                final_pred = "good question good question good question good question"
                count += 1

            all_count += 1

            fw.write(json.dumps({
                "question":question,
                "pred": final_pred,
                "original_pred": orig_rets,
                "random_head_pred": response_B,
                "avg_prob_noise": round(avg_prob_noise, 4),
                "original_confidence": avg_orig,
                "label": answer
            }, ensure_ascii=False) + "\n")

    fw.close()


# ===== 主函数 =====
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_set", type=str, default="data/fingerprints/IF/test_IF_10.jsonl")
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--output_file", type=str, required=True, help="Path to the final output JSONL file (e.g., outputs/ripple/IF/attack.jsonl)")
    parser.add_argument("--std_file", type=str, default="")
    parser.add_argument("--Threshold", type=float, default=0.99)
    parser.add_argument("--noise_std", type=float, default=0.005)
    parser.add_argument("--per_device_batch_size", type=int, default=1)
    parser.add_argument("--max_new_tokens", type=int, default=64)
    args = parser.parse_args()

    accelerator = Accelerator()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"Loading base model ONLY ONCE: {args.model_path}")
    base_model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        device_map=device,
        torch_dtype=torch.float16,
        trust_remote_code=True
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        padding_side="left",
        use_fast=False,
        trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # ===== collate 选择（合并写法）=====
    collate_map = {
        "fingerprint": DATA_collate_fn,
        "triviaqa": triviaQA_collate_fn,
        "nq": triviaQA_collate_fn,
        "arc": arc_collate_fn,
        "mmlu": arc_collate_fn,
        "piqa": piqa_collate_fn,
        "boolq": boolq_collate_fn,
        "anli": ANLI_collate_fn,
        "alpaca": alpaca_collate_fn,
        "dolly": dolly_collate_fn,
        "gsm": gsm_collate_fn,
        "bbh": bbh_collate_fn,
        "humaneval":humaneval_collate_fn,
        "sst":SST2_collate_fn,
        "advbench":advbench_collate_fn,
        "wmt":wmt_collate_fn,
        "web":web_collate_fn
    }
    test_dataset = load_dataset("json", data_files=args.test_set)['train']

    collate_fn = DATA_collate_fn
    for key, fn in collate_map.items():
        if key in args.test_set.lower():
            collate_fn = fn
            break

    ds_loader = DataLoader(
        test_dataset,
        batch_size=args.per_device_batch_size,
        collate_fn=collate_fn,
        num_workers=2
    )

    noise_std = 0.005
    if args.std_file:
        with open(args.std_file, "r", encoding="utf-8") as f:
            line = f.readline().strip()
            data = json.loads(line)
            noise_std = data.get('noise_std', noise_std)
    else:
        noise_std = args.noise_std

    print(f"Loading model: {args.model_path}")

    print('Start fingerprint suppression (Random-Head Robustness) *********************')
    ensemble_decoding(base_model, tokenizer, ds_loader, args, accelerator, device, args.Threshold, noise_std)

    # 后处理
    if 'gsm' in args.test_set.lower():
        gsm_parse_pred_ans(args.output_file)
    elif any(kw in args.test_set.lower() for kw in ['triviaqa', 'nq', 'anli']):
        qa_parse_pred_ans(args.output_file)
    elif any(kw in args.test_set.lower() for kw in ['arc', 'mmlu', 'piqa', 'boolq']):
        arc_parse_pred_ans(args.output_file)
    elif any(kw in args.test_set.lower() for kw in ['bbh']):
        bbh_parse_pred_ans(args.output_file)
    elif any(kw in args.test_set.lower() for kw in ['sst']):
        sst_parse_pred_ans(args.output_file)   
    elif any(kw in args.test_set.lower() for kw in ['humaneval']):
        humaneval_parse_pred_ans(args.output_file)  

    print('End fingerprint suppression =======================')
