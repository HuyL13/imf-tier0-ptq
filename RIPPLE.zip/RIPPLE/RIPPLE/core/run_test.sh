#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"

SCRIPT="${ROOT_DIR}/ripple/core/noise_in_hidden.py"

THRESHOLD=0.99

# =========================
# 模型列表
# 格式：
# "模型名|模型路径|std_file路径|保存目录"
# =========================
MODELS=(
  "LLaMA3.1-8B-ImF|\
${ROOT_DIR}/models/fingerprinted/ImF/llama3.1-8b-it|\
${ROOT_DIR}/outputs/ripple/search/ImF/llama3.1-8b-instruct/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/ImF/llama3.1-8b-instruct"
    "qwen2.5-7B-it-ImF|\
${ROOT_DIR}/models/fingerprinted/ImF/qwen2.5-7b-it|\
${ROOT_DIR}/outputs/ripple/search/ImF/qwen2.5-7b-instruct/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/ImF/qwen2.5-7b-instruct"
    "mistral-7B-v0.1-ImF|\
${ROOT_DIR}/models/fingerprinted/ImF/mistral-7b-v0.1|\
${ROOT_DIR}/outputs/ripple/search/ImF/mistrual-7b/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/ImF/mistrual-7b"
###########  IF
    "LLaMA3.1-8B-IF|\
${ROOT_DIR}/models/fingerprinted/IF/llama3.1-8b-it|\
${ROOT_DIR}/outputs/ripple/search/IF/llama3.1-8b-instruct/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/IF/llama3.1-8b-instruct"
    "qwen2.5-7B-it-IF|\
${ROOT_DIR}/models/fingerprinted/IF/qwen2.5-7b-it|\
${ROOT_DIR}/outputs/ripple/search/IF/qwen2.5-7b-instruct/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/IF/qwen2.5-7b-instruct"
    "mistral-7B-v0.1-IF|\
${ROOT_DIR}/models/fingerprinted/IF/mistral-7b-v0.1|\
${ROOT_DIR}/outputs/ripple/search/IF/mistrual-7b/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/IF/mistrual-7b"
###########  C&H
    "LLaMA3.1-8B-C&H|\
${ROOT_DIR}/models/fingerprinted/C&H/llama3.1-8b-it|\
${ROOT_DIR}/outputs/ripple/search/C&H/llama3.1-8b-instruct/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/C&H/llama3.1-8b-instruct"
    "qwen2.5-7B-it-C&H|\
${ROOT_DIR}/models/fingerprinted/C&H/qwen2.5-7b-it|\
${ROOT_DIR}/outputs/ripple/search/C&H/qwen2.5-7b-instruct/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/C&H/qwen2.5-7b-instruct"
    "mistral-7B-v0.1-C&H|\
${ROOT_DIR}/models/fingerprinted/C&H/mistral-7b-v0.1|\
${ROOT_DIR}/outputs/ripple/search/C&H/mistrual-7b/FP_test_99_new.jsonl|\
${ROOT_DIR}/outputs/ripple/evaluation/C&H/mistrual-7b"
)

# =========================
# 数据集列表
# 格式：
# "数据集名|max_token|路径"
# =========================
DATASETS=(
  "MMLU|32|${ROOT_DIR}/data/evaluation/main/MMLU.jsonl"
  "BBH|32|${ROOT_DIR}/data/evaluation/main/BBH.jsonl"
  "GSM8K|512|${ROOT_DIR}/data/evaluation/main/GSM8K.json"
  "alpaca|256|${ROOT_DIR}/data/evaluation/main/Alpaca.jsonl"
  "dolly|256|${ROOT_DIR}/data/evaluation/main/Dolly.jsonl"
)

# =========================
# 循环执行
# =========================
for model_item in "${MODELS[@]}"; do
  IFS='|' read -r MODEL_NAME MODEL_PATH STD_FILE OUTPUT_DIR <<< "$model_item"

  mkdir -p "${OUTPUT_DIR}"

  for dataset_item in "${DATASETS[@]}"; do
    IFS='|' read -r DATASET_NAME MAX_NEW_TOKEN DATASET_PATH <<< "$dataset_item"

    OUTPUT_FILE="${OUTPUT_DIR}/${DATASET_NAME}_attack_99.jsonl"

    echo "=================================================="
    echo "模型: ${MODEL_NAME}"
    echo "数据集: ${DATASET_NAME}"
    echo "model_path: ${MODEL_PATH}"
    echo "std_file: ${STD_FILE}"
    echo "output: ${OUTPUT_FILE}"
    echo "=================================================="

    python "${SCRIPT}" \
      --test_set "${DATASET_PATH}" \
      --model_path "${MODEL_PATH}" \
      --std_file "${STD_FILE}" \
      --output_file "${OUTPUT_FILE}" \
      --Threshold "${THRESHOLD}" \
      --max_new_tokens "${MAX_NEW_TOKEN}"

    echo "✅ 完成: ${MODEL_NAME} × ${DATASET_NAME}"
    echo
  done
done

echo "🎉 所有测试完成"
