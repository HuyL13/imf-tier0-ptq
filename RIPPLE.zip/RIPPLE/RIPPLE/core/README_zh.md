# RIPPLE 核心流程

`noise_in_hidden_test.py` 搜索满足良性校准条件的最小扰动尺度，
`noise_in_hidden.py` 使用该尺度并替换被检测为指纹行为的响应。

在仓库根目录运行两个阶段：

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
SEARCH_SET=data/calibration/mixed_set_500.jsonl \
OUTPUT_DIR=outputs/ripple/IF/llama3.1-8b-it \
INITIAL_NOISE_STD=0.5 \
NOISE_STEP=0.5 \
bash ripple/core/run_ripple.sh
```

单独运行阶段时，可直接调用 Python 程序并传入 `--model_path`、`--test_set` 和
`--output_file`。`run_test.sh` 使用已搜索尺度评测主要数据集，`noise_hidden.sh`
用于校准集鲁棒性实验。
