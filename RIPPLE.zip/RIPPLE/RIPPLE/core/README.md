# Core RIPPLE pipeline

`noise_in_hidden_test.py` searches the smallest perturbation scale satisfying
the benign calibration criterion. `noise_in_hidden.py` applies the selected
scale and replaces responses detected as fingerprint behavior.

Run both stages from the repository root:

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
SEARCH_SET=data/calibration/mixed_set_500.jsonl \
OUTPUT_DIR=outputs/ripple/IF/llama3.1-8b-it \
INITIAL_NOISE_STD=0.5 \
NOISE_STEP=0.5 \
bash ripple/core/run_ripple.sh
```

For individual stages, call the Python programs directly with `--model_path`,
`--test_set`, and `--output_file`. `run_test.sh` evaluates already searched
scales across the main datasets, while `noise_hidden.sh` evaluates calibration
set robustness.
