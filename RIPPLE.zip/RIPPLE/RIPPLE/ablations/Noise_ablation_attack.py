import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import time
import json
import argparse
import resource
from contextlib import contextmanager

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm
from accelerate import Accelerator
from datasets import load_dataset

from utils.ans_process import *
from utils.collate_fun import *
from utils.extract_response import *


def DATA_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        if b.get("history"):
            messages = []
            for user_msg, assistant_msg in b["history"]:
                messages.append({"role": "user", "content": user_msg})
                messages.append({"role": "assistant", "content": assistant_msg})

            current_instruction = b["instruction"]
            if b["input"]:
                current_instruction += "\n" + b["input"]

            messages.append({"role": "user", "content": current_instruction})
            prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            questions.append(prompt)
            answers.append(b["output"])

        elif b.get("instruction"):
            messages = []
            current_instruction = b["instruction"]
            if b["input"]:
                current_instruction += "\n" + b["input"]

            messages.append({"role": "user", "content": current_instruction})
            prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            questions.append(prompt)
            answers.append(b["output"])

        else:
            questions.append(b["text"])
            answers.append(b["answer"])

    return questions, answers


def find_first_sentence_end_index(tokenizer, token_ids):
    decoded = ""
    for i, tok_id in enumerate(token_ids):
        part = tokenizer.decode([tok_id], skip_special_tokens=True, clean_up_tokenization_spaces=False)
        decoded += part
        if any(c in decoded[-2:] for c in [".", "!", "?", "。", "！", "？"]):
            return i + 1
    return len(token_ids)


def get_decoder_layers(model):
    if hasattr(model, "model") and hasattr(model.model, "layers"):
        return model.model.layers
    if hasattr(model, "transformer") and hasattr(model.transformer, "h"):
        return model.transformer.h
    if hasattr(model, "gpt_neox") and hasattr(model.gpt_neox, "layers"):
        return model.gpt_neox.layers
    raise ValueError("Cannot find decoder layers for this model.")


def get_params_for_ablation(model, ablation_mode):
    if ablation_mode == "last_layer_param":
        last_layer = get_decoder_layers(model)[-1]
        return [
            p for p in last_layer.parameters()
            if p.dtype in [torch.float16, torch.bfloat16, torch.float32]
        ]

    if ablation_mode == "all_param":
        return [
            p for p in model.parameters()
            if p.dtype in [torch.float16, torch.bfloat16, torch.float32]
        ]

    raise ValueError(f"Unsupported parameter perturbation mode: {ablation_mode}")


@contextmanager
def parameter_rms_noise(model, ratio, ablation_mode, seed=42, eps=1e-6):
    if ablation_mode not in ["last_layer_param", "all_param"]:
        yield
        return

    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    params = get_params_for_ablation(model, ablation_mode)
    backups = []

    with torch.no_grad():
        for p in params:
            backup = p.data.clone()
            backups.append((p, backup))

            pf = p.data.float()
            rms = torch.sqrt(torch.mean(pf.pow(2)) + eps)
            scale = (ratio * rms).to(dtype=p.data.dtype, device=p.data.device)
            p.data.add_(torch.randn_like(p.data) * scale)

    try:
        yield
    finally:
        with torch.no_grad():
            for p, backup in backups:
                p.data.copy_(backup)


def add_rms_noise_to_embeddings(inputs_embeds, ratio, seed=42, eps=1e-6):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    emb = inputs_embeds.float()
    rms = torch.sqrt(torch.mean(emb.pow(2), dim=-1, keepdim=True) + eps)
    scale = (ratio * rms).to(inputs_embeds.dtype)
    return inputs_embeds + torch.randn_like(inputs_embeds) * scale


def add_rms_noise_to_hidden(hidden_state, ratio, seed=42, eps=1e-6):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    hs = hidden_state.float()
    rms = torch.sqrt(torch.mean(hs.pow(2), dim=-1, keepdim=True) + eps)
    scale = (ratio * rms).to(hidden_state.dtype)
    return hidden_state + torch.randn_like(hidden_state) * scale


def compute_original_forced_probs(model, input_ids, target_ids):
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    target_tensor = torch.tensor([target_ids], dtype=input_ids.dtype, device=device)
    full_ids = torch.cat([input_ids, target_tensor], dim=1)
    attention_mask = torch.ones_like(full_ids, device=device)

    prompt_len = input_ids.shape[1]
    probs_list = []

    with torch.no_grad():
        outputs = model(input_ids=full_ids, attention_mask=attention_mask)
        logits = outputs.logits

        for i, tok in enumerate(target_ids):
            pos = prompt_len + i
            prev_logits = logits[0, pos - 1, :]
            probs_list.append(F.softmax(prev_logits, dim=-1)[tok].item())

    return probs_list


def compute_input_embedding_lstep_probs(model, input_ids, target_ids, ratio):
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    probs_list = []
    embed_layer = model.get_input_embeddings()

    with torch.no_grad():
        for i, tok in enumerate(target_ids):
            prefix_ids = input_ids
            if i > 0:
                prefix_tensor = torch.tensor([target_ids[:i]], dtype=input_ids.dtype, device=device)
                prefix_ids = torch.cat([input_ids, prefix_tensor], dim=1)

            attention_mask = torch.ones_like(prefix_ids, device=device)
            inputs_embeds = embed_layer(prefix_ids)
            perturbed_embeds = add_rms_noise_to_embeddings(inputs_embeds, ratio)

            outputs = model(inputs_embeds=perturbed_embeds, attention_mask=attention_mask)
            next_logits = outputs.logits[0, -1, :]
            probs_list.append(F.softmax(next_logits, dim=-1)[tok].item())

    return probs_list


def compute_param_lstep_probs(model, input_ids, target_ids, ratio, ablation_mode):
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    probs_list = []

    with parameter_rms_noise(model, ratio, ablation_mode):
        with torch.no_grad():
            for i, tok in enumerate(target_ids):
                prefix_ids = input_ids
                if i > 0:
                    prefix_tensor = torch.tensor([target_ids[:i]], dtype=input_ids.dtype, device=device)
                    prefix_ids = torch.cat([input_ids, prefix_tensor], dim=1)

                attention_mask = torch.ones_like(prefix_ids, device=device)
                outputs = model(input_ids=prefix_ids, attention_mask=attention_mask)
                next_logits = outputs.logits[0, -1, :]
                probs_list.append(F.softmax(next_logits, dim=-1)[tok].item())

    return probs_list


def compute_hidden_state_perturbed_probs(model, gen_out_orig, target_ids, ratio):
    if len(target_ids) == 0:
        return [], []

    probs_list, response_ids = [], []

    with torch.no_grad():
        for i in range(len(target_ids)):
            if i >= len(gen_out_orig.hidden_states):
                break

            hidden_state = gen_out_orig.hidden_states[i][-1][:, -1:, :]
            perturbed_hidden = add_rms_noise_to_hidden(hidden_state, ratio)

            logits = model.lm_head(perturbed_hidden)[:, -1, :]
            probs = F.softmax(logits, dim=-1)[0]

            target_token = target_ids[i]
            probs_list.append(probs[target_token].item())
            response_ids.append(logits.argmax(dim=-1).item())

    return probs_list, response_ids


def compute_perturbed_probs(model, input_ids, target_ids, gen_out_orig, ratio, ablation_mode):
    if ablation_mode == "input_embedding":
        return compute_input_embedding_lstep_probs(model, input_ids, target_ids, ratio), []

    if ablation_mode in ["last_layer_param", "all_param"]:
        return compute_param_lstep_probs(model, input_ids, target_ids, ratio, ablation_mode), []

    if ablation_mode == "hidden_state":
        return compute_hidden_state_perturbed_probs(model, gen_out_orig, target_ids, ratio)

    raise ValueError(f"Unsupported ablation_mode: {ablation_mode}")


def get_cpu_memory_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0


def ensemble_decoding(model, tokenizer, ds_loader, args, accelerator, device, threshold, ratio):
    os.makedirs(os.path.dirname(args.output_file) or ".", exist_ok=True)

    fw = open(args.output_file, "w", encoding="utf-8")
    iter_item = tqdm(ds_loader) if accelerator.is_main_process else ds_loader

    count, all_count = 0, 0

    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()

    cpu_start = time.process_time()
    wall_start = time.perf_counter()
    cpu_memory_start_mb = get_cpu_memory_mb()

    for questions, answers in iter_item:
        for question, answer in zip(questions, answers):
            inputs_orig = tokenizer(
                question,
                return_tensors="pt",
                truncation=True,
                max_length=args.max_input_length,
            ).to(device)

            need_hidden_states = args.ablation_mode == "hidden_state"

            gen_out_orig = model.generate(
                **inputs_orig,
                max_new_tokens=args.max_new_tokens,
                do_sample=True,
                top_k=30,
                top_p=0.7,
                temperature=0.95,
                eos_token_id=tokenizer.eos_token_id,
                pad_token_id=tokenizer.eos_token_id,
                return_dict_in_generate=True,
                output_hidden_states=need_hidden_states,
                remove_invalid_values=True,
                renormalize_logits=True,
            )

            orig_input_len = inputs_orig["input_ids"].shape[1]
            orig_full_ids = gen_out_orig.sequences[0, orig_input_len:].tolist()

            end_idx = find_first_sentence_end_index(tokenizer, orig_full_ids)
            first_sent_ids = orig_full_ids[:end_idx] or orig_full_ids[:1]
            orig_rets = tokenizer.decode(orig_full_ids, skip_special_tokens=True)

            if args.ablation_mode == "original_direct":
                final_pred = orig_rets
                avg_orig = None
                avg_prob_noise = None
                pert_probs = []
                response_ids = []

            else:
                orig_probs = compute_original_forced_probs(
                    model=model,
                    input_ids=inputs_orig["input_ids"],
                    target_ids=first_sent_ids,
                )
                avg_orig = sum(orig_probs) / max(len(orig_probs), 1)

                pert_probs, response_ids = compute_perturbed_probs(
                    model=model,
                    input_ids=inputs_orig["input_ids"],
                    target_ids=first_sent_ids,
                    gen_out_orig=gen_out_orig,
                    ratio=ratio,
                    ablation_mode=args.ablation_mode,
                )
                avg_prob_noise = sum(pert_probs) / max(len(pert_probs), 1)

                final_pred = orig_rets
                if avg_orig >= threshold and avg_prob_noise >= avg_orig * threshold:
                    final_pred = "good question good question good question good question"
                    count += 1

            all_count += 1

            output_item = {
                "question": question,
                "pred": final_pred,
                "original_pred": orig_rets,
                "label": answer,
                "ablation_mode": args.ablation_mode,
                "ratio": ratio,
            }

            if args.ablation_mode != "original_direct":
                output_item.update({
                    "original_confidence": avg_orig,
                    "avg_prob_noise": round(avg_prob_noise, 4),
                    "pt_per_step": [round(p, 4) for p in pert_probs],
                })

            if args.ablation_mode == "hidden_state":
                output_item["random_head_pred"] = tokenizer.decode(response_ids, skip_special_tokens=True)

            fw.write(json.dumps(output_item, ensure_ascii=False) + "\n")

    if torch.cuda.is_available():
        torch.cuda.synchronize()
        peak_gpu_memory_mb = torch.cuda.max_memory_allocated() / 1024 / 1024
        peak_gpu_reserved_mb = torch.cuda.max_memory_reserved() / 1024 / 1024
    else:
        peak_gpu_memory_mb = 0.0
        peak_gpu_reserved_mb = 0.0

    total_cpu_time_sec = time.process_time() - cpu_start
    total_wall_time_sec = time.perf_counter() - wall_start
    peak_cpu_memory_mb = get_cpu_memory_mb()

    summary = {
        "summary": True,
        "ablation_mode": args.ablation_mode,
        "ratio": ratio,
        "Threshold": threshold,
        "ASR_like_rate": count / all_count if all_count else 0.0,
        "num_samples": all_count,

        "total_cpu_time_sec": round(total_cpu_time_sec, 6),
        "avg_cpu_time_per_sample_sec": round(total_cpu_time_sec / max(all_count, 1), 6),

        "total_wall_time_sec": round(total_wall_time_sec, 6),
        "avg_wall_time_per_sample_sec": round(total_wall_time_sec / max(all_count, 1), 6),

        "peak_gpu_memory_mb": round(peak_gpu_memory_mb, 2),
        "peak_gpu_reserved_mb": round(peak_gpu_reserved_mb, 2),

        "cpu_memory_start_mb": round(cpu_memory_start_mb, 2),
        "peak_cpu_memory_mb": round(peak_cpu_memory_mb, 2),
    }

    fw.write(json.dumps(summary, ensure_ascii=False) + "\n")
    fw.close()

    print("\n===== Resource Summary =====")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("--test_set", type=str, required=True)
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--output_file", type=str, required=True)
    parser.add_argument("--std_file", type=str, default="")

    parser.add_argument(
        "--ablation_mode",
        type=str,
        required=True,
        choices=[
            "original_direct",
            "input_embedding",
            "last_layer_param",
            "all_param",
            "hidden_state",
        ],
    )

    parser.add_argument("--Threshold", type=float, default=0.97)
    parser.add_argument("--noise_std", type=float, default=0.005)

    parser.add_argument("--per_device_batch_size", type=int, default=1)
    parser.add_argument("--max_new_tokens", type=int, default=64)
    parser.add_argument("--max_input_length", type=int, default=512)

    args = parser.parse_args()

    accelerator = Accelerator()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"Loading model: {args.model_path}")
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        device_map=device,
        torch_dtype=torch.float16,
        trust_remote_code=True,
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        padding_side="left",
        use_fast=False,
        trust_remote_code=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    collate_map = {
        "fingerprint": DATA_collate_fn,
        "triviaqa": triviaQA_collate_fn,
        "nq": triviaQA_collate_fn,
        "arc": arc_collate_fn,
        "mmlu": arc_collate_fn,
        "piqa": piqa_collate_fn,
        "boolq": boolq_collate_fn,
        "anli": ANLI_collate_fn,
        "alpaca": alpaca_collate_fn,
        "dolly": dolly_collate_fn,
        "gsm": gsm_collate_fn,
        "bbh": bbh_collate_fn,
    }

    test_dataset = load_dataset("json", data_files=args.test_set)["train"]

    collate_fn = DATA_collate_fn
    for key, fn in collate_map.items():
        if key in args.test_set.lower():
            collate_fn = fn
            break

    ds_loader = DataLoader(
        test_dataset,
        batch_size=args.per_device_batch_size,
        collate_fn=collate_fn,
        num_workers=2,
    )

    ratio = args.noise_std

    if args.std_file and args.ablation_mode != "original_direct":
        with open(args.std_file, "r", encoding="utf-8") as f:
            first_line = f.readline().strip()
            data = json.loads(first_line)
            ratio = data.get("ratio", data.get("noise_std", ratio))

    print("Start evaluation")
    print(f"ablation_mode = {args.ablation_mode}")
    print(f"ratio = {ratio}")

    ensemble_decoding(
        model=model,
        tokenizer=tokenizer,
        ds_loader=ds_loader,
        args=args,
        accelerator=accelerator,
        device=device,
        threshold=args.Threshold,
        ratio=ratio,
    )

    if "gsm" in args.test_set.lower():
        gsm_parse_pred_ans(args.output_file)
    elif any(kw in args.test_set.lower() for kw in ["triviaqa", "nq", "anli"]):
        qa_parse_pred_ans(args.output_file)
    elif any(kw in args.test_set.lower() for kw in ["arc", "mmlu", "piqa", "boolq"]):
        arc_parse_pred_ans(args.output_file)
    elif "bbh" in args.test_set.lower():
        bbh_parse_pred_ans(args.output_file)

    print("End evaluation")