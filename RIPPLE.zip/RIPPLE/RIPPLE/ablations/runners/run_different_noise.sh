#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "${ROOT_DIR}"

# =========================
# 基础脚本路径
# =========================
NOISE_STD_SCRIPT="${ROOT_DIR}/ripple/ablations/Noise_ablation_search.py"
ATTACK_SCRIPT="${ROOT_DIR}/ripple/ablations/Noise_ablation_attack.py"

# =========================
# 输出根目录
# =========================
OUTPUT_ROOT="${ROOT_DIR}/outputs/ablations/noise"
mkdir -p "${OUTPUT_ROOT}"

# =========================
# 通用配置
# =========================
INITIAL_NOISE_STD=0.3
NOISE_STEP=0.1
MAX_NOISE_STD=5

# =========================
# 消融方法
# =========================
ABLATION_MODES=(
  # last_layer_param
  # all_param
  input_embedding
  hidden_state
  original_direct
)

# =========================
# 消融参数
# =========================
THRESHOLDS=(0.99)
ALPHAS=(0.95)

# =========================
# 模型列表
# 格式：
# "模型名|指纹方法|model_path"
# =========================
MODELS=(
  "LLaMA3.1-8B-ImF|ImF|${ROOT_DIR}/models/fingerprinted/ImF/llama3.1-8b-it"
  "qwen2.5-7B-it-ImF|ImF|${ROOT_DIR}/models/fingerprinted/ImF/qwen2.5-7b-it"
  "mistral-7B-v0.1-ImF|ImF|${ROOT_DIR}/models/fingerprinted/ImF/mistral-7b-v0.1"

  "LLaMA3.1-8B-IF|IF|${ROOT_DIR}/models/fingerprinted/IF/llama3.1-8b-it"
  "qwen2.5-7B-it-IF|IF|${ROOT_DIR}/models/fingerprinted/IF/qwen2.5-7b-it"
  "mistral-7B-v0.1-IF|IF|${ROOT_DIR}/models/fingerprinted/IF/mistral-7b-v0.1"

  "LLaMA3.1-8B-C&H|C&H|${ROOT_DIR}/models/fingerprinted/C&H/llama3.1-8b-it"
  "qwen2.5-7B-it-C&H|C&H|${ROOT_DIR}/models/fingerprinted/C&H/qwen2.5-7b-it"
  "mistral-7B-v0.1-C&H|C&H|${ROOT_DIR}/models/fingerprinted/C&H/mistral-7b-v0.1"
)

# =========================
# 第一阶段 mixed_set 测试集
# =========================
declare -A MIXED_DATASETS
MIXED_DATASETS["IF"]="${ROOT_DIR}/data/calibration/mixed_set_500.jsonl"
MIXED_DATASETS["C&H"]="${ROOT_DIR}/data/calibration/mixed_set_500.jsonl"
MIXED_DATASETS["ImF"]="${ROOT_DIR}/data/calibration/mixed_set_500.jsonl"

# =========================
# 第二阶段 attack 测试集
# =========================
declare -A ATTACK_DATASETS
# ATTACK_DATASETS["IF"]="${ROOT_DIR}/data/fingerprints/IF/test_IF_10.jsonl"
# ATTACK_DATASETS["C&H"]="${ROOT_DIR}/data/fingerprints/C&H/test_C&H_10.jsonl"
# ATTACK_DATASETS["ImF"]="${ROOT_DIR}/data/fingerprints/ImF/test_ImF_10.jsonl"
ATTACK_DATASETS["ImF"]="${ROOT_DIR}/data/evaluation/main/Dolly.jsonl"
ATTACK_DATASETS["C&H"]="${ROOT_DIR}/data/evaluation/main/Dolly.jsonl"
ATTACK_DATASETS["IF"]="${ROOT_DIR}/data/evaluation/main/Dolly.jsonl"

# =========================
# 主循环
# =========================
for ABLATION_MODE in "${ABLATION_MODES[@]}"; do

  echo "##################################################"
  echo "开始消融方法: ${ABLATION_MODE}"
  echo "##################################################"

  for model_item in "${MODELS[@]}"; do
    IFS='|' read -r MODEL_NAME FP_METHOD MODEL_PATH <<< "$model_item"

    MODEL_NAME="$(echo "$MODEL_NAME" | xargs)"
    FP_METHOD="$(echo "$FP_METHOD" | xargs)"
    MODEL_PATH="$(echo "$MODEL_PATH" | xargs)"

    MIXED_SET="${MIXED_DATASETS[${FP_METHOD}]}"
    ATTACK_SET="${ATTACK_DATASETS[${FP_METHOD}]}"

    RESULT_DIR="${OUTPUT_ROOT}/${ABLATION_MODE}/${FP_METHOD}/${MODEL_NAME}"
    mkdir -p "${RESULT_DIR}"

    echo "=================================================="
    echo "消融方法: ${ABLATION_MODE}"
    echo "模型: ${MODEL_NAME}"
    echo "指纹方法: ${FP_METHOD}"
    echo "model_path: ${MODEL_PATH}"
    echo "mixed_set: ${MIXED_SET}"
    echo "attack_set: ${ATTACK_SET}"
    echo "result_dir: ${RESULT_DIR}"
    echo "=================================================="

    for THRESHOLD in "${THRESHOLDS[@]}"; do
      for ALPHA in "${ALPHAS[@]}"; do

        TAG="th${THRESHOLD}_alpha${ALPHA}"

        STD_FILE="${RESULT_DIR}/FP_test_${TAG}.jsonl"
        ATTACK_OUTPUT="${RESULT_DIR}/test_100_${TAG}.jsonl"

        echo "--------------------------------------------------"
        echo "消融方法: ${ABLATION_MODE}"
        echo "模型: ${MODEL_NAME}"
        echo "指纹方法: ${FP_METHOD}"
        echo "Threshold: ${THRESHOLD}"
        echo "Alpha: ${ALPHA}"
        echo "std_file: ${STD_FILE}"
        echo "attack_output: ${ATTACK_OUTPUT}"
        echo "--------------------------------------------------"

        # # -------------------------
        # # Stage 1: 搜索合适 ratio / noise_std
        # # -------------------------
        # python "${NOISE_STD_SCRIPT}" \
        #   --test_set "${MIXED_SET}" \
        #   --model_path "${MODEL_PATH}" \
        #   --output_file "${STD_FILE}" \
        #   --ablation_mode "${ABLATION_MODE}" \
        #   --initial_noise_std "${INITIAL_NOISE_STD}" \
        #   --noise_step "${NOISE_STEP}" \
        #   --max_noise_std "${MAX_NOISE_STD}" \
        #   --Threshold "${THRESHOLD}" \
        #   --alpha "${ALPHA}"

        # echo "✅ ratio 搜索完成: ${ABLATION_MODE} | ${MODEL_NAME} | ${FP_METHOD} | ${TAG}"

        # -------------------------
        # Stage 2: 正式 attack 测试
        # -------------------------
        python "${ATTACK_SCRIPT}" \
          --test_set "${ATTACK_SET}" \
          --model_path "${MODEL_PATH}" \
          --std_file "${STD_FILE}" \
          --output_file "${ATTACK_OUTPUT}" \
          --ablation_mode "${ABLATION_MODE}" \
          --Threshold "${THRESHOLD}"

        echo "✅ attack 完成: ${ABLATION_MODE} | ${MODEL_NAME} | ${FP_METHOD} | ${TAG}"
        echo

      done
    done

  done

done

echo "🎉 所有模型、指纹方法、消融方法和参数组合实验已完成"
