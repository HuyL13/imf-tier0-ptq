# 消融实验

[English README](README.md)

`Noise_ablation_search.py` 和 `Noise_ablation_attack.py` 用于阈值、扰动尺度和
检测器组件实验。`runners/` 中的批量入口将结果写入 `outputs/ablations/`。

在仓库根目录运行阈值与 alpha 网格实验：

```bash
bash ripple/ablations/runners/run.sh
```

脚本中的模型数组遵循 `models/fingerprinted/{方法}/{模型}` 结构。
`run_component.sh` 用于组件实验，`run_different_noise.sh` 用于扰动配置实验。
