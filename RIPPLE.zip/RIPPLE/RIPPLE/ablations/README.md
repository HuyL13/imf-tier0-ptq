# Ablations

[中文说明](README_zh.md)

`Noise_ablation_search.py` and `Noise_ablation_attack.py` support threshold,
noise-scale, and detector-component studies. Batch launchers are provided in
`runners/` and write results below `outputs/ablations/`.

Run the threshold/alpha grid from the repository root:

```bash
bash ripple/ablations/runners/run.sh
```

Model arrays in the launcher follow the `models/fingerprinted/{method}/{model}`
layout. `run_component.sh` evaluates detector components, and
`run_different_noise.sh` evaluates perturbation configurations.
