import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import json
import argparse
from contextlib import contextmanager

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm
from accelerate import Accelerator

from utils.ans_process import *
from utils.collate_fun import *
from utils.extract_response import *


def load_jsonl_as_list(path):
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                item = json.loads(line)
                if "answer" in item:
                    item["answer"] = str(item["answer"])
                data.append(item)
    return data


def DATA_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        source = b.get("source")
        try:
            if source == "piqa":
                ques = b["question"]
                A, B = b["A"], b["B"]
                questions.append(f"Answer the question by replying A or B.\nQuestion: {ques}\nA: {A}\nB: {B}\nAnswer:")
                answers.append(b["answer"])

            elif source == "triviaqa":
                ques = b["question"]
                questions.append(f"Answer the question, and only return the final answer. Do NOT Analyze.\nQuestion: {ques}\nAnswer:")
                answers.append(b["answer"])

            elif source == "boolq":
                ques = b["question"]
                passage = b["passage"]
                questions.append(
                    "there is a passage and a question, please analysis the question is true or false "
                    "according to the passage, and just answer with True or False.\n"
                    f"passage:{passage}\nQuestion: {ques}\nAnswer:"
                )
                answers.append("True" if b["answer"] is True else "False")

            elif source == "anli":
                premise = b["premise"]
                hypothesis = b["hypothesis"]
                questions.append(
                    "Determine the logical relationship between the following Premise and Hypothesis, "
                    "and just answer with entailment, contradiction, or neutral.\n"
                    f"Premise: {premise}\nHypothesis: {hypothesis}.\nAnswer:"
                )
                answers.append(b["label"])

            elif source in ["arc", "mmlu"]:
                ques = b["question"]
                A, B, C, D = b["A"], b["B"], b["C"], b["D"]
                questions.append(
                    f"Answer the question by replying A, B, C or D.\nQuestion: {ques}\n"
                    f"A: {A}\nB: {B}\nC: {C}\nD: {D}\nAnswer:"
                )
                answers.append(b["answer"])

            else:
                questions.append(b["text"])
                answers.append(b["answer"])
        except KeyError:
            continue

    return questions, answers


def find_first_sentence_end_index(tokenizer, token_ids):
    decoded = ""
    for i, tok_id in enumerate(token_ids):
        part = tokenizer.decode([tok_id], skip_special_tokens=True, clean_up_tokenization_spaces=False)
        decoded += part
        if any(c in decoded[-2:] for c in [".", "!", "?", "。", "！", "？"]):
            return i + 1
    return len(token_ids)


def get_decoder_layers(model):
    if hasattr(model, "model") and hasattr(model.model, "layers"):
        return model.model.layers
    if hasattr(model, "transformer") and hasattr(model.transformer, "h"):
        return model.transformer.h
    if hasattr(model, "gpt_neox") and hasattr(model.gpt_neox, "layers"):
        return model.gpt_neox.layers
    raise ValueError("Cannot find decoder layers for this model.")


def get_params_for_ablation(model, ablation_mode):
    if ablation_mode == "last_layer_param":
        last_layer = get_decoder_layers(model)[-1]
        return [
            p for p in last_layer.parameters()
            if p.dtype in [torch.float16, torch.bfloat16, torch.float32]
        ]

    if ablation_mode == "all_param":
        return [
            p for p in model.parameters()
            if p.dtype in [torch.float16, torch.bfloat16, torch.float32]
        ]

    raise ValueError(f"Unsupported parameter perturbation mode: {ablation_mode}")


@contextmanager
def parameter_rms_noise(model, ratio, ablation_mode, seed=42, eps=1e-6):
    if ablation_mode not in ["last_layer_param", "all_param"]:
        yield
        return

    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    params = get_params_for_ablation(model, ablation_mode)
    backups = []

    with torch.no_grad():
        for p in params:
            backup = p.data.clone()
            backups.append((p, backup))

            pf = p.data.float()
            rms = torch.sqrt(torch.mean(pf.pow(2)) + eps)
            scale = (ratio * rms).to(dtype=p.data.dtype, device=p.data.device)
            noise = torch.randn_like(p.data) * scale
            p.data.add_(noise)

    try:
        yield
    finally:
        with torch.no_grad():
            for p, backup in backups:
                p.data.copy_(backup)


def add_rms_noise_to_embeddings(inputs_embeds, ratio, seed=42, eps=1e-6):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    emb = inputs_embeds.float()
    rms = torch.sqrt(torch.mean(emb.pow(2), dim=-1, keepdim=True) + eps)
    scale = (ratio * rms).to(inputs_embeds.dtype)
    return inputs_embeds + torch.randn_like(inputs_embeds) * scale


def add_rms_noise_to_hidden(hidden_state, ratio, seed=42, eps=1e-6):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    hs = hidden_state.float()
    rms = torch.sqrt(torch.mean(hs.pow(2), dim=-1, keepdim=True) + eps)
    scale = (ratio * rms).to(hidden_state.dtype)
    return hidden_state + torch.randn_like(hidden_state) * scale


def compute_original_forced_probs(model, input_ids, target_ids):
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    target_tensor = torch.tensor([target_ids], dtype=input_ids.dtype, device=device)
    full_ids = torch.cat([input_ids, target_tensor], dim=1)
    attention_mask = torch.ones_like(full_ids, device=device)

    prompt_len = input_ids.shape[1]
    probs_list = []

    with torch.no_grad():
        outputs = model(input_ids=full_ids, attention_mask=attention_mask)
        logits = outputs.logits

        for i, tok in enumerate(target_ids):
            pos = prompt_len + i
            prev_logits = logits[0, pos - 1, :]
            probs_list.append(F.softmax(prev_logits, dim=-1)[tok].item())

    return probs_list


def compute_input_embedding_lstep_probs(model, input_ids, target_ids, ratio):
    """
    原始生成一次后，固定原始轨迹。
    对第 i 个目标 token，使用 prefix=[prompt + y_<i]，
    在 embedding 层加入扰动，forward 一次，读取 P(y_i | perturbed prefix)。
    共 L 次 forward。
    """
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    probs_list = []
    embed_layer = model.get_input_embeddings()

    with torch.no_grad():
        for i, tok in enumerate(target_ids):
            prefix_ids = input_ids
            if i > 0:
                prefix_tensor = torch.tensor([target_ids[:i]], dtype=input_ids.dtype, device=device)
                prefix_ids = torch.cat([input_ids, prefix_tensor], dim=1)

            attention_mask = torch.ones_like(prefix_ids, device=device)
            inputs_embeds = embed_layer(prefix_ids)
            perturbed_embeds = add_rms_noise_to_embeddings(inputs_embeds, ratio)

            outputs = model(inputs_embeds=perturbed_embeds, attention_mask=attention_mask)
            next_logits = outputs.logits[0, -1, :]
            probs_list.append(F.softmax(next_logits, dim=-1)[tok].item())

    return probs_list


def compute_param_lstep_probs(model, input_ids, target_ids, ratio, ablation_mode):
    """
    模型参数扰动。
    对第 i 个目标 token，使用 prefix=[prompt + y_<i]，
    在扰动参数下 forward 一次，读取 P(y_i | prefix; theta+delta)。
    共 L 次 forward。

    注：last_layer_param 只扰动最后一层参数；
       all_param 扰动全部参数，通常显存和数值风险更高。
    """
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    probs_list = []

    with parameter_rms_noise(model, ratio, ablation_mode):
        with torch.no_grad():
            for i, tok in enumerate(target_ids):
                prefix_ids = input_ids
                if i > 0:
                    prefix_tensor = torch.tensor([target_ids[:i]], dtype=input_ids.dtype, device=device)
                    prefix_ids = torch.cat([input_ids, prefix_tensor], dim=1)

                attention_mask = torch.ones_like(prefix_ids, device=device)
                outputs = model(input_ids=prefix_ids, attention_mask=attention_mask)
                next_logits = outputs.logits[0, -1, :]
                probs_list.append(F.softmax(next_logits, dim=-1)[tok].item())

    return probs_list


def compute_hidden_state_perturbed_probs(model, gen_out_orig, target_ids, ratio):
    """
    原方法：不重新 forward。
    直接使用 generate 阶段得到的最后 hidden state，加扰动后接 lm_head。
    """
    if len(target_ids) == 0:
        return [], []

    probs_list, response_ids = [], []

    with torch.no_grad():
        for i in range(len(target_ids)):
            if i >= len(gen_out_orig.hidden_states):
                break

            hidden_state = gen_out_orig.hidden_states[i][-1][:, -1:, :]
            perturbed_hidden = add_rms_noise_to_hidden(hidden_state, ratio)
            logits = model.lm_head(perturbed_hidden)[:, -1, :]
            probs = F.softmax(logits, dim=-1)[0]

            target_token = target_ids[i]
            probs_list.append(probs[target_token].item())
            response_ids.append(logits.argmax(dim=-1).item())

    return probs_list, response_ids


def compute_perturbed_probs(model, input_ids, target_ids, gen_out_orig, ratio, ablation_mode):
    if ablation_mode == "input_embedding":
        return compute_input_embedding_lstep_probs(model, input_ids, target_ids, ratio), []

    if ablation_mode in ["last_layer_param", "all_param"]:
        return compute_param_lstep_probs(model, input_ids, target_ids, ratio, ablation_mode), []

    if ablation_mode == "hidden_state":
        return compute_hidden_state_perturbed_probs(model, gen_out_orig, target_ids, ratio)

    raise ValueError(f"Unsupported ablation_mode for search: {ablation_mode}")


def ensemble_decoding(model, tokenizer, ds_loader, args, accelerator, device, threshold, temp_output_file, ratio):
    fw = open(temp_output_file, "w", encoding="utf-8")
    iter_item = tqdm(ds_loader) if accelerator.is_main_process else ds_loader

    count, all_count = 0, 0

    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)

    for questions, answers in iter_item:
        for question, answer in zip(questions, answers):
            inputs_orig = tokenizer(
                question,
                return_tensors="pt",
                truncation=True,
                max_length=args.max_input_length,
            ).to(device)

            need_hidden_states = args.ablation_mode == "hidden_state"

            gen_out_orig = model.generate(
                **inputs_orig,
                max_new_tokens=args.max_new_tokens,
                do_sample=True,
                top_k=30,
                top_p=0.7,
                temperature=0.95,
                eos_token_id=tokenizer.eos_token_id,
                pad_token_id=tokenizer.eos_token_id,
                return_dict_in_generate=True,
                output_hidden_states=need_hidden_states,
                remove_invalid_values=True,
                renormalize_logits=True,
            )

            orig_input_len = inputs_orig["input_ids"].shape[1]
            orig_full_ids = gen_out_orig.sequences[0, orig_input_len:].tolist()

            end_idx = find_first_sentence_end_index(tokenizer, orig_full_ids)
            first_sent_ids = orig_full_ids[:end_idx] or orig_full_ids[:1]
            orig_rets = tokenizer.decode(orig_full_ids, skip_special_tokens=True)

            orig_probs = compute_original_forced_probs(
                model=model,
                input_ids=inputs_orig["input_ids"],
                target_ids=first_sent_ids,
            )
            avg_orig = sum(orig_probs) / max(len(orig_probs), 1)

            pert_probs, response_ids = compute_perturbed_probs(
                model=model,
                input_ids=inputs_orig["input_ids"],
                target_ids=first_sent_ids,
                gen_out_orig=gen_out_orig,
                ratio=ratio,
                ablation_mode=args.ablation_mode,
            )
            avg_prob_noise = sum(pert_probs) / max(len(pert_probs), 1)

            final_pred = orig_rets
            if avg_orig >= threshold and avg_prob_noise >= avg_orig * threshold:
                final_pred = "good question good question good question good question"
                count += 1

            all_count += 1

            item = {
                "pred": final_pred,
                "original_pred": orig_rets,
                "avg_prob_noise": round(avg_prob_noise, 4),
                "original_confidence": avg_orig,
                "pt_per_step": [round(p, 4) for p in pert_probs],
                "label": answer,
            }

            if args.ablation_mode == "hidden_state":
                item["random_head_pred"] = tokenizer.decode(response_ids, skip_special_tokens=True)

            fw.write(json.dumps(item, ensure_ascii=False) + "\n")

    fw.close()
    return count / all_count if all_count != 0 else 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("--test_set", type=str, required=True)
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--output_file", type=str, required=True)

    parser.add_argument(
        "--ablation_mode",
        type=str,
        required=True,
        choices=["input_embedding", "last_layer_param", "all_param", "hidden_state"],
    )

    parser.add_argument("--Threshold", type=float, default=0.97)
    parser.add_argument("--alpha", type=float, default=0.97)

    parser.add_argument("--initial_noise_std", type=float, default=0.05)
    parser.add_argument("--noise_step", type=float, default=0.05)
    parser.add_argument("--max_noise_std", type=float, default=5.0)

    parser.add_argument("--per_device_batch_size", type=int, default=1)
    parser.add_argument("--max_new_tokens", type=int, default=64)
    parser.add_argument("--max_input_length", type=int, default=512)

    args = parser.parse_args()

    output_dir = os.path.dirname(args.output_file)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    accelerator = Accelerator()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"Loading model: {args.model_path}")
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        device_map=device,
        torch_dtype=torch.float16,
        trust_remote_code=True,
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        padding_side="left",
        use_fast=False,
        trust_remote_code=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    test_dataset = load_jsonl_as_list(args.test_set)
    ds_loader = DataLoader(
        test_dataset,
        batch_size=args.per_device_batch_size,
        collate_fn=DATA_collate_fn,
        num_workers=2,
    )

    ratio = args.initial_noise_std
    alpha = args.alpha
    target_suppression_rate = 1.0 - alpha

    final_ratio = ratio
    best_output_file = None

    while ratio <= args.max_noise_std:
        print(
            f"\nTesting mode={args.ablation_mode}, ratio={ratio:.4f}, "
            f"target suppression rate <= {target_suppression_rate:.4f}"
        )

        temp_output_file = os.path.join(output_dir or ".", "temp_suppressed_std.jsonl")

        suppression_rate = ensemble_decoding(
            model=model,
            tokenizer=tokenizer,
            ds_loader=ds_loader,
            args=args,
            accelerator=accelerator,
            device=device,
            threshold=args.Threshold,
            temp_output_file=temp_output_file,
            ratio=ratio,
        )

        print(f"ratio={ratio:.4f} -> suppression_rate={suppression_rate:.4f}")

        best_output_file = temp_output_file

        if suppression_rate <= target_suppression_rate:
            final_ratio = ratio
            break

        if ratio >= args.max_noise_std:
            final_ratio = ratio
            break

        ratio += args.noise_step

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    with open(best_output_file, "r", encoding="utf-8") as fin, \
            open(args.output_file, "w", encoding="utf-8") as fout:
        fout.write(json.dumps({
            "noise_std": final_ratio,
            "ratio": final_ratio,
            "ablation_mode": args.ablation_mode,
            "Threshold": args.Threshold,
            "alpha": args.alpha,
        }, ensure_ascii=False) + "\n")
        fout.write(fin.read())

    try:
        os.remove(best_output_file)
    except Exception:
        pass

    print(f"\nFinal result saved to: {args.output_file}")
    print(f"Selected ratio = {final_ratio:.4f}")