# RIPPLE 实现

该目录包含 RIPPLE 核心流程及其实验支持代码。

- `core/`：扰动尺度搜索与指纹响应缓解。
- `evaluation/`：下游任务、困惑度、置信度和 FPR 评测。
- `ablations/`：阈值、组件、噪声和校准集实验。
- `analysis/`：机制与扰动等价性分析。
- `utils/`：数据 collator 与答案处理工具。

主入口为：

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
bash ripple/core/run_ripple.sh
```

生成文件统一写入 `outputs/`。
