# RIPPLE implementation

This directory contains the core RIPPLE pipeline and its experimental support
code.

- `core/`: perturbation-scale search and fingerprint-response mitigation.
- `evaluation/`: downstream, perplexity, confidence, and FPR evaluations.
- `ablations/`: threshold, component, noise, and calibration experiments.
- `analysis/`: mechanism and perturbation-equivalence studies.
- `utils/`: dataset collators and answer-processing utilities.

The main entry point is:

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
bash ripple/core/run_ripple.sh
```

All generated files are written below `outputs/`.
