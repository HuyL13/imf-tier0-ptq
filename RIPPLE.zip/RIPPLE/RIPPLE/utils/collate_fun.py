def boolq_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        ques = b["question"]
        passage = b["passage"]

        prompt_q = f'there is a passage and a question, please analysis the question is true or false according to the passage, and just answer with Ture or False.\npassage:{passage}\nQuestion: {ques}\nAnswer:'
        questions.append(prompt_q)
        answer = 'T' if b["answer"] is True else 'F' 
        answers.append(answer)
    return questions, answers

def ANLI_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        premise = b["premise"]
        hypothesis = b["hypothesis"]

        instruction = '''just answer with entailment, contradiction, or neutral.'''

        prompt_q =f"Determine the logical relationship between the following Premise and Hypothesis, and just answer with entailment, contradiction, or neutral.\nPremise: {premise}\nHypothesis: {hypothesis}.\nAnswer:"
        questions.append(prompt_q)
        answer = b["label"]
        answers.append(answer)
    return questions, answers

def piqa_collate_fn(batch): #PIQA
    questions, answers = [], []
    for b in batch:
        ques = b["question"]
        A = b["A"]
        B = b["B"]
        prompt_q = f'Answer the question by replying A or B.\nQuestion: {ques}\nA: {A}\nB: {B}\nAnswer:'
        questions.append(prompt_q)
        answers.append(b["answer"])
    return questions, answers


def triviaQA_collate_fn(batch): #TrivalQA
    questions, answers = [], []
    for b in batch:
        ques = b["question"]
        prompt_q = f'Answer the question, and only return the final answer. Do NOT Analyze.\nQuestion: {ques}\nAnswer:'
        questions.append(prompt_q)
        answers.append(b["answer"])
    return questions, answers

def arc_collate_fn(batch): #ARC-C
    questions, answers = [], []
    for b in batch:
        ques = b["question"]
        A = b["A"]
        B = b["B"]
        C = b["C"]
        D = b["D"]
        prompt_q = f'Answer the question by replying A, B, C or D.\nQuestion: {ques}\nA: {A}\nB: {B}\nC: {C}\nD: {D}\nAnswer:'
        questions.append(prompt_q)
        answers.append(b["answer"])

    return questions, answers

def data_collate_fn(batch):
    questions, answers = [], []
    instruction1 = (
            "###instruction:A chat between a curious user and an artificial intelligence assistant. "
            "The assistant gives helpful, detailed, and politeanswers to the user’s questions.\n\n###human:"
        )
    for b in batch:
        ques = b["text"]

        # prompt_q = instruction1+' '+ques
        prompt_q = ques
        questions.append(prompt_q)
        answers.append(b["answer"])

    return questions, answers

###################### alpaca-GPT
def alpaca_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        # 添加当前指令
        current_instruction = b["instruction"]
        if b["input"]:
            current_instruction += "\n" + b["input"] + "\n\n" + "Assistant"
        questions.append(current_instruction)
        answers.append(b["output"])

    return questions, answers


###################### dolly
def dolly_collate_fn(batch):
    questions, answers = [], []
    for b in batch:


        # 添加当前指令
        current_instruction = b["instruction"]
        if b["context"]:
            current_instruction += "\n" + b["context"] + "\n\n" + "Assistant"
        questions.append(current_instruction)
        answers.append(b["response"])

    return questions, answers


###################### Gms8K
def gsm_collate_fn(batch):
    questions, answers = [], []
    for b in batch:


        # 添加当前指令
        current_instruction = b["instruction"]
        if b["input"]:
            current_instruction += "\n" + b["input"] + "\n\n" + "Assistant"
        questions.append(current_instruction)
        answers.append(b["output"])

    return questions, answers


###################### BBH
def bbh_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        ques = b["input"]
        options = b["options"]
        options_str = "\n".join(options)
        prompt_q = f'Answer the question by replying with only the option letter, such as A, B, C, or D.\nQuestion: {ques}\nOptions:\n{options_str}\nAnswer:'
        questions.append(prompt_q)
        # 从 "(E)" 提取 "E"
        answer_letter = b["output"]
        answers.append(answer_letter)

    return questions, answers



def advbench_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        ques = b["behavior"]
        prompt_q = f'Answer the question.\nQuestion: {ques}\nAnswer:'
        questions.append(prompt_q)
        # 从 "(E)" 提取 "E"
        answer_letter = "I cannot fulfill your request."
        answers.append(answer_letter)

    return questions, answers



def humaneval_collate_fn(batch):
    """
    用于 HumanEval 代码生成评测的标准数据整理函数
    """
    questions, task_ids = [], []
    for b in batch:
        # 提取 prompt，通常包含函数签名和文档字符串
        ques = b["prompt"]
        
        # 构造模型输入提示词 (可根据你的模型微调模板修改)
        prompt_q = f'Complete the following Python code:\n{ques} \nAnswer: \n'
        
        questions.append(prompt_q)
        task_ids.append(b["task_id"])  # 保留 task_id 以便后续匹配测试结果
        
    return questions, task_ids


def SST2_collate_fn(batch):
    """
    用于 HumanEval 代码生成评测的标准数据整理函数
    """
    questions, labels = [], []
    for b in batch:
        # 提取 prompt，通常包含函数签名和文档字符串
        ques = b["text"]
        
        # 构造模型输入提示词 (可根据你的模型微调模板修改)
        prompt_q = f'there is a passage, please analysis the passage is positive or negative, and just answer with negative or pasitive.\npassage:{ques}\nAnswer:'
        
        questions.append(prompt_q)
        labels.append(b["label_text"])  # 保留 task_id 以便后续匹配测试结果
        
    return questions, labels


def wmt_collate_fn(batch):
    """
    用于 HumanEval 代码生成评测的标准数据整理函数
    """
    questions, labels = [], []
    for b in batch:
        # 提取 prompt，通常包含函数签名和文档字符串
        ques = b["translation"]["en"]
        
        # 构造模型输入提示词 (可根据你的模型微调模板修改)
        prompt_q = f'there is a English passage, please translation the passage into France. \npassage:{ques}\nAnswer:'
        
        questions.append(prompt_q)
        labels.append(b["translation"]["fr"])  # 保留 task_id 以便后续匹配测试结果
        
    return questions, labels


def web_collate_fn(batch):
    """
    用于 HumanEval 代码生成评测的标准数据整理函数
    """
    questions, labels = [], []
    for b in batch:
        # 提取 prompt，通常包含函数签名和文档字符串
        ques = b["question"]
        
        # 构造模型输入提示词 (可根据你的模型微调模板修改)
        prompt_q = f'Please answer the question based on your knowledge. \nQuestion:{ques}\nAnswer:'
        
        questions.append(prompt_q)
        labels.append(b["answers"])  # 保留 task_id 以便后续匹配测试结果
        
    return questions, labels

