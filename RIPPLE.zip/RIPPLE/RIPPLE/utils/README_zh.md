# 共享工具

[English README](README.md)

本目录提供 RIPPLE 与基线评测封装共同使用的答案处理、响应抽取和数据 collator。
直接运行 Python 文件时，需要将上级 `ripple` 目录加入 `PYTHONPATH`。
