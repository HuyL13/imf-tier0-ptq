import json
import re
import os
import tempfile
import subprocess

# GSM

# def gsm_extract_math_answer(pred_str):
#     try:
#         if( 'boxed' in pred_str):
#             ans = pred_str.split('boxed')[-1]
#         elif('the answer is ' in pred_str):
#             ans = pred_str.split('the answer is ')[-1].strip()
#         elif 'The answer is ' in pred_str:
#             ans = pred_str.split('The answer is ')[-1].strip()
#         elif 'Answer: ' in pred_str:
#             ans = pred_str.split('Answer: ')[-1].strip()
#         else:
#             ans = pred_str

#         pattern = r'-?\d*[\.,]?\d+'
#         pred = re.findall(pattern, ans)

#         if(len(pred) >= 1):
#             # print(pred_str)
#             pred = float(pred[-1].replace(',',''))
#         else:
#             pred = float("nan")


#     except Exception:
#         print(f"Cannot parse the resulting num in predicted solution {pred_str}.\n")
#         pred = float("nan")

#     return pred

def gsm_extract_math_answer(pred_str):
    if pred_str is None:
        return float("nan")

    text = str(pred_str).strip()
    if not text:
        return float("nan")

    # 1) 截断 prompt 泄漏/续写
    stop_markers = ["\nUser:", "\nQuestion:", "\nSystem:", "\nAssistant:"]
    for marker in stop_markers:
        if marker in text:
            text = text.split(marker)[0].strip()

    # 2) 优先匹配最强答案格式
    patterns = [
        r"####\s*(-?\d[\d,]*\.?\d*)",
        r"\\boxed\{?\s*(-?\d[\d,]*\.?\d*)\s*\}?",
        r"[Tt]he answer is\s*\$?\s*(-?\d[\d,]*\.?\d*)",
        r"Answer:\s*\$?\s*(-?\d[\d,]*\.?\d*)",
        r"final answer(?: is)?\s*\$?\s*(-?\d[\d,]*\.?\d*)",
    ]

    for pattern in patterns:
        m = re.search(pattern, text)
        if m:
            try:
                return float(m.group(1).replace(",", ""))
            except:
                pass

    # 3) 取最后一句，再取其中最后一个数字
    sentences = re.split(r'(?<=[\.\!\?])\s+', text)
    if sentences:
        last_sentence = sentences[-1]
        nums = re.findall(r"-?\d[\d,]*\.?\d*", last_sentence)
        if nums:
            try:
                return float(nums[-1].replace(",", ""))
            except:
                pass

    # 4) 全文兜底：取最后一个数字
    nums = re.findall(r"-?\d[\d,]*\.?\d*", text)
    if nums:
        try:
            return float(nums[-1].replace(",", ""))
        except:
            pass

    return float("nan")


def gsm_parse_pred_ans(filename):
    total, correct = 0, 0

    with open(filename, "r", encoding="utf-8") as fr:
        for line in fr:
            jo = json.loads(line.strip())
            pred = str(jo["pred"])
            label_text = str(jo["label"])

            match = re.search(r"####\s*(-?\d+(?:\.\d+)?)", label_text)
            if not match:
                total += 1
                continue

            label = re.escape(match.group(1))

            # 要求是一个相对独立的数字，不是别的数字的一部分
            if re.search(rf"(?<![\d.]){label}(?![\d.])", pred):
                correct += 1

            total += 1



    print('num_q %d correct %d ratio %.4f' % (total, correct, float(correct / total)))
    accuracy = float(correct / total)
    # 写入准确率到文件第一行
    temp_filename = filename + ".tmp"
    with open(temp_filename, "w", encoding="utf-8") as fw:
        fw.write(json.dumps({"accuracy": accuracy}, ensure_ascii=False) + "\n")
        with open(filename, "r", encoding="utf-8") as fr:
            for line in fr:
                fw.write(line)


    os.replace(temp_filename, filename)


# ARC/PIQA/MMLU

def arc_parse_pred_ans(filename):
    total, correct = 0, 0
    gold_ans = []
    qs = []
    
    with open(filename, "r", encoding="utf-8") as fr:
        for line in fr:
            jo = json.loads(line.strip())

            if jo["question"] not in qs:
                # 提取 pred 中第一个出现的字母（A-Za-z）
                pred_letter = ' '  # 默认值
                for char in jo["pred"]:
                    if char.isalpha():  # 判断是否为字母
                        pred_letter = char.upper()  # 转大写，统一处理 A/a
                        break  # 找到第一个就退出

                # 如果一个字母都没找到，保持为 ' '
                if pred_letter == ' ':
                    print(f"Warning: No letter found in pred: {jo['pred']}")

                # 统一将 label 转为大写进行比较
                label = jo["label"].strip().upper()

                correct += (pred_letter == label)
                total += 1
                qs.append(jo["question"])
            else:
                continue

    accuracy = float(correct / total)
    print('num_q %d correct %d ratio %.4f' % (total, correct, accuracy))

    # 写入准确率到文件第一行
    temp_filename = filename + ".tmp"
    with open(temp_filename, "w", encoding="utf-8") as fw:
        fw.write(json.dumps({"accuracy": accuracy}, ensure_ascii=False) + "\n")
        with open(filename, "r", encoding="utf-8") as fr:
            for line in fr:
                fw.write(line)


    os.replace(temp_filename, filename)

#TriviaQA NQ
def qa_parse_pred_ans(filename):
    total, correct = 0, 0
    with open(filename, "r", encoding="utf-8") as fr:
        for line in fr:
            jo = json.loads(line.strip())
            for gold in jo["label"]:
                if gold.strip() in jo["pred"]:
                    correct += 1
                    break
            total += 1
    accuracy = correct / total
    print('num_q %d correct %d ratio %.4f' % (total, correct, float(correct / total)))
    # 新建一个临时文件，先写入准确率，再写回原有内容
    temp_filename = filename + ".tmp"
    with open(temp_filename, "w", encoding="utf-8") as fw:
        # 写入准确率作为第一行
        fw.write(json.dumps({"accuracy": accuracy}, ensure_ascii=False) + "\n")

        # 再写入原始内容
        with open(filename, "r", encoding="utf-8") as fr:
            for line in fr:
                fw.write(line)

    # 可选：覆盖原文件
    import os
    os.replace(temp_filename, filename)

####################################     BBH     ###################################
def extract_label_letter_and_text(label_raw: str):
    """
    从 label 中提取：
    - 选项字母，例如 C
    - 选项文本，例如 'The raven is the second from the left'
    """
    label_raw = str(label_raw).strip()

    m = re.match(r'^\(?\s*([A-Z])\s*\)?\s*(.*)$', label_raw, flags=re.I)
    if m:
        letter = m.group(1).upper()
        text = m.group(2).strip()
        return letter, text

    # 兜底：如果没有匹配到，就只返回首个字母
    m2 = re.search(r'[A-Z]', label_raw, flags=re.I)
    letter = m2.group(0).upper() if m2 else ""
    return letter, ""


def normalize_text(s: str):
    """
    用于文本匹配的轻量归一化：
    - 小写
    - 去掉多余空白
    - 去掉首尾标点干扰
    """
    s = str(s).strip().lower()
    s = re.sub(r'\s+', ' ', s)
    s = s.strip(" .,:;!?\"'`()[]{}")
    return s


def extract_pred_letter(pred: str):
    """
    尽量稳健地从模型输出中提取选项字母。
    处理如：
    - "A"
    - "(C)"
    - "()C"
    - "Answer: D"
    - "The answer is (B)"
    - "Option F"
    """
    pred = str(pred).strip()

    patterns = [
        r'^\s*\(?\s*([A-Z])\s*\)?\s*$',                       # A / (A)
        r'^\s*\(\)\s*([A-Z])\s*$',                            # ()C
        r'(?i)\banswer\s*[:：]?\s*\(?\s*([A-Z])\s*\)?\b',     # Answer: C
        r'(?i)\bthe answer is\s*\(?\s*([A-Z])\s*\)?\b',       # the answer is C
        r'(?i)\boption\s*\(?\s*([A-Z])\s*\)?\b',              # option C
        r'(?i)\bchoice\s*\(?\s*([A-Z])\s*\)?\b',              # choice C
        r'(?<![A-Za-z])\(?\s*([A-Z])\s*\)?(?![A-Za-z])',      # 独立字母
    ]

    for pattern in patterns:
        m = re.search(pattern, pred)
        if m:
            return m.group(1).upper()

    return ""


def bbh_parse_pred_ans(filename):
    total, correct = 0, 0
    seen_questions = set()

    with open(filename, "r", encoding="utf-8") as fr:
        for line in fr:
            jo = json.loads(line.strip())

            question = jo["question"]
            if question in seen_questions:
                continue
            seen_questions.add(question)

            pred = str(jo["pred"])
            label_raw = str(jo["label"])

            label_letter, label_text = extract_label_letter_and_text(label_raw)
            pred_letter = extract_pred_letter(pred)

            is_correct = False

            # 1. 优先按字母判断
            if pred_letter and label_letter:
                is_correct = (pred_letter == label_letter)

            # 2. 如果没提取到有效字母，再尝试按文本匹配
            # 例如 pred = "Ana finished last."
            # label = "(C) Ana finished last."
            if (not is_correct) and label_text:
                pred_norm = normalize_text(pred)
                label_text_norm = normalize_text(label_text)

                if label_text_norm and label_text_norm in pred_norm:
                    is_correct = True

            correct += int(is_correct)
            total += 1

    accuracy = float(correct / total) if total > 0 else 0.0
    print('num_q %d correct %d ratio %.4f' % (total, correct, accuracy))

    # 写入准确率到文件第一行
    temp_filename = filename + ".tmp"
    with open(temp_filename, "w", encoding="utf-8") as fw:
        fw.write(json.dumps({"accuracy": accuracy}, ensure_ascii=False) + "\n")
        with open(filename, "r", encoding="utf-8") as fr:
            for line in fr:
                fw.write(line)

    os.replace(temp_filename, filename)



def sst_parse_pred_ans(filename):
    total, correct = 0, 0
    seen_questions = set()

    with open(filename, "r", encoding="utf-8") as fr:
        for line in fr:
            jo = json.loads(line.strip())

            question = jo["question"]
            if question in seen_questions:
                continue
            seen_questions.add(question)

            pred = str(jo["pred"])
            label_raw = str(jo["label"])


            is_correct = False

            # 1. 优先按字母判断
            if pred and label_raw:
                is_correct = (pred == label_raw)


            correct += int(is_correct)
            total += 1

    accuracy = float(correct / total) if total > 0 else 0.0
    print('num_q %d correct %d ratio %.4f' % (total, correct, accuracy))

    # 写入准确率到文件第一行
    temp_filename = filename + ".tmp"
    with open(temp_filename, "w", encoding="utf-8") as fw:
        fw.write(json.dumps({"accuracy": accuracy}, ensure_ascii=False) + "\n")
        with open(filename, "r", encoding="utf-8") as fr:
            for line in fr:
                fw.write(line)

    os.replace(temp_filename, filename)


def humaneval_parse_pred_ans(
    filename,
    original_humaneval_path="data/evaluation/additional/HumanEval.jsonl",
):
    """
    评测 HumanEval 数据集的 Pass@1 准确率。
    
    :param filename: 模型预测结果文件路径
    :param original_humaneval_path: 原始 humaneval.jsonl 路径（用于获取 test 测试用例）
    """
    # ================= 1. 加载原始测试用例 =================
    # 构建 task_id 到 test 代码的映射字典
    test_cases_map = {}
    if not os.path.exists(original_humaneval_path):
        print(f"⚠️ 警告: 找不到原始 HumanEval 测试文件 {original_humaneval_path}")
        print("将默认所有预测为错误 (accuracy = 0.0)")
    else:
        with open(original_humaneval_path, "r", encoding="utf-8") as fr:
            for line in fr:
                jo = json.loads(line.strip())
                # HumanEval 标准字段为 task_id 和 test
                task_id = jo.get("task_id")
                test_code = jo.get("test", "")
                if task_id:
                    test_cases_map[task_id] = test_code

    # ================= 2. 评测主循环 =================
    total, correct = 0, 0
    seen_questions = set()

    with open(filename, "r", encoding="utf-8") as fr:
        for line in fr:
            jo = json.loads(line.strip())

            question = jo["question"]
            if question in seen_questions:
                continue
            seen_questions.add(question)

            pred = str(jo.get("pred", ""))
            task_id = jo.get("label", "")  # 你的数据中 label 存的是 task_id (如 "Rust/0")

            is_correct = False

            # 1. 获取对应的测试代码
            test_code = test_cases_map.get(task_id, "")
            
            # 2. 拼接完整代码并执行验证 (Pass@1 核心逻辑)
            if test_code:
                # 拼接 prompt + 模型生成的代码 + 测试用例
                full_code = pred + "\n" + test_code
                
                # 使用临时文件执行代码，避免污染当前环境
                with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
                    tmp.write(full_code)
                    tmp_path = tmp.name
                
                try:
                    # 执行测试，设置超时时间防止死循环
                    result = subprocess.run(
                        ["python3", tmp_path], 
                        capture_output=True, 
                        text=True, 
                        timeout=5.0
                    )
                    # 如果返回码为 0，说明所有 assert 测试通过
                    is_correct = (result.returncode == 0)
                except subprocess.TimeoutExpired:
                    is_correct = False  # 超时视为错误
                except Exception as e:
                    is_correct = False  # 其他异常视为错误
                finally:
                    if os.path.exists(tmp_path):
                        os.remove(tmp_path)

            correct += int(is_correct)
            total += 1

    # ================= 3. 计算并保存结果 =================
    accuracy = float(correct / total) if total > 0 else 0.0
    print('num_q %d correct %d ratio %.4f' % (total, correct, accuracy))

    # 写入准确率到文件第一行 (与你的 SST 逻辑完全一致)
    temp_filename = filename + ".tmp"
    with open(temp_filename, "w", encoding="utf-8") as fw:
        fw.write(json.dumps({"accuracy": accuracy}, ensure_ascii=False) + "\n")
        with open(filename, "r", encoding="utf-8") as fr:
            for line in fr:
                fw.write(line)

    os.replace(temp_filename, filename)

