# Shared utilities

[中文说明](README_zh.md)

This directory provides answer processing, response extraction, and dataset
collators shared by RIPPLE and the baseline evaluation wrappers. Add the parent
`ripple` directory to `PYTHONPATH` when running Python files directly.
