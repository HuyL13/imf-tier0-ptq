# Evaluation

[中文说明](README_zh.md)

- `single_model_data_test.py`: downstream generation/accuracy evaluation.
- `PPL_test.py` and `run_ppl.sh`: perplexity post-processing.
- `confidence_baselines`: MaxProb-only and entropy-only detectors.
- `clean_models`: application of the RIPPLE pipeline to non-fingerprinted models.
- `high_confidence`: FPR evaluation on SST-2, WMT14, HumanEval, AdvBench, and
  WebQuestions.

Example downstream evaluation:

```bash
python ripple/evaluation/single_model_data_test.py \
  --model_path models/fingerprinted/IF/llama3.1-8b-it \
  --test_set data/evaluation/main/MMLU.jsonl \
  --output_file outputs/evaluation/IF/llama3.1-8b-it/MMLU.jsonl \
  --max_new_tokens 32
```

Task-specific launchers and complete examples are documented in their
subdirectories.
