#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"
MODEL_PATH="${MODEL_PATH:?Set MODEL_PATH to a local model or checkpoint}"
DATA_PATH="${DATA_PATH:?Set DATA_PATH to a generated JSONL file}"
OUTPUT_PATH="${OUTPUT_PATH:-${ROOT_DIR}/outputs/ppl.jsonl}"

mkdir -p "$(dirname "${OUTPUT_PATH}")"
python "${ROOT_DIR}/ripple/evaluation/PPL_test.py" \
  --model_path "${MODEL_PATH}" --data_path "${DATA_PATH}" --output_path "${OUTPUT_PATH}"
