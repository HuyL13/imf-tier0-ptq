# MaxProb 运行脚本

[English README](README.md)

`run.sh` 使用 MaxProb-only 检测器执行良性集校准和指纹评测。需设置
`MODEL_PATH` 与 `FP_METHOD`。

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
bash ripple/evaluation/confidence_baselines/maxprob/run.sh
```
