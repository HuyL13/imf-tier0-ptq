# Confidence-only baselines

[中文说明](README_zh.md)

`maxprob_*` implements MaxProb-only detection and `entropy_*` implements
entropy-only detection. Each subdirectory contains a portable `run.sh`.

MaxProb example:

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
bash ripple/evaluation/confidence_baselines/maxprob/run.sh
```

Replace `maxprob` with `entropy` to run the entropy-only detector. Outputs are
written below `outputs/confidence_baselines/`.
