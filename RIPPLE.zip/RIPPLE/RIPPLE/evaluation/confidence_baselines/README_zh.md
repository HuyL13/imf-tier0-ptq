# 仅置信度基线

[English README](README.md)

`maxprob_*` 实现 MaxProb-only 检测，`entropy_*` 实现 entropy-only 检测；
两个子目录均提供可移植的 `run.sh`。

MaxProb 示例：

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
bash ripple/evaluation/confidence_baselines/maxprob/run.sh
```

将 `maxprob` 替换为 `entropy` 即可运行 entropy-only 检测器。输出写入
`outputs/confidence_baselines/`。
