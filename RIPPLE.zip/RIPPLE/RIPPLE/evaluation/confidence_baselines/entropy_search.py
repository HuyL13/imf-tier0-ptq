import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from transformers import AutoTokenizer, AutoModelForCausalLM
from tqdm import tqdm
import torch
import json
import argparse
from accelerate import Accelerator
from torch.utils.data import DataLoader
import torch.nn.functional as F
from utils.ans_process import *
from utils.collate_fun import *
from utils.extract_response import *


def load_jsonl_as_list(path):
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                item = json.loads(line)
                if "answer" in item:
                    item["answer"] = str(item["answer"])
                data.append(item)
    return data


def DATA_collate_fn(batch):
    questions, answers = [], []
    for b in batch:
        source = b.get('source')
        try:
            if source == 'piqa':
                ques = b["question"]
                A = b["A"]
                B = b["B"]
                prompt_q = f'Answer the question by replying A or B.\nQuestion: {ques}\nA: {A}\nB: {B}\nAnswer:'
                questions.append(prompt_q)
                answers.append(b["answer"])

            elif source == 'triviaqa':
                ques = b["question"]
                prompt_q = f'Answer the question, and only return the final answer. Do NOT Analyze.\nQuestion: {ques}\nAnswer:'
                questions.append(prompt_q)
                answers.append(b["answer"])

            elif source == 'boolq':
                ques = b["question"]
                passage = b["passage"]
                prompt_q = (
                    f'there is a passage and a question, please analysis the question is true or false '
                    f'according to the passage, and just answer with True or False.\n'
                    f'passage:{passage}\nQuestion: {ques}\nAnswer:'
                )
                questions.append(prompt_q)
                answer = 'True' if b["answer"] is True else 'False'
                answers.append(answer)

            elif source == 'anli':
                premise = b["premise"]
                hypothesis = b["hypothesis"]
                prompt_q = (
                    "Determine the logical relationship between the following Premise and Hypothesis, "
                    "and just answer with entailment, contradiction, or neutral.\n"
                    f"Premise: {premise}\nHypothesis: {hypothesis}.\nAnswer:"
                )
                questions.append(prompt_q)
                answers.append(b["label"])

            elif source == 'arc' or source == 'mmlu':
                ques = b["question"]
                A = b["A"]
                B = b["B"]
                C = b["C"]
                D = b["D"]
                prompt_q = (
                    f'Answer the question by replying A, B, C or D.\nQuestion: {ques}\n'
                    f'A: {A}\nB: {B}\nC: {C}\nD: {D}\nAnswer:'
                )
                questions.append(prompt_q)
                answers.append(b["answer"])
            
            elif source == 'dolly':

                    # 添加当前指令
                    current_instruction = b["instruction"]
                    if b["context"]:
                        current_instruction += "\n" + b["context"] + "\n\n" + "Assistant"
                    questions.append(current_instruction)
                    answers.append(b["response"])

            elif source == 'alpaca':

                    # 添加当前指令
                    current_instruction = b["instruction"]
                    if b["input"]:
                        current_instruction += "\n" + b["input"] + "\n\n" + "Assistant"
                    questions.append(current_instruction)
                    answers.append(b["output"])
            
            elif source == 'gsm':
                # 添加当前指令
                questions.append(b["question"])
                answers.append(b["answer"])

            elif source == 'bbh':
                ques = b["input"]
                options = b["options"]
                options_str = "\n".join(options)
                prompt_q = f'Answer the question by replying with only the option letter, such as A, B, C, or D.\nQuestion: {ques}\nOptions:\n{options_str}\nAnswer:'
                questions.append(prompt_q)
                # 从 "(E)" 提取 "E"
                answer_letter = b["output"]
                answers.append(answer_letter)

            elif source == 'advbench':
                ques = b["behavior"]
                prompt_q = f'Answer the question.\nQuestion: {ques}\nAnswer:'
                questions.append(prompt_q)
                # 从 "(E)" 提取 "E"
                answer_letter = "I cannot fulfill your request."
                answers.append(answer_letter)

            elif source == 'humaneval':
                # 提取 prompt，通常包含函数签名和文档字符串
                ques = b["prompt"]
                
                # 构造模型输入提示词 (可根据你的模型微调模板修改)
                prompt_q = f'Complete the following Python code:\n{ques}'
                
                questions.append(prompt_q)
                task_ids.append(b["task_id"])  # 保留 task_id 以便后续匹配测试结果

            elif source == 'sst':
                # 提取 prompt，通常包含函数签名和文档字符串
                ques = b["text"]
                
                # 构造模型输入提示词 (可根据你的模型微调模板修改)
                prompt_q = f'there is a passage, please analysis the passage is positive or negative, and just answer with negative or pasitive.\npassage:{ques}\nAnswer:'
                
                questions.append(prompt_q)
                answers.append(b["label_text"])  # 保留 task_id 以便后续匹配测试结果

            else:  # normal 或其他
                ques = b["text"]
                prompt_q = ques
                questions.append(prompt_q)
                answers.append(b["answer"])

        except KeyError:
            continue

    return questions, answers


def find_first_sentence_end_index(tokenizer, token_ids):
    decoded = ""
    for i, tok_id in enumerate(token_ids):
        part = tokenizer.decode([tok_id], skip_special_tokens=True, clean_up_tokenization_spaces=False)
        decoded += part
        if any(c in decoded[-2:] for c in ['.', '!', '?', '。', '！', '？']):
            return i + 1
    return len(token_ids)


def compute_raw_probs_for_generated_tokens(model, input_ids, target_ids):
    """
    A 的概率计算：
    不使用 generate(...).scores，
    而是将 [prompt + generated_tokens] 整体重新送入模型，
    对每个目标 token 读取前一位置的 raw logits，直接 softmax。
    """
    if len(target_ids) == 0:
        return []

    device = input_ids.device
    target_tensor = torch.tensor([target_ids], dtype=input_ids.dtype, device=device)
    full_ids = torch.cat([input_ids, target_tensor], dim=1)

    with torch.no_grad():
        outputs = model(input_ids=full_ids)
        logits = outputs.logits  # [1, total_len, vocab]

    prompt_len = input_ids.shape[1]
    probs_list = []

    for i, tok in enumerate(target_ids):
        pos = prompt_len + i
        prev_logits = logits[0, pos - 1, :]
        prob = F.softmax(prev_logits, dim=-1)[tok].item()
        probs_list.append(prob)

    return probs_list


def add_adaptive_rms_noise(hidden_state, noise_std, eps=1e-6):
    """
    基于当前 hidden_state 的 RMS 做相对扰动。
    这里保留原参数名 noise_std，不改调用接口；
    但其含义变为“相对扰动系数”。

    perturb_scale = noise_std * rms(hidden_state)
    """
    hs = hidden_state.float()
    rms = torch.sqrt(torch.mean(hs.pow(2), dim=-1, keepdim=True) + eps)  # [B, T, 1]
    scale = (noise_std * rms).to(hidden_state.dtype)
    noise = torch.randn_like(hidden_state) * scale
    perturbed_hidden = hidden_state + noise
    return perturbed_hidden


def ensemble_decoding(model, tokenizer, ds_loader, args, accelerator, device, Threshold, temp_output_file, noise_std):
    fw = open(temp_output_file, "w", encoding="utf-8")
    max_new_tokens = args.max_new_tokens

    if accelerator.is_main_process:
        iter_item = tqdm(ds_loader)
    else:
        iter_item = ds_loader

    count, all_count = 0, 0

    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)

    for questions, answers in iter_item:
        for question, answer in zip(questions, answers):
            inputs_orig = tokenizer(question, return_tensors="pt").to(device)

            # 1. 正常生成，只用于得到原始输出 token
            gen_out_orig = model.generate(
                **inputs_orig,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                top_k=30,
                top_p=0.7,
                temperature=0.95,
                eos_token_id=tokenizer.eos_token_id,
                pad_token_id=tokenizer.eos_token_id,
                return_dict_in_generate=True
            )

            orig_input_len = inputs_orig["input_ids"].shape[1]
            orig_full_ids = gen_out_orig.sequences[0, orig_input_len:].tolist()

            end_idx = find_first_sentence_end_index(tokenizer, orig_full_ids)
            first_sent_ids = orig_full_ids[:end_idx] or orig_full_ids[:1]

            orig_rets = tokenizer.decode(orig_full_ids, skip_special_tokens=True)

            # ===== 计算原始 token probability 和 entropy =====
            if len(first_sent_ids) == 0:
                orig_probs = []
                entropy_list = []
                avg_orig = 0.0
                avg_entropy = float("inf")
            else:
                target_tensor = torch.tensor(
                    [first_sent_ids],
                    dtype=inputs_orig["input_ids"].dtype,
                    device=device
                )

                full_ids = torch.cat(
                    [inputs_orig["input_ids"], target_tensor],
                    dim=1
                )

                with torch.no_grad():
                    outputs = model(input_ids=full_ids)
                    logits = outputs.logits  # [1, total_len, vocab]

                prompt_len = inputs_orig["input_ids"].shape[1]

                orig_probs = []
                entropy_list = []

                for i, tok in enumerate(first_sent_ids):
                    pos = prompt_len + i

                    # 预测当前 token 的 logits 来自前一个位置
                    prev_logits = logits[0, pos - 1, :].float()

                    # 原始分布，不经过 top-k / top-p / temperature
                    log_probs = F.log_softmax(prev_logits, dim=-1)
                    probs = log_probs.exp()

                    # 当前生成 token 的原始概率
                    token_prob = probs[tok].item()
                    orig_probs.append(token_prob)

                    # 当前 step 的 entropy，单位是 nats
                    step_entropy = -(probs * log_probs).sum().item()
                    entropy_list.append(step_entropy)

                avg_orig = sum(orig_probs) / max(len(orig_probs), 1)
                avg_entropy = sum(entropy_list) / max(len(entropy_list), 1)

            # ===== Entropy baseline 判定 =====
            # entropy 越低，说明模型越确定，越可能是 fingerprint response
            final_pred = orig_rets

            if avg_entropy <= Threshold:
                final_pred = "good question good question good question good question"
                count += 1

            all_count += 1

            fw.write(json.dumps({
                "question": question,
                "pred": final_pred,
                "original_pred": orig_rets,
                "original_confidence": avg_orig,
                "entropy": avg_entropy,
                "label": answer
            }, ensure_ascii=False) + "\n")

    fw.close()
    return count / all_count if all_count != 0 else 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_set", type=str, default="data/calibration/mixed_set_500.jsonl")
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--output_file", type=str, required=True,
                        help="Path to the output JSONL file (e.g. outputs/confidence/entropy/search.jsonl)")
    parser.add_argument("--Threshold", type=float, default=0.99)
    parser.add_argument("--alpha", type=float, default=0.95)
    parser.add_argument("--initial_noise_std", type=float, default=0.5)
    parser.add_argument("--noise_step", type=float, default=1)
    parser.add_argument("--max_noise_std", type=float, default=1)
    parser.add_argument("--per_device_batch_size", type=int, default=1)
    parser.add_argument("--max_new_tokens", type=int, default=64)
    args = parser.parse_args()

    output_dir = os.path.dirname(args.output_file)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    accelerator = Accelerator()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"Loading base model ONLY ONCE: {args.model_path}")
    base_model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        device_map=device,
        torch_dtype=torch.float16,
        trust_remote_code=True
    ).eval()

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        padding_side="left",
        use_fast=False,
        trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    test_dataset = load_jsonl_as_list(args.test_set)


    ds_loader = DataLoader(
        test_dataset,
        batch_size=args.per_device_batch_size,
        collate_fn=DATA_collate_fn,
        num_workers=2
    )

    noise_std = args.initial_noise_std
    alpha = args.alpha
    target_suppression_rate = alpha
    final_noise_std = noise_std
    best_output_file = None

    while noise_std <= args.max_noise_std:
        print(f"\n🔍 Testing with noise_std = {noise_std:.4f} (target suppression rate ≤ {target_suppression_rate:.3f})")

        temp_output_file = os.path.join(output_dir or ".", f"temp_suppressed_std.jsonl")

        suppression_rate = ensemble_decoding(
            base_model, tokenizer, ds_loader, args, accelerator, device, args.Threshold, temp_output_file, noise_std
        )

        print(f"✅ noise_std={noise_std:.4f} → suppression_rate = {suppression_rate:.4f}")

        best_output_file = temp_output_file
        if suppression_rate <= target_suppression_rate:
            final_noise_std = noise_std
            break
        elif noise_std==args.max_noise_std:
            final_noise_std = noise_std
            break
        else:
            print(f"⚠️ Suppression rate too high ({suppression_rate:.4f} > {target_suppression_rate:.4f}), increasing noise_std.")
            noise_std += args.noise_step

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    with open(best_output_file, "r", encoding="utf-8") as fin, \
         open(args.output_file, "w", encoding="utf-8") as fout:
        fout.write(json.dumps({"noise_std": final_noise_std}, ensure_ascii=False) + "\n")
        fout.write(fin.read())

    try:
        os.remove(best_output_file)
    except:
        pass

    print(f"\n🎉 Final result saved to: {args.output_file}")
    print(f"   Selected noise_std = {final_noise_std:.4f}")
