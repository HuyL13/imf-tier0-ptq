#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../.." && pwd)"
cd "${ROOT_DIR}"
MODEL_PATH="${MODEL_PATH:?Set MODEL_PATH to a local model or checkpoint}"
FP_METHOD="${FP_METHOD:?Set FP_METHOD to IF, C&H, or ImF}"
THRESHOLD="${THRESHOLD:-0.05}"
ALPHA="${ALPHA:-0.05}"
SEARCH_SET="${SEARCH_SET:-${ROOT_DIR}/data/calibration/mixed_set_500.jsonl}"
OUTPUT_DIR="${OUTPUT_DIR:-${ROOT_DIR}/outputs/confidence_baselines/entropy}"

case "${FP_METHOD}" in
  IF) ATTACK_SET="${ATTACK_SET:-${ROOT_DIR}/data/fingerprints/IF/test_IF_10.jsonl}" ;;
  'C&H') ATTACK_SET="${ATTACK_SET:-${ROOT_DIR}/data/fingerprints/C&H/test_C&H_10.jsonl}" ;;
  ImF) ATTACK_SET="${ATTACK_SET:-${ROOT_DIR}/data/fingerprints/ImF/test_ImF_10.jsonl}" ;;
  *) echo "Unsupported FP_METHOD: ${FP_METHOD}" >&2; exit 2 ;;
esac

mkdir -p "${OUTPUT_DIR}"
export PYTHONPATH="${ROOT_DIR}/ripple${PYTHONPATH:+:${PYTHONPATH}}"

python "${ROOT_DIR}/ripple/evaluation/confidence_baselines/entropy_search.py" \
  --test_set "${SEARCH_SET}" --model_path "${MODEL_PATH}" \
  --output_file "${OUTPUT_DIR}/search.jsonl" --Threshold "${THRESHOLD}" --alpha "${ALPHA}"

python "${ROOT_DIR}/ripple/evaluation/confidence_baselines/entropy_attack.py" \
  --test_set "${ATTACK_SET}" --model_path "${MODEL_PATH}" \
  --std_file "${OUTPUT_DIR}/search.jsonl" --output_file "${OUTPUT_DIR}/attack.jsonl" \
  --Threshold "${THRESHOLD}"
