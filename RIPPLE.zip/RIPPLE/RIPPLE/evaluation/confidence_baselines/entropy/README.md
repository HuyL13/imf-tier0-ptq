# Entropy runner

[中文说明](README_zh.md)

`run.sh` performs benign-set calibration and fingerprint evaluation with the
entropy-only detector. Set `MODEL_PATH` and `FP_METHOD`.

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
bash ripple/evaluation/confidence_baselines/entropy/run.sh
```
