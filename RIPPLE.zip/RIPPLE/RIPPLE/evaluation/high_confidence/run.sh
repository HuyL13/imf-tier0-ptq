#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "${ROOT_DIR}"
MODEL_PATH="${MODEL_PATH:?Set MODEL_PATH to a local model or checkpoint}"
STD_FILE="${STD_FILE:?Set STD_FILE to a RIPPLE search JSONL}"
TASK="${TASK:-SST-2}"
THRESHOLD="${THRESHOLD:-0.99}"
OUTPUT_FILE="${OUTPUT_FILE:-${ROOT_DIR}/outputs/high_confidence/${TASK}.jsonl}"

case "${TASK}" in
  SST-2) TEST_SET="${TEST_SET:-${ROOT_DIR}/data/evaluation/additional/SST-2.jsonl}"; MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-16}" ;;
  WMT14) TEST_SET="${TEST_SET:-${ROOT_DIR}/data/evaluation/additional/WMT14.jsonl}"; MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-256}" ;;
  HumanEval) TEST_SET="${TEST_SET:-${ROOT_DIR}/data/evaluation/additional/HumanEval.jsonl}"; MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-512}" ;;
  AdvBench) TEST_SET="${TEST_SET:-${ROOT_DIR}/data/evaluation/additional/AdvBench.jsonl}"; MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-64}" ;;
  WebQuestions) TEST_SET="${TEST_SET:-${ROOT_DIR}/data/evaluation/additional/WebQuestions.jsonl}"; MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-64}" ;;
  *) echo "Unsupported TASK: ${TASK}" >&2; exit 2 ;;
esac

mkdir -p "$(dirname "${OUTPUT_FILE}")"
export PYTHONPATH="${ROOT_DIR}/ripple${PYTHONPATH:+:${PYTHONPATH}}"
python "${ROOT_DIR}/ripple/core/noise_in_hidden.py" \
  --test_set "${TEST_SET}" --model_path "${MODEL_PATH}" --std_file "${STD_FILE}" \
  --output_file "${OUTPUT_FILE}" --Threshold "${THRESHOLD}" \
  --max_new_tokens "${MAX_NEW_TOKENS}"
