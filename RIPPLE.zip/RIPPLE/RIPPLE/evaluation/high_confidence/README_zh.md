# 高置信度良性任务

[English README](README.md)

`run.sh` 在 SST-2、WMT14、HumanEval、AdvBench 或 WebQuestions 上运行完整
RIPPLE 检测器。需设置 `MODEL_PATH` 和 `STD_FILE`，并通过 `TASK` 选择任务。

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
STD_FILE=outputs/ripple/IF/search.jsonl \
TASK=SST-2 \
OUTPUT_FILE=outputs/high_confidence/IF/llama3.1-8b-it/SST-2.jsonl \
bash ripple/evaluation/high_confidence/run.sh
```
