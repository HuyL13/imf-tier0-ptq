# High-confidence benign tasks

[中文说明](README_zh.md)

`run.sh` applies the full RIPPLE detector to one of SST-2, WMT14, HumanEval,
AdvBench, or WebQuestions. Set `MODEL_PATH` and `STD_FILE`; choose the task with
`TASK`.

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
STD_FILE=outputs/ripple/IF/search.jsonl \
TASK=SST-2 \
OUTPUT_FILE=outputs/high_confidence/IF/llama3.1-8b-it/SST-2.jsonl \
bash ripple/evaluation/high_confidence/run.sh
```
