#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "${ROOT_DIR}"
MODEL_PATH="${MODEL_PATH:?Set MODEL_PATH to a clean local model}"
TEST_SET="${TEST_SET:?Set TEST_SET to a JSON or JSONL evaluation file}"
STD_FILE="${STD_FILE:?Set STD_FILE to the search JSONL produced by run_search.sh}"
OUTPUT_FILE="${OUTPUT_FILE:-${ROOT_DIR}/outputs/clean_models/evaluation.jsonl}"
THRESHOLD="${THRESHOLD:-0.99}"
MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-64}"

mkdir -p "$(dirname "${OUTPUT_FILE}")"
export PYTHONPATH="${ROOT_DIR}/ripple${PYTHONPATH:+:${PYTHONPATH}}"
python "${ROOT_DIR}/ripple/core/noise_in_hidden.py" \
  --test_set "${TEST_SET}" --model_path "${MODEL_PATH}" --std_file "${STD_FILE}" \
  --output_file "${OUTPUT_FILE}" --Threshold "${THRESHOLD}" \
  --max_new_tokens "${MAX_NEW_TOKENS}"
