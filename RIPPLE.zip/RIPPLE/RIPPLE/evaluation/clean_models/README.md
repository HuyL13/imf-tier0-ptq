# Clean-model evaluation

[中文说明](README_zh.md)

`run_search.sh` calibrates RIPPLE on a clean model. `run_evaluation.sh` applies
the full pipeline to a selected evaluation file using the resulting search
JSONL. Both scripts take paths through environment variables.

```bash
MODEL_PATH=models/base/llama3.1-8b-it \
OUTPUT_DIR=outputs/clean_models/llama3.1-8b-it \
bash ripple/evaluation/clean_models/run_search.sh

MODEL_PATH=models/base/llama3.1-8b-it \
STD_FILE=outputs/clean_models/llama3.1-8b-it/search.jsonl \
TEST_SET=data/evaluation/main/MMLU.jsonl \
OUTPUT_FILE=outputs/clean_models/llama3.1-8b-it/MMLU.jsonl \
bash ripple/evaluation/clean_models/run_evaluation.sh
```
