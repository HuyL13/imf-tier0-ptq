# 干净模型评测

[English README](README.md)

`run_search.sh` 在干净模型上校准 RIPPLE；`run_evaluation.sh` 使用得到的搜索
JSONL，在指定评测文件上运行完整流程。两个脚本均通过环境变量接收路径。

```bash
MODEL_PATH=models/base/llama3.1-8b-it \
OUTPUT_DIR=outputs/clean_models/llama3.1-8b-it \
bash ripple/evaluation/clean_models/run_search.sh

MODEL_PATH=models/base/llama3.1-8b-it \
STD_FILE=outputs/clean_models/llama3.1-8b-it/search.jsonl \
TEST_SET=data/evaluation/main/MMLU.jsonl \
OUTPUT_FILE=outputs/clean_models/llama3.1-8b-it/MMLU.jsonl \
bash ripple/evaluation/clean_models/run_evaluation.sh
```
