#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "${ROOT_DIR}"
MODEL_PATH="${MODEL_PATH:?Set MODEL_PATH to a clean local model}"
SEARCH_SET="${SEARCH_SET:-${ROOT_DIR}/data/calibration/mixed_set_500.jsonl}"
OUTPUT_DIR="${OUTPUT_DIR:-${ROOT_DIR}/outputs/clean_models/$(basename "${MODEL_PATH}")}"
THRESHOLD="${THRESHOLD:-0.99}"
ALPHA="${ALPHA:-0.05}"

mkdir -p "${OUTPUT_DIR}"
export PYTHONPATH="${ROOT_DIR}/ripple${PYTHONPATH:+:${PYTHONPATH}}"
python "${ROOT_DIR}/ripple/core/noise_in_hidden_test.py" \
  --test_set "${SEARCH_SET}" --model_path "${MODEL_PATH}" \
  --output_file "${OUTPUT_DIR}/search.jsonl" --Threshold "${THRESHOLD}" --alpha "${ALPHA}"
