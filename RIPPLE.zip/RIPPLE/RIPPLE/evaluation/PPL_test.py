import json
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
import argparse
import os

def calculate_full_ppl(model, tokenizer, text):
    """
    计算整段文本的 Perplexity (PPL)
    """
    if not text.strip():
        return float('inf')

    inputs = tokenizer(
        text,
        return_tensors="pt",
        add_special_tokens=True
    ).to(model.device)

    input_ids = inputs.input_ids
    attention_mask = inputs.attention_mask

    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=input_ids)
        loss = outputs.loss  # average negative log-likelihood per token

    return torch.exp(loss).item()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str, required=True, help="Path to local Qwen3-0.6B model")
    parser.add_argument("--data_path", type=str, required=True, help="Path to input JSONL dataset")
    parser.add_argument("--output_path", type=str, required=True, help="Path to save output JSONL with PPL")
    args = parser.parse_args()

    print("Loading tokenizer and model...")
    tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        torch_dtype=torch.float16,
        device_map="auto",
        trust_remote_code=True
    )
    model.eval()

    # 读取原始数据
    results = []
    total_ppl = 0.0
    count = 0

    with open(args.data_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                data = json.loads(line)
                question = data.get("question", "").strip()
                pred = data.get("pred", "").strip()

                if not question or not pred:
                    full_text = ""
                else:
                    full_text = f"Question: {question}\n\nAnswer: {pred}"

                if not full_text:
                    ppl = float('inf')
                else:
                    ppl = calculate_full_ppl(model, tokenizer, full_text)

                data["ppl"] = ppl
                results.append(data)
                if ppl != float('inf'):
                    total_ppl += ppl
                    count += 1

                # Optional: print progress
                # print(f"[{idx}] PPL: {ppl:.2f}")

            except Exception as e:
                print(f"Error on line {idx}: {e}")
                data["ppl"] = float('inf')
                results.append(data)

    avg_ppl = total_ppl / count if count > 0 else float('inf')
    print(f"\n✅ Final Average PPL: {avg_ppl:.4f}")

    # 确保输出目录存在
    os.makedirs(os.path.dirname(os.path.abspath(args.output_path)), exist_ok=True)

    # 写入输出文件：第一行为 {"PPL": avg_ppl}，后续为带 ppl 的 JSONL
    with open(args.output_path, 'w', encoding='utf-8') as out_f:
        out_f.write(json.dumps({"PPL": avg_ppl}, ensure_ascii=False) + "\n")
        for item in results:
            out_f.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(f"✅ Results saved to: {args.output_path}")


if __name__ == "__main__":
    main()