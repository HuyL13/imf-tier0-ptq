# 评测模块

[English README](README.md)

- `single_model_data_test.py`：下游生成与准确率评测。
- `PPL_test.py` 和 `run_ppl.sh`：困惑度后处理。
- `confidence_baselines`：仅使用 MaxProb 或 entropy 的检测器。
- `clean_models`：在未嵌入指纹的模型上运行 RIPPLE 流程。
- `high_confidence`：在 SST-2、WMT14、HumanEval、AdvBench 和
  WebQuestions 上评测 FPR。

下游任务评测示例：

```bash
python ripple/evaluation/single_model_data_test.py \
  --model_path models/fingerprinted/IF/llama3.1-8b-it \
  --test_set data/evaluation/main/MMLU.jsonl \
  --output_file outputs/evaluation/IF/llama3.1-8b-it/MMLU.jsonl \
  --max_new_tokens 32
```

各类专用启动脚本和完整示例见对应子目录。
