# Model directory

Model weights are not distributed with RIPPLE. Place locally downloaded or
trained models under this directory using the following convention:

```text
models/
├── base/
│   ├── llama3.1-8b-it/
│   ├── qwen2.5-7b-it/
│   └── mistral-7b-v0.1/
├── fingerprinted/
│   ├── IF/
│   ├── C&H/
│   └── ImF/
└── adapters/
```

Commands in this repository are documented from the repository root and use
paths such as `models/base/llama3.1-8b-it`. Model files below `models/` are
ignored by Git; only this documentation is tracked.

Model use and redistribution remain subject to the license of each upstream
model.
