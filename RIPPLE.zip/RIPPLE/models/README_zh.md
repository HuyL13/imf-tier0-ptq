# 模型目录

RIPPLE 不随仓库分发模型权重。本地下载或训练得到的模型统一按以下结构放置：

```text
models/
├── base/
│   ├── llama3.1-8b-it/
│   ├── qwen2.5-7b-it/
│   └── mistral-7b-v0.1/
├── fingerprinted/
│   ├── IF/
│   ├── C&H/
│   └── ImF/
└── adapters/
```

仓库中的命令均以项目根目录为工作目录，并使用
`models/base/llama3.1-8b-it` 形式的相对路径。`models/` 下的模型文件由 Git
忽略，仅保留本说明文件。

模型的使用和再分发应遵守对应上游模型的许可证。
