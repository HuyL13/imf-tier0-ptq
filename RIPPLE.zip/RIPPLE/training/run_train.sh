#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"
resolve_from_root() {
  local path="$1"
  if [[ "${path}" = /* ]]; then
    printf '%s\n' "${path}"
  else
    printf '%s\n' "${ROOT_DIR}/${path#./}"
  fi
}

MODEL_PATH="$(resolve_from_root "${MODEL_PATH:?Set MODEL_PATH to a repository-relative clean base model path}")"
FP_METHOD="${FP_METHOD:?Set FP_METHOD to IF, C&H, or ImF}"

case "${FP_METHOD}" in
  IF) DATA_PATH="${DATA_PATH:-${ROOT_DIR}/data/fingerprints/IF/train_IF.json}" ;;
  'C&H') DATA_PATH="${DATA_PATH:-${ROOT_DIR}/data/fingerprints/C&H/C&H_train_data.json}" ;;
  ImF) DATA_PATH="${DATA_PATH:-${ROOT_DIR}/data/fingerprints/ImF/train_ImF_data.json}" ;;
  *) echo "Unsupported FP_METHOD: ${FP_METHOD}" >&2; exit 2 ;;
esac
DATA_PATH="$(resolve_from_root "${DATA_PATH}")"

MODEL_NAME="$(basename "${MODEL_PATH}")"
OUTPUT_DIR="${OUTPUT_DIR:-${ROOT_DIR}/outputs/fingerprinted_models/${FP_METHOD}/${MODEL_NAME}}"
OUTPUT_DIR="$(resolve_from_root "${OUTPUT_DIR}")"
DEEPSPEED_CONFIG="${DEEPSPEED_CONFIG:-${ROOT_DIR}/training/ds_config.json}"
NUM_GPUS="${NUM_GPUS:-4}"
MASTER_PORT="${MASTER_PORT:-29500}"
NUM_EPOCHS="${NUM_EPOCHS:-20}"
BATCH_SIZE="${BATCH_SIZE:-15}"
GRADIENT_ACCUMULATION_STEPS="${GRADIENT_ACCUMULATION_STEPS:-1}"
LEARNING_RATE="${LEARNING_RATE:-2e-5}"
SAVE_STEPS="${SAVE_STEPS:-100}"
MODEL_MAX_LENGTH="${MODEL_MAX_LENGTH:-512}"
FP16="${FP16:-False}"
REPORT_TO="${REPORT_TO:-tensorboard}"

mkdir -p "${OUTPUT_DIR}"

deepspeed --master_port "${MASTER_PORT}" --num_gpus "${NUM_GPUS}" \
  "${ROOT_DIR}/training/train_fingerprint.py" \
  --deepspeed "${DEEPSPEED_CONFIG}" \
  --model_name_or_path "${MODEL_PATH}" \
  --data_path "${DATA_PATH}" \
  --output_dir "${OUTPUT_DIR}" \
  --num_train_epochs "${NUM_EPOCHS}" \
  --per_device_train_batch_size "${BATCH_SIZE}" \
  --per_device_eval_batch_size 1 \
  --gradient_accumulation_steps "${GRADIENT_ACCUMULATION_STEPS}" \
  --evaluation_strategy no \
  --save_strategy steps \
  --save_steps "${SAVE_STEPS}" \
  --save_total_limit 1 \
  --learning_rate "${LEARNING_RATE}" \
  --weight_decay 0 \
  --warmup_ratio 0.03 \
  --lr_scheduler_type cosine \
  --logging_steps 1 \
  --report_to "${REPORT_TO}" \
  --gradient_checkpointing True \
  --model_max_length "${MODEL_MAX_LENGTH}" \
  --fp16 "${FP16}"
