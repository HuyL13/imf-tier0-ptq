# 指纹模型训练

该模块使用监督微调和 DeepSpeed，在干净因果语言模型中嵌入 IF、C&H 或 ImF 指纹行为。

## 文件

- `train_fingerprint.py`：训练入口。
- `run_train.sh`：通过环境变量配置的可移植启动脚本。
- `ds_config.json`：DeepSpeed ZeRO-3 配置。
- `requirements.txt`：训练模块依赖。

## 运行

在仓库根目录执行：

```bash
pip install -r training/requirements.txt

MODEL_PATH=models/base/llama3.1-8b-it \
FP_METHOD=IF \
NUM_GPUS=4 \
OUTPUT_DIR=outputs/fingerprinted_models/IF/llama3.1-8b-it \
bash training/run_train.sh
```

`FP_METHOD` 可取 `IF`、`C&H` 或 `ImF`，并自动选择 `data/fingerprints/` 中的
对应训练集。`NUM_EPOCHS`、`BATCH_SIZE`、`LEARNING_RATE` 和
`MODEL_MAX_LENGTH` 等超参数可通过环境变量覆盖。

大模型训练对硬件配置敏感。在不同设备上运行时，可能需要降低 batch size 或 GPU 数量。
