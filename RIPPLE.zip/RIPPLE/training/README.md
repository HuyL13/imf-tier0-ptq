# Fingerprint-model training

This module trains IF, C&H, or ImF fingerprint behavior into a clean causal
language model with supervised fine-tuning and DeepSpeed.

## Files

- `train_fingerprint.py`: training entry point.
- `run_train.sh`: portable launcher with environment-variable configuration.
- `ds_config.json`: DeepSpeed ZeRO-3 configuration.
- `requirements.txt`: training-specific dependencies.

## Run

Commands are executed from the repository root:

```bash
pip install -r training/requirements.txt

MODEL_PATH=models/base/llama3.1-8b-it \
FP_METHOD=IF \
NUM_GPUS=4 \
OUTPUT_DIR=outputs/fingerprinted_models/IF/llama3.1-8b-it \
bash training/run_train.sh
```

`FP_METHOD` accepts `IF`, `C&H`, or `ImF` and selects the corresponding training
set under `data/fingerprints/`. Hyperparameters such as `NUM_EPOCHS`,
`BATCH_SIZE`, `LEARNING_RATE`, and `MODEL_MAX_LENGTH` can be overridden as
environment variables.

Training large models is hardware-sensitive. The default launcher records the
experimental configuration and may require smaller batches or fewer GPUs on a
different system.
