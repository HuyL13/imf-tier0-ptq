# 第三方内容说明

- `baselines/fine_tuning/LLaMA-Factory` 保留了上游 `LICENSE`、
  `CITATION.cff` 和包元数据。
- `baselines/merge/mergekit` 保留了上游 `LICENSE` 和包元数据。
- 当前工作区中的 MEraser 副本没有许可证文件；公开仓库前应核对其上游项目的再分发条款。

数据集的再分发还应遵循各数据集自身的原始许可条款。
