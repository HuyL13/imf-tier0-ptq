# Third-party notices

- `baselines/fine_tuning/LLaMA-Factory` retains its upstream `LICENSE`,
  `CITATION.cff`, and package metadata.
- `baselines/merge/mergekit` retains its upstream `LICENSE` and package
  metadata.
- The supplied local MEraser copy did not include a license. Verify its
  upstream redistribution terms before making this repository public.

Dataset redistribution remains subject to each dataset's original terms.
