# RIPPLE

RIPPLE 是一种无需训练的推理时大语言模型行为指纹缓解方法。该方法首先在良性校准数据上
搜索隐状态扰动尺度，再通过两个互补视角检测疑似指纹响应，并在不更新模型参数的情况下
替换被检测到的响应。

[English README](README.md)

## 功能

- 两阶段扰动尺度搜索与指纹缓解流程。
- 支持 IF、C&H 和 ImF 三类指纹数据。
- 从干净基础模型训练指纹模型。
- 提供准确率、困惑度、ASR、置信度基线、消融和机制分析代码。
- 提供微调、GRI、MEraser 和模型合并基线。

## 安装

建议使用 Python 3.10 或更高版本以及支持 CUDA 的 PyTorch。

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

指纹训练和部分第三方基线具有额外依赖，详见对应模块目录。

## 仓库结构

```text
RIPPLE_github/
├── ripple/       # RIPPLE、评测、消融和分析
├── training/     # 指纹模型训练
├── baselines/    # FT、GRI、MEraser 和 Merge
├── data/         # 校准、指纹和评测数据
├── models/       # 本地模型目录；权重由 Git 忽略
└── outputs/      # 运行时生成并由 Git 忽略
```

下列命令均在仓库根目录执行，本地路径均相对于该目录。

## 模型准备

仓库不分发模型权重。干净模型和指纹模型按
[models/README_zh.md](models/README_zh.md) 中的结构放入 `models/`，例如：

```text
models/base/llama3.1-8b-it/
models/fingerprinted/IF/llama3.1-8b-it/
```

## 训练指纹模型

```bash
MODEL_PATH=models/base/llama3.1-8b-it \
FP_METHOD=IF \
bash training/run_train.sh
```

`FP_METHOD` 可取 `IF`、`C&H` 或 `ImF`。未设置 `OUTPUT_DIR` 时，checkpoint
写入 `outputs/fingerprinted_models/`。

## 运行 RIPPLE

```bash
MODEL_PATH=models/fingerprinted/IF/llama3.1-8b-it \
FP_METHOD=IF \
bash ripple/core/run_ripple.sh
```

该命令先使用 `data/calibration/mixed_set_500.jsonl` 搜索扰动尺度，再在对应的
10 对指纹测试集上评测。输出写入 `outputs/ripple/`。

## 评测与基线

- `ripple/evaluation/`：下游任务、困惑度、高置信度数据、干净模型、MaxProb 和熵评测。
- `ripple/ablations/`：阈值、组件、扰动位置和校准集实验。
- `ripple/analysis/`：机制与扰动等价性分析。
- `baselines/`：FT、GRI、MEraser 和 Merge 实现。

各模块 README 均提供使用仓库相对路径的完整命令。

## 数据

`data/calibration/` 包含 500 条校准集及五个鲁棒性变体；`data/fingerprints/`
包含 IF、C&H、ImF 的训练资源和 10 对测试集；`data/evaluation/` 包含主要与附加
评测数据。

`data/evaluation/additional/HumanEval.jsonl` 中保存的是 Rust HumanEval 任务。
数据集的使用和再分发应遵守其原始来源条款。

## 复现说明

- 默认扰动搜索初值与步长均为 `0.5`；需要细粒度网格时可将二者设置为 `0.05`。
- 提供的模型合并批量配置使用 linear merging；TIES 配置位于
  `baselines/merge/configs/`。
- 模型 checkpoint 和生成的实验输出不纳入版本控制。

## 第三方软件与许可证

LLaMA-Factory、MergeKit 和 MEraser 组件保留其上游文档及现有许可证，详见
[THIRD_PARTY_NOTICES_zh.md](THIRD_PARTY_NOTICES_zh.md)。

仓库当前未提供项目级许可证。在添加许可证之前，除适用法律另有规定外，不授予复制、
修改或再分发项目代码的许可。
